package local.jarvis.search;

import android.app.assist.*;
import android.content.*;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.*;
import android.service.voice.*;
import android.view.View;

public final class MariSessionService extends VoiceInteractionSessionService {
    @Override public VoiceInteractionSession onNewSession(Bundle args){return new Session(this);}

    private static final class Session extends VoiceInteractionSession {
        final Handler handler=new Handler(Looper.getMainLooper());
        final Runnable deliver=this::open;
        ScreenItem item;
        boolean assist,shot;
        Session(Context c){super(c);}
        @Override public void onPrepareShow(Bundle args,int flags){super.onPrepareShow(args,flags);setUiEnabled(false);}
        @Override public void onShow(Bundle args,int flags){
            super.onShow(args,flags);clear();
            if(!ScreenTask.unlocked(getContext())){hide();return;}
            item=new ScreenItem();
            assist=false;shot=false;android.util.Log.i("MariScreen","System invocation flags="+flags);
            handler.postDelayed(deliver,3000);
        }
        @Override public void onHandleAssist(AssistState state){
            android.util.Log.i("MariScreen","Assist received, active="+(item!=null));if(item==null || state.getIndex()!=0)return;
            AssistContent content=state.getAssistContent();
            if(content!=null){
                Intent intent=content.getIntent();
                Uri uri=intent!=null && Intent.ACTION_VIEW.equals(intent.getAction())?intent.getData():null;
                if(uri==null && content.getClipData()!=null && content.getClipData().getItemCount()==1)
                    uri=content.getClipData().getItemAt(0).getUri();
                if(ScreenItem.safe(getContext(),uri))item.uri=uri;
            }
            AssistStructure structure=state.getAssistStructure();
            if(structure!=null){
                var component=structure.getActivityComponent();
                if(component!=null)item.origin=component.getPackageName();
                StringBuilder text=new StringBuilder();
                for(int i=0;i<structure.getWindowNodeCount();i++)collect(structure.getWindowNodeAt(i).getRootViewNode(),text,0);
                item.text=text.toString();
            }
            assist=true;ready();
        }
        private void collect(AssistStructure.ViewNode n,StringBuilder out,int depth){
            if(depth>45 || out.length()>10000 || n.getVisibility()!=View.VISIBLE || n.getInputType()!=0)return;
            CharSequence t=n.getText();if(t!=null && t.length()>0)out.append(t,0,Math.min(512,t.length())).append('\n');
            for(int i=0;i<n.getChildCount()&&out.length()<10000;i++)collect(n.getChildAt(i),out,depth+1);
        }
        @Override public void onHandleScreenshot(Bitmap b){
            if(item==null)return;
            android.util.Log.i("MariScreen","Screenshot available="+(b!=null));item.picture=b;shot=true;ready();
        }
        private void ready(){if(assist && shot){handler.removeCallbacks(deliver);handler.post(deliver);}}
        private void clear(){handler.removeCallbacks(deliver);item=null;}
        private void open(){
            if(item==null || !ScreenTask.unlocked(getContext())){hide();return;}
            Intent i=new Intent(getContext(),AssistPanel.class).setAction(ScreenItem.ACTION)
                .putExtra("capture",ScreenItem.offer(item)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
            if(item.uri!=null)i.setClipData(ClipData.newRawUri("file",item.uri));
            if(item.uri!=null)i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try{getContext().startActivity(i);}catch(RuntimeException e){android.widget.Toast.makeText(getContext(),"Не удалось открыть Марию",0).show();}
            clear();hide();
        }
        @Override public void onHide(){clear();super.onHide();}
        @Override public void onDestroy(){clear();super.onDestroy();}
    }
}
