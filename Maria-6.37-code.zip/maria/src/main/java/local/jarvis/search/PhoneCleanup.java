package local.jarvis.search;

import android.app.*;
import android.content.*;
import android.os.*;
import android.os.storage.StorageManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.format.Formatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

final class PhoneCleanup {
    static final int TRASH=213,CACHE=214;
    private final SearchActivity a;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private AlertDialog progress;
    private Future<?> job;
    private int epoch;
    PhoneCleanup(SearchActivity a){this.a=a;}
    static boolean requested(String text){
        String q=text.toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("[,.!?]+"," ").strip().replaceAll("\\s+"," ");
        q=q.replaceFirst("^(?:(?:мари|джарвис|пожалуйста|давай) )+","");
        return q.matches("(?:(?:запусти|начни|открой|сделай|проведи|включи) )?(?:глубок(?:ая|ую) )?очистк[ау](?: телефона| памяти| хранилища)?(?: от мусора)?")
            || q.matches("(?:очисти|почисти) (?:мне )?(?:телефон|хранилище|память|к[еэ]ш)(?: телефона)?(?: от мусора)?")
            || q.matches("(?:освободи место|убери мусор|найди дубликаты)(?: на телефоне| в телефоне)?");
    }
    private String size(long n){return Formatter.formatFileSize(a,n);}
    private String free(){return size(new StatFs(Environment.getDataDirectory().getPath()).getAvailableBytes());}
    private void message(String s){a.record("Очистка",s);new AlertDialog.Builder(a).setTitle("Очистка телефона").setMessage(s).setPositiveButton("Готово",null).show();}
    void stop(){
        epoch++;
        if(job!=null)job.cancel(true);
        if(progress!=null){progress.dismiss();progress=null;}
    }
    void close(){stop();io.shutdownNow();}
    private <T> void task(String title,Callable<T> work,Consumer<T> done){
        stop();int token=epoch;
        progress=new AlertDialog.Builder(a).setTitle(title).setMessage("Обработка на телефоне…")
            .setNegativeButton("Остановить",(d,w)->stop()).setOnCancelListener(d->stop()).show();
        job=io.submit(()->{
            try{T result=work.call();a.runOnUiThread(()->{
                if(epoch!=token || a.isFinishing() || a.isDestroyed())return;
                progress.dismiss();progress=null;done.accept(result);
            });}catch(Exception failure){a.runOnUiThread(()->{
                if(epoch!=token || a.isFinishing() || a.isDestroyed())return;
                progress.dismiss();progress=null;message("Проверка прервана. Проверьте доступ к файлам и повторите.");
            });}
        });
    }
    void open(){
        a.record("Очистка","Начато локальное сканирование");
        task("Ищу временные файлы и точные копии",()->CleanupScan.run(a),this::report);
    }
    private void report(CleanupScan s){
        long temp=s.temp.stream().mapToLong(CleanupScan.Temp::bytes).sum();
        long copies=s.copies.stream().mapToLong(c->c.item().bytes()).sum();
        List<String> rows=new ArrayList<>();List<Runnable> actions=new ArrayList<>();
        if(!s.temp.isEmpty()){rows.add("Временные копии Марии · "+size(temp));actions.add(()->chooseTemp(s));}
        if(!s.copies.isEmpty()){rows.add("Копии фото и видео · "+s.copies.size()+" · "+size(copies));actions.add(()->chooseCopies(s));}
        if(Build.VERSION.SDK_INT>=30 && Environment.isExternalStorageManager()){
            rows.add("Очистить внешний кэш приложений…");actions.add(this::systemCache);
        }
        rows.add("Открыть хранилище Android");actions.add(()->{
            try{a.startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));}catch(ActivityNotFoundException e){message("Экран хранилища недоступен.");}
        });
        String summary="Свободно "+free()+"\nДоступные фото и видео от 256 КиБ: "+s.checked+
            "\nТочные копии: "+s.copies.size()+" · Временные файлы Марии: "+s.temp.size();
        if(s.unreadable>0)summary+="\nЧасть данных не удалось прочитать.";
        if(Build.VERSION.SDK_INT<30)summary+="\nКорзина для копий доступна с Android 11.";
        a.record("Очистка",summary);
        android.widget.TextView header=new android.widget.TextView(a);int pad=(int)(20*a.getResources().getDisplayMetrics().density);
        header.setPadding(pad,pad,pad,pad/2);header.setTextSize(18);header.setText("Очистка телефона\n\n"+summary);
        new AlertDialog.Builder(a).setCustomTitle(header).setItems(rows.toArray(new String[0]),(d,i)->actions.get(i).run()).setNegativeButton("Закрыть",null).show();
    }
    private void chooseTemp(CleanupScan scan){
        List<CleanupScan.Temp> list=scan.temp;
        String[] labels=list.stream().map(f->(f.path().getName().startsWith("drive-preview-")?"Предпросмотр с Диска":"Копия для передачи")+" · "+size(f.bytes())+"\n"+f.path().getName()).toArray(String[]::new);
        choose("Кэш Марии старше 7 дней","Продолжить",labels,indices->{
            List<CleanupScan.Temp> chosen=indices.stream().map(list::get).collect(java.util.stream.Collectors.toList());long bytes=chosen.stream().mapToLong(CleanupScan.Temp::bytes).sum();
            new AlertDialog.Builder(a).setTitle("Удалить временные копии?").setMessage("Выбрано: "+chosen.size()+" · "+size(bytes)+". Удаление из кэша окончательное.")
                .setNegativeButton("Отмена",null).setPositiveButton("Удалить из кэша",(d,w)->task("Очищаю кэш Марии",()->{
                    long removed=0;int count=0;
                    for(var f:chosen){if(Thread.currentThread().isInterrupted())break;try{if(CleanupScan.remove(f)){removed+=f.bytes();count++;}}catch(java.io.IOException ignored){}}
                    return "Удалено временных файлов: "+count+" из "+chosen.size()+" ("+size(removed)+"). Сейчас свободно "+free()+".";
                },this::message)).show();
        });
    }
    private void chooseCopies(CleanupScan s){
        String[] labels=s.copies.stream().map(c->c.item().location()+" · "+size(c.item().bytes())+"\nОстанется: "+c.keep().location()).toArray(String[]::new);
        choose("Какие копии переместить в корзину?","В корзину",labels,indices->{
            if(indices.size()>2000){message("За один раз можно выбрать до 2 000 копий.");return;}
            List<CleanupScan.Copy> chosen=indices.stream().map(s.copies::get).collect(java.util.stream.Collectors.toList());
            task("Повторно сверяю выбранные копии",()->CleanupScan.recheck(a.getContentResolver(),chosen),uris->{
                if(uris.size()!=chosen.size()){message("Состав файлов изменился. Повторите сканирование.");return;}
                try{
                    PendingIntent ask=MediaStore.createTrashRequest(a.getContentResolver(),uris,true);
                    a.startIntentSenderForResult(ask.getIntentSender(),TRASH,null,0,0,0);
                }catch(Exception e){message("Android не разрешил перемещение в корзину.");}
            });
        });
    }
    private void choose(String title,String action,String[] labels,Consumer<List<Integer>> accept){
        boolean[] selected=new boolean[labels.length];
        AlertDialog dialog=new AlertDialog.Builder(a).setTitle(title)
            .setMultiChoiceItems(labels,selected,(d,i,on)->selected[i]=on).setNegativeButton("Отмена",null)
            .setPositiveButton(action,(d,w)->{
                List<Integer> ids=new ArrayList<>();for(int i=0;i<selected.length;i++)if(selected[i])ids.add(i);
                if(!ids.isEmpty())accept.accept(ids);
            }).create();
        dialog.show();var next=dialog.getButton(AlertDialog.BUTTON_POSITIVE);next.setEnabled(false);
        dialog.getListView().setOnItemClickListener((parent,v,i,id)->{
            selected[i]=dialog.getListView().isItemChecked(i);
            boolean any=false;for(boolean value:selected)any|=value;next.setEnabled(any);
        });
    }
    private void systemCache(){
        new AlertDialog.Builder(a).setTitle("Внешний кэш приложений")
            .setMessage("Android предложит очистить временные файлы других приложений. Часть содержимого им может понадобиться загрузить заново.")
            .setNegativeButton("Отмена",null).setPositiveButton("Продолжить",(d,w)->{
                try{a.startActivityForResult(new Intent(StorageManager.ACTION_CLEAR_APP_CACHE),CACHE);}
                catch(SecurityException|ActivityNotFoundException e){message("На этом телефоне недоступна системная очистка внешнего кэша.");}
            }).show();
    }
    void result(int request,int code){
        if(code==Activity.RESULT_CANCELED){message("Операция отменена.");return;}
        if(code!=Activity.RESULT_OK){message("Android сообщил об ошибке очистки.");return;}
        message(request==TRASH?"Android переместил выбранные копии в корзину. Место освободится после её очистки.":"Android подтвердил очистку внешнего кэша. Сейчас свободно "+free()+".");
    }
}
