package local.jarvis.search;

import android.accessibilityservice.*;
import android.os.*;
import android.view.accessibility.*;
import android.widget.Toast;
import java.util.*;

public final class ScreenTask extends AccessibilityService {
    private static ScreenTask active;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable step=this::advance;
    private String target,label,afterSearch;
    private boolean search,opened,seenTarget;
    private long deadline;
    private int scrolls;
    private long scrollAfter;
    private final android.content.BroadcastReceiver screenOff=new android.content.BroadcastReceiver(){
        public void onReceive(android.content.Context ctx,android.content.Intent intent){reset();}
    };
    @Override public void onCreate(){
        super.onCreate();
        var filter=new android.content.IntentFilter(android.content.Intent.ACTION_SCREEN_OFF);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(screenOff,filter,android.content.Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(screenOff,filter);
    }
    @Override protected void onServiceConnected(){active=this;reset();}
    static void cancel(){if(active!=null)active.reset();}
    static void disableControl(){
        ScreenTask service=active;
        if(service==null)return;
        service.reset();active=null;service.disableSelf();
    }
    static boolean ready(){return active!=null;}
    static String accessStatus(android.content.Context c){
        if(ready())return "Доступ к управлению экраном включён. Служба Марии подключена.";
        var mine=new android.content.ComponentName(c,ScreenTask.class);
        String enabled=android.provider.Settings.Secure.getString(c.getContentResolver(),
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if(enabled!=null)for(String entry:enabled.split(":")){
            if(mine.equals(android.content.ComponentName.unflattenFromString(entry)))
                return "Доступ уже выдан. Android пока не подключил службу Марии.";
        }
        return "Доступ к управлению экраном выключен. В специальных возможностях включите службу действий Марии.";
    }
    @Override public boolean onUnbind(android.content.Intent intent){
        reset();if(active==this)active=null;return super.onUnbind(intent);
    }
    static boolean unlocked(android.content.Context c){
        return c.getSystemService(PowerManager.class).isInteractive()
            && !c.getSystemService(android.app.KeyguardManager.class).isKeyguardLocked();
    }
    static boolean start(String pkg,String value,boolean find,String nextButton){
        ScreenTask s=active;if(s==null || !unlocked(s))return false;s.reset();s.target=pkg;s.label=value;s.search=find;s.afterSearch=nextButton;s.deadline=SystemClock.uptimeMillis()+15000;
        s.events(pkg,AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);
        s.handler.postDelayed(s.step,450);return true;
    }
    private ScreenNavigation navigation;
    private long navigationTurn;
    private boolean scrolled;
    private int scrollWindow;
    private long settleUntil;
    static boolean navigate(String pkg,ScreenNavigation action,long turn){
        ScreenTask s=active;
        if(s==null || !unlocked(s) || pkg.equals(s.getPackageName()) || pkg.equals("android") ||
            pkg.equals("com.android.systemui") || pkg.contains("permissioncontroller") || pkg.contains("packageinstaller"))return false;
        s.reset();s.target=pkg;s.navigation=action;s.navigationTurn=turn;s.deadline=SystemClock.uptimeMillis()+6000;
        s.events(pkg,AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED|AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_VIEW_SCROLLED);
        s.handler.postDelayed(s.step,350);return true;
    }
    private void navigateStep(AccessibilityNodeInfo root){
        if(SystemClock.uptimeMillis()<settleUntil){handler.removeCallbacks(step);handler.postDelayed(step,200);return;}
        if(scrolled && root.getWindowId()!=scrollWindow){String notice="После прокрутки изменилось окно. Остановилась.";SearchJournal.get(this).add(navigationTurn,"Результат на экране",notice);finish(notice);return;}
        boolean scroll=!scrolled && !navigation.direction().isEmpty();
        var result=navigation.run(root,scroll);
        SearchJournal.get(this).add(navigationTurn,"Результат на экране",target+" · "+result.notice());
        if(scroll && result.ok() && !navigation.label().isEmpty()){
            scrolled=true;scrollWindow=root.getWindowId();settleUntil=SystemClock.uptimeMillis()+650;
            handler.removeCallbacks(step);handler.postDelayed(step,700);return;
        }
        finish(result.notice());
    }
    private Messenger recipientApp;
    private long recipientTurn;
    private GoogleTasksFlow googleTasks;
    private PostReader post;
    private ScreenItem postSource;
    static boolean readPost(ScreenItem source,long turn){
        ScreenTask s=active;
        if(s==null||!unlocked(s)||source.origin.isBlank()||source.origin.equals(s.getPackageName()))return false;
        s.reset();s.postSource=source;s.post=new PostReader(source.origin,turn);s.target=source.origin;
        s.deadline=SystemClock.uptimeMillis()+3000;
        s.events(s.target,AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED|AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED);
        s.handler.postDelayed(s.step,400);return true;
    }
    private void returnPost(){
        var r=post;var source=postSource;reset();
        source.article=r.body.toString();source.readingNotice=r.notice;source.articleTurn=r.turn;
        SearchJournal.get(this).add(r.turn,"Чтение поста","Экранов: "+r.pages+" · прокруток: "+r.scrolls+" · символов: "+source.article.length()+" · "+r.notice);
        var intent=new android.content.Intent(this,AssistPanel.class).setAction(ScreenItem.ACTION)
            .putExtra("capture",ScreenItem.offer(source)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK|android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK);
        try{startActivity(intent);}catch(RuntimeException e){Toast.makeText(this,"Не удалось открыть панель чтения Марии.",Toast.LENGTH_LONG).show();}
    }
    static boolean tasks(GoogleTasksFlow request){
        ScreenTask s=active;if(s==null||!unlocked(s))return false;
        s.reset();s.googleTasks=request;s.target=GoogleTasksFlow.PKG;s.deadline=SystemClock.uptimeMillis()+65000;
        s.events(s.target,AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);
        s.handler.postDelayed(s.step,650);return true;
    }
    private void tasksResult(String result){
        var window=getRootInActiveWindow();
        boolean showingTasks=window!=null && GoogleTasksFlow.PKG.contentEquals(Objects.toString(window.getPackageName(),""));
        GoogleTasksFlow task=googleTasks;reset();
        SearchJournal.get(this).add(task.turn,"Результат Google Задач",result);
        if(!task.list && result.startsWith("Подтверждено")){
            ActionReceipt.remember(this,"google",task.title,task.due,"Google Задачи подтвердили «"+task.title+"» на");
        }
        if(showingTasks && unlocked(this))try{
            startActivity(new android.content.Intent(this,SearchActivity.class).setAction("local.jarvis.TASK_RECEIPT")
                    .putExtra("report",result).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK|android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP|android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP));
        }catch(RuntimeException e){Toast.makeText(this,result,Toast.LENGTH_LONG).show();}
    }
    static void recipient(Messenger app,String name,long turn){
        if(start(app.pkg,name,true,null)){
            active.recipientApp=app;active.recipientTurn=turn;
            active.deadline=SystemClock.uptimeMillis()+90000; // Allow time for the Android profile chooser.
            active.events(app.pkg,AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED);
        }
    }
    private AccessibilityNodeInfo visibleById(AccessibilityNodeInfo root,String id){
        AccessibilityNodeInfo only=null;
        for(var node:root.findAccessibilityNodeInfosByViewId(target+":id/"+id)){
            if(node.isVisibleToUser() && node.isEnabled() && !node.isPassword()){
                if(only!=null)return null;
                only=node;
            }
        }
        return only;
    }
    private void fillRecipient(AccessibilityNodeInfo root){
        if(recipientApp==Messenger.WHATSAPP){
            if(!opened){
                if(root.findAccessibilityNodeInfosByViewId(target+":id/contactpicker_row_container").isEmpty()
                    && root.findAccessibilityNodeInfosByViewId(target+":id/create_new_group_icon").isEmpty())return;
                var button=visibleById(root,"menuitem_search");
                if(button!=null)opened=button.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                return;
            }
            enterRecipient(visibleById(root,"search_src_text"));return;
        }
        if(recipientApp==Messenger.VIBER){enterRecipient(visibleById(root,"add_recipients_search_field"));return;}
        ArrayDeque<AccessibilityNodeInfo> queue=new ArrayDeque<>();queue.add(root);
        AccessibilityNodeInfo field=null;
        for(int i=0;!queue.isEmpty() && i<1500;i++){
            var n=queue.remove();
            boolean chatSearch=false;
            for(CharSequence part:new CharSequence[]{n.getHintText(),n.getContentDescription(),n.getText()}){
                if(text(part).matches("поиск чатов|поиск по чатам|search chats|search for chats|пошук чатів")){chatSearch=true;break;}
            }
            if(chatSearch && n.isVisibleToUser() && n.isEnabled() && !n.isPassword()
                    && (n.isEditable() || n.isClickable())){
                if(field!=null && !field.equals(n) && n.isEditable()==field.isEditable())return;
                if(field==null || n.isEditable())field=n;
            }
            for(int c=0;c<n.getChildCount();c++){var child=n.getChild(c);if(child!=null)queue.add(child);}
        }
        if(field==null)return;
        if(!opened && (!field.isFocused() || !field.isEditable())){
            opened=field.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            if(opened){android.util.Log.i("MariScreen",recipientApp.title+" chat search opened");return;}
        }
        enterRecipient(field);
    }
    private void enterRecipient(AccessibilityNodeInfo field){
        if(field==null || !field.isEditable())return;
        Bundle args=new Bundle();args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,label);
        if(field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args)){
            SearchJournal.get(this).add(recipientTurn,"Результат на экране",recipientApp.title+" · введено имя для поиска: "+label);
            finish("Имя введено. Выберите чат и проверьте вложение.");
        }
    }
    private void events(String pkg,int types){
        AccessibilityServiceInfo info=getServiceInfo();
        if(info!=null){
            if(recipientApp==null && googleTasks==null && post==null && navigation==null)info.flags&=~AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
            else info.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
            if(googleTasks!=null)info.flags|=AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS;
            else info.flags&=~AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS;
            info.packageNames=new String[]{pkg};info.eventTypes=types;setServiceInfo(info);}
    }
    private void reset(){handler.removeCallbacks(step);target=null;seenTarget=false;recipientApp=null;googleTasks=null;post=null;postSource=null;navigation=null;scrolled=false;settleUntil=0;label=null;afterSearch=null;scrolls=0;scrollAfter=0;opened=false;events(getPackageName(),0);}
    private void finish(String message){reset();Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    private boolean next(){
        if(afterSearch==null)return false;
        String[] remaining=afterSearch.split(",? и нажми (?:кнопку )?",2);
        label=remaining[0];afterSearch=remaining.length==2?remaining[1]:null;
        scrolls=0;scrollAfter=SystemClock.uptimeMillis()+650;search=false;opened=false;
        handler.removeCallbacks(step);handler.postDelayed(step,400);return true;
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(target!=null && !handler.hasCallbacks(step))handler.postDelayed(step,160);
    }
    private static String text(CharSequence value){return value==null?"":value.toString().trim().toLowerCase(Locale.ROOT);}
    private List<AccessibilityNodeInfo> matches(AccessibilityNodeInfo root,boolean input){
        ArrayDeque<AccessibilityNodeInfo> pending=new ArrayDeque<>();pending.add(root);
        List<AccessibilityNodeInfo> found=new ArrayList<>();
        for(int i=0;!pending.isEmpty()&&i<1600;i++){
            var n=pending.remove();
            if(!n.isVisibleToUser()||!n.isEnabled()||n.isPassword())continue;
            String t=text(n.getText()),d=text(n.getContentDescription());
            String hint=text(n.getHintText()),id=text(n.getViewIdResourceName());
            boolean searchField=opened||(t+" "+d+" "+hint+" "+id).matches(".*(?:поиск|найти|search).*");
            boolean match=input?n.isEditable()&&searchField:search?t.matches("поиск|search")||d.matches("поиск|search"):t.equals(label)||d.equals(label);
            if(match){
                if(!input){while(n!=null&&!n.isClickable())n=n.getParent();}
                if(n!=null&&!found.contains(n))found.add(n);
                continue;
            }
            for(int j=0;j<n.getChildCount();j++){var child=n.getChild(j);if(child!=null)pending.add(child);}
        }
        return found;
    }
    private void scrollList(AccessibilityNodeInfo root){
        long now=SystemClock.uptimeMillis();
        if(scrolls>=8 || now<scrollAfter)return;
        ArrayDeque<AccessibilityNodeInfo> pending=new ArrayDeque<>();
        pending.add(root);
        for(int visited=0;!pending.isEmpty() && visited<1200;visited++){
            var node=pending.remove();
            if(!node.isVisibleToUser())continue;
            if(node.isScrollable() && node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)){
                scrolls++;
                scrollAfter=now+650;
                return;
            }
            for(int i=0;i<node.getChildCount();i++){
                var child=node.getChild(i);
                if(child!=null)pending.add(child);
            }
        }
    }
    private void advance(){
        if(target==null)return;
        if(!unlocked(this)){reset();return;}
        if(SystemClock.uptimeMillis()>=deadline){
            if(navigation!=null){String message="Исходное приложение не появилось вовремя.";SearchJournal.get(this).add(navigationTurn,"Результат на экране",message);finish(message);return;}
            if(recipientApp!=null){String notice="Не удалось ввести имя в поиск получателя.";SearchJournal.get(this).add(recipientTurn,"Результат на экране",recipientApp.title+" · "+notice);finish(notice);return;}
            if(post!=null){
                var current=getRootInActiveWindow();
                if(seenTarget && current!=null && target.equals(Objects.toString(current.getPackageName(),""))){post.notice="Достигнут предел времени прокрутки.";returnPost();}
                else finish("Откройте публикацию и вызовите Марию поверх неё.");return;
            }
            if(googleTasks!=null)tasksResult("Не удалось подтвердить результат в Google Задачах. Проверьте открытый список перед повтором.");
            else finish("Мария: не нашла нужную кнопку или поле на этом экране.");return;
        }
        var root=getRootInActiveWindow();
        if(root!=null && target.contentEquals(root.getPackageName()==null?"":root.getPackageName())){
            if(post!=null){
                if(!seenTarget)deadline=SystemClock.uptimeMillis()+90000;
                seenTarget=true;
                if(post.step(root)){returnPost();return;}
                handler.removeCallbacks(step);handler.postDelayed(step,600);return;
            }
            if(!seenTarget && recipientApp!=null)deadline=SystemClock.uptimeMillis()+15000;
            seenTarget=true;
            if(navigation!=null){navigateStep(root);return;}
            if(googleTasks!=null){
                String before=googleTasks.stage();
                String result=googleTasks.step(root);
                if(!before.equals(googleTasks.stage()))android.util.Log.i("MariTasks",before+" -> "+googleTasks.stage());
                if(result!=null){tasksResult(result);return;}
                handler.removeCallbacks(step);handler.postDelayed(step,500);return;
            }
            if(recipientApp!=null){
                fillRecipient(root);
                if(target!=null){handler.removeCallbacks(step);handler.postDelayed(step,350);}
                return;
            }
            var fields=search?matches(root,true):Collections.<AccessibilityNodeInfo>emptyList();
            if(fields.size()>1){finish("Мария: на экране несколько полей ввода.");return;}
            if(fields.size()==1){
                var field=fields.get(0);
                Bundle args=new Bundle();
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,label);
                if(field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args)){
                    boolean sent=Build.VERSION.SDK_INT>=30 && field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
                    if(next())return;
                    finish(sent?"Запрос передан приложению.":"Запрос введён. Результаты или кнопка поиска — на экране приложения.");return;
                }
            }else if(!opened){
                var buttons=matches(root,false);
                if(buttons.size()>1){finish("Мария: на экране несколько подходящих кнопок.");return;}
                if(!search && buttons.size()==1 && ScreenNavigation.manualControl(buttons.get(0))){finish("Последнее нажатие оставляю вам.");return;}
                if(buttons.size()==1 && buttons.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK)){
                    if(!search){if(!next())finish("Нажал «"+label+"».");return;}
                    opened=true;
                } else if(buttons.isEmpty() && !search) scrollList(root);
            }
        }else if(seenTarget && root!=null && googleTasks==null){
            if(navigation!=null)SearchJournal.get(this).add(navigationTurn,"Результат на экране","Открыто другое приложение. Остановилась.");
            reset();return;
        }
        handler.removeCallbacks(step);handler.postDelayed(step,350);
    }
    @Override public void onInterrupt(){reset();}
    @Override public void onDestroy(){unregisterReceiver(screenOff);reset();if(active==this)active=null;super.onDestroy();}
}
