package local.jarvis.search;

import android.content.Context;
import java.io.File;
import java.nio.charset.StandardCharsets;

final class LocalAnswer {
    static { System.loadLibrary("jarvis_brain"); }
    static native void select(long id);
    private static native byte[] generate(byte[] path, byte[] prompt, long id);
    static AssistantPlan understand(Context context,String request,String available,long id){
        File model=new File(context.getExternalFilesDir(null),"qwen.gguf");
        if(!model.isFile() || request.length()>900)return AssistantPlan.clarify();
        String instructions=AssistantPlan.INSTRUCTIONS;
        if(available.contains("openedDocument=false"))instructions=instructions.replace("DOCUMENT = question about an already opened document.","");
        if(available.contains("resultCount=0"))instructions=instructions.replace("RESULT = open numbered result, argument = number starting at 1.","");
        String prompt="<|im_start|>system\n"+instructions+"\nContext: "+available+"<|im_end|>\n<|im_start|>user\n"
                +request.replace("<|","").replace("|>","")+"<|im_end|>\n<|im_start|>assistant\n";
        byte[] out=generate(model.getAbsolutePath().getBytes(StandardCharsets.UTF_8),prompt.getBytes(StandardCharsets.UTF_8),id);
        AssistantPlan plan=AssistantPlan.parse(out==null?null:new String(out,StandardCharsets.UTF_8));
        if(plan.tool()==AssistantPlan.Tool.DOCUMENT && available.contains("openedDocument=false")
                || plan.tool()==AssistantPlan.Tool.RESULT && available.contains("resultCount=0"))return AssistantPlan.clarify();
        return plan;
    }
    static String englishDescription(Context ctx,String text,long id) throws java.io.IOException {
        if (!java.util.regex.Pattern.compile("\\p{IsCyrillic}").matcher(text).find()) return text;
        File model=new File(ctx.getExternalFilesDir(null),"qwen.gguf");
        if (!model.isFile()) throw new java.io.IOException("Нужна модель Qwen для перевода описания.");
        String prompt="<|im_start|>system\nTranslate the Russian image description into English. Output ONLY a short English noun phrase, no explanation. Example: белая собака на траве = a white dog on the grass.<|im_end|>\n<|im_start|>user\n"
                +text.replace("<|","").replace("|>","")+"<|im_end|>\n<|im_start|>assistant\n";
        byte[] data=generate(model.getAbsolutePath().getBytes(StandardCharsets.UTF_8),prompt.getBytes(StandardCharsets.UTF_8),id);
        if(data==null || data.length==0) throw new java.io.IOException("Не удалось разобрать описание.");
        return new String(data,StandardCharsets.UTF_8).strip();
    }
    static String answer(Context ctx, String question, long token) {
        File model=new File(ctx.getExternalFilesDir(null),"qwen.gguf");
        if (model.length()!=1117320736L) return "Для ответов нужен файл модели. Установите его по инструкции из комплекта Марии.";
        if (question.length()>900) return "Сформулируйте вопрос короче, чтобы он поместился в память модели.";
        String prompt="<|im_start|>system\nТы Мария, дружелюбная помощница на телефоне. Говори от первого лица в женском роде. Отвечай тепло и по делу, учитывай вопрос. Не выдумывай выполненные действия. Отвечай на русском, кратко, одним-тремя предложениями. Если не знаешь, скажи об этом. У тебя нет интернета.<|im_end|>\n<|im_start|>user\n"
                +question.replace("<|","").replace("|>","")+"<|im_end|>\n<|im_start|>assistant\n";
        byte[] data=generate(model.getAbsolutePath().getBytes(StandardCharsets.UTF_8),prompt.getBytes(StandardCharsets.UTF_8),token);
        return data==null || data.length==0 ? "Не удалось подготовить ответ. Попробуйте ещё раз или сократите вопрос." : new String(data,StandardCharsets.UTF_8).trim();
    }
}
