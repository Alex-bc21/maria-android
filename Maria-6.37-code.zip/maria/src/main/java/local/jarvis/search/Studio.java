package local.jarvis.search;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;

final class Studio {
    static final int BG=0xff0c111b, PANEL=0xff19202d, EDGE=0xff334050, TEXT=0xfff6f3fc, MUTED=0xffb9c4d2,
        LILAC=0xffc9bcff, PEACH=0xffffc4a6, MINT=0xffb2dfd8;
    final Context ctx;
    Studio(Context ctx){this.ctx=ctx;}
    int dp(float n){return Math.round(n*ctx.getResources().getDisplayMetrics().density);}
    GradientDrawable shape(int color,int radius,int border){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));
        if(border!=0)d.setStroke(dp(1),border);return d;
    }
    Drawable surface(int color,int radius,int border){return new RippleDrawable(ColorStateList.valueOf(0x34d4caff),shape(color,radius,border),null);}
    LinearLayout column(){LinearLayout l=new LinearLayout(ctx);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(ctx);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    TextView text(String s,int size,int color,boolean medium){
        TextView v=new TextView(ctx);v.setText(s);v.setTextColor(color);v.setTextSize(size);v.setIncludeFontPadding(false);
        v.setTypeface(Typeface.create(medium?"sans-serif-medium":"sans-serif",0));return v;
    }
    Drawable glyph(String name,int tint){
        Drawable d=ctx.getDrawable(ctx.getResources().getIdentifier("ui_"+name,"drawable",ctx.getPackageName())).mutate();d.setTint(tint);return d;
    }
    ImageView icon(String name,int tint){ ImageView i=new ImageView(ctx);i.setImageDrawable(glyph(name,tint));i.setScaleType(ImageView.ScaleType.CENTER_INSIDE);return i; }
    void action(View v,String label,Runnable fn){
        v.setFocusable(true);v.setContentDescription(label);
        v.setOnClickListener(w->{w.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK);fn.run();});
    }
    ImageView iconButton(String name,String label,int tint,Runnable fn){
        ImageView v=icon(name,tint);v.setPadding(dp(12),dp(12),dp(12),dp(12));
        v.setBackground(surface(PANEL,16,EDGE));action(v,label,fn);return v;
    }
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    void gap(LinearLayout l,int amount){View v=new View(ctx);if(l.getOrientation()==LinearLayout.VERTICAL)l.addView(v,lp(1,amount));else l.addView(v,lp(amount,1));}
    void tintCard(LinearLayout v,int a,int b){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});
        d.setCornerRadius(dp(20));d.setStroke(dp(1),EDGE);
        v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x24ffffff),d,null));
    }
}
