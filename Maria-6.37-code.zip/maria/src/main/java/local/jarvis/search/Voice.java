package local.jarvis.search;

import android.content.*;
import android.os.Bundle;
import android.speech.*;
import android.speech.tts.*;
import android.util.Log;
import java.util.*;

final class Voice implements RecognitionListener {
    interface Events { void speakingText(String text); void status(String text); void recognized(String text); void mic(AuraView.Mode mode); void level(float value); void playing(boolean value); void mouth(float open,float round); }
    private final Context context;
    private final Events events;
    private final NeuralSpeech neural;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ready, closed, listening;
    private String queued;
    private String utterance;
    private Runnable afterSpeech;
    private final android.os.Handler main=new android.os.Handler(android.os.Looper.getMainLooper());
    private void playback(String id,boolean active){main.post(()->{if(!closed && id.equals(utterance))events.playing(active);});}
    Voice(Context context, Events events) {
        this.context=context; this.events=events;
        neural=new NeuralSpeech(context);
    }
    private void startTts(String engine) {
        tts=new TextToSpeech(context,code->{
            if (closed) return;
            if (code!=TextToSpeech.SUCCESS || tts.setLanguage(Locale.forLanguageTag("ru-RU"))<0) {
                if (engine==null) { tts.shutdown(); startTts("com.google.android.tts"); }
                else events.status("Русский голос недоступен. Проверьте синтез речи в настройках Android.");
                return;
            }
            ready=true;
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                public void onStart(String id) { playback(id,true);Log.i("JarvisVoice","speech started"); }
                @Override public void onRangeStart(String id,int start,int end,int frame){
                    main.post(()->{
                        if(closed || !id.equals(utterance))return;
                        events.mouth(.56f,.15f);
                        main.postDelayed(()->{if(!closed && id.equals(utterance))events.mouth(0,0);},95);
                    });
                }
                public void onDone(String id) { main.post(()->{
                    if(closed||!id.equals(utterance))return;
                    events.playing(false);Runnable done=afterSpeech;afterSpeech=null;if(done!=null)done.run();
                });Log.i("JarvisVoice","speech finished"); }
                public void onError(String id) { playback(id,false);Log.w("JarvisVoice","speech failed"); }
            });
            if (queued!=null) { String text=queued; queued=null; systemSay(text); }
        },engine);
    }
    void say(String text) {
        say(text,null);
    }
    void say(String text,Runnable done) {
        say(text,done,CoralDelivery.CONVERSATION);
    }
    void say(String text,Runnable done,CoralDelivery delivery) {
        afterSpeech=done;
        events.speakingText(text);
        utterance=UUID.randomUUID().toString();
        if(tts!=null)tts.stop();
        neural.say(delivery.forSpeech(text),delivery,new NeuralSpeech.Listener(){
            public void start(){events.playing(true);}
            public void mouth(float open,float round){events.mouth(open,round);}
            public void end(){events.playing(false);Runnable next=afterSpeech;afterSpeech=null;if(next!=null)next.run();}
            public void failed(){events.playing(false);systemSay(text);}
        });
    }
    private void systemSay(String text){
        if(ready){tts.setPitch(text.length()<=110?1.15f:1.07f);tts.setSpeechRate(text.length()<=110?1.09f:1.0f);tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,utterance);return;}
        queued=text;if(tts==null)startTts(null);
    }
    void stop() {
        neural.stop();queued=null;utterance=null;afterSpeech=null;events.playing(false);events.mic(AuraView.Mode.READY);
        if (tts!=null) tts.stop();
        if (recognizer!=null) { listening=false; recognizer.destroy(); recognizer=null; }
    }
    void listen() {
        if (listening) { recognizer.stopListening(); return; }
        stop();
        if (!SpeechRecognizer.isRecognitionAvailable(context)) { events.status("Распознавание речи недоступно. Можно ввести команду."); return; }
        recognizer=SpeechRecognizer.createSpeechRecognizer(context);
        recognizer.setRecognitionListener(this);
        Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ru-RU");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
        listening=true;events.mic(AuraView.Mode.LISTEN);
        events.status("Включаю микрофон…");
        recognizer.startListening(intent);
    }
    public void onReadyForSpeech(Bundle b) { events.status("Слушаю…"); Log.i("JarvisVoice","recognizer ready"); }
    public void onBeginningOfSpeech() {}
    public void onEndOfSpeech() { if(!listening)return;events.mic(AuraView.Mode.WORK);events.status("Распознаю…"); }
    public void onRmsChanged(float value) { if(listening)events.level(value); }
    public void onBufferReceived(byte[] buffer) {}
    public void onEvent(int type,Bundle b) {}
    public void onPartialResults(Bundle b) {}
    public void onError(int code) {
        if (!listening) return;
        listening=false;events.mic(AuraView.Mode.READY);
        Log.i("JarvisVoice","recognition error "+code);
        events.status(switch(code) {
            case SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Не расслышала. Скажите ещё раз?";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Для голосовых команд разрешите доступ к микрофону.";
            case SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Сервису распознавания нужна сеть или загруженный русский языковой пакет.";
            default -> "Распознавание сейчас недоступно ("+code+"). Повторите или введите команду.";
        });
    }
    public void onResults(Bundle b) {
        if (!listening) return;
        listening=false;events.mic(AuraView.Mode.READY);
        ArrayList<String> results=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (results!=null && !results.isEmpty()) events.recognized(results.get(0));
        else events.status("Повторите, пожалуйста. Я не расслышала.");
    }
    void close() { closed=true; stop(); neural.close(); if (tts!=null) tts.shutdown(); }
}
