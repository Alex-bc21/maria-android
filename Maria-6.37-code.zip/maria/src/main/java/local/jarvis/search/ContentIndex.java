package local.jarvis.search;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.os.*;
import com.googlecode.tesseract.android.TessBaseAPI;
import java.io.*;
import java.util.*;
import java.util.regex.*;

final class ContentIndex implements AutoCloseable {
    private final Context ctx;
    private final SQLiteDatabase db;
    private final ContentRequest request;
    private final Clip clip;
    private final VideoTour tour;
    private TessBaseAPI ocr;

    ContentIndex(Context ctx,ContentRequest request,long token) throws Exception {
        this(ctx,request,token,description->{});
    }
    ContentIndex(Context ctx,ContentRequest request,long token,java.util.function.Consumer<String> translated) throws Exception {
        this.ctx=ctx; this.request=request;
        tour=request.video()?VideoTour.parse(request.terms()):null;
        if(request.visual()) {
            String description=tour==null?PhotoSubject.english(ctx,request.terms(),token):"interior rooms of an apartment, living room, kitchen or bedroom";
            String detail=tour==null || tour.clue().isEmpty()?"":LocalAnswer.englishDescription(ctx,tour.detailText(),token);
            if(Thread.currentThread().isInterrupted()) throw new InterruptedException();
            translated.accept(description+(detail.isEmpty()?"":" · "+detail));
            clip=new Clip(ctx,description,detail,tour);
        } else clip=null;
        db=ctx.openOrCreateDatabase("content_index_v2",0,null);
        db.execSQL("CREATE TABLE IF NOT EXISTS features (uri TEXT PRIMARY KEY, stamp TEXT NOT NULL, value BLOB NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS pages (uri TEXT, page INTEGER, stamp TEXT, text TEXT, PRIMARY KEY(uri,page))");
    }
    private String[] key(PhoneSearch.Hit h){return new String[]{h.uri().toString(),h.stamp()};}
    PhoneSearch.Hit match(PhoneSearch.Hit h) throws Exception {return match(h,0);}
    PhoneSearch.Hit match(PhoneSearch.Hit h,long durationMillis) throws Exception {
        if(request.video()){
            String label=(h.path()+"/"+h.name()).toLowerCase(Locale.ROOT);
            if(tour==null && Arrays.stream(request.terms().split("\\s+")).allMatch(label::contains))return h.matched(1,-1,"По названию или папке");
            return matchVideo(h,durationMillis);
        }
        if(request.includeTextFiles() && h.mime().startsWith("text/")){
            try(var stream=ctx.getContentResolver().openInputStream(h.uri())){
                if(stream==null)return null;
                var reader=new java.io.InputStreamReader(stream,java.nio.charset.StandardCharsets.UTF_8);
                char[] buffer=new char[8192];
                String tail="",similar=null;
                int count;
                while((count=reader.read(buffer))!=-1){
                    if(Thread.currentThread().isInterrupted())throw new InterruptedException();
                    String part=tail+new String(buffer,0,count);
                    String excerpt=find(part,request.terms(),false);
                    if(excerpt!=null)return h.matched(1,-1,"В тексте · "+excerpt);
                    if(similar==null && typoCandidate(request.terms()))similar=find(part,request.terms(),true);
                    tail=part.substring(Math.max(0,part.length()-Math.max(512,request.terms().length()*2)));
                }
                return similar==null?null:h.matched(-1,-1,"Похожее написание · "+similar);
            }
        }
        if(request.lettering() || request.scan() && h.mime().startsWith("image/")){
            String excerpt=find(imageText(h),request.terms(),true);
            return excerpt==null?null:h.matched(1,-1,"Надпись · "+excerpt);
        }
        if(request.photo()) {
            byte[] blob=null;
            try (Cursor c=db.rawQuery("SELECT value FROM features WHERE uri=? AND stamp=?",key(h))) {
                if(c.moveToFirst()) blob=c.getBlob(0);
            }
            if(blob==null) {
                blob=clip.image(h.uri());
                db.execSQL("INSERT OR REPLACE INTO features VALUES(?,?,?)",new Object[]{h.uri().toString(),h.stamp(),blob});
            }
            double score=clip.score(blob);
            return score>=0.205 ? h.matched(score,-1,"По описанию") : null;
        }
        try(ParcelFileDescriptor fd=ctx.getContentResolver().openFileDescriptor(h.uri(),"r")) {
            if(fd==null) throw new IOException("PDF unavailable");
            try(PdfRenderer pdf=new PdfRenderer(fd)) {
                PhoneSearch.Hit similar=null;
                for(int i=0;i<pdf.getPageCount();i++) {
                    if(Thread.currentThread().isInterrupted()) throw new InterruptedException();
                    String page=pageText(h,pdf,i);
                    boolean scanned=page.startsWith("[OCR]\n");
                    String text=scanned?page.substring(6):page;
                    String location="Стр. "+(i+1)+(scanned?" · скан":"");
                    String excerpt=find(text,request.terms(),false);
                    if(excerpt!=null)return h.matched(1,i,location+" · "+excerpt);
                    if(similar==null && (scanned || typoCandidate(request.terms()))){
                        excerpt=find(text,request.terms(),true);
                        if(excerpt!=null)similar=h.matched(-1,i,location+" · похожее написание · "+excerpt);
                    }
                }
                return similar;
            }
        }
    }
    PhoneSearch.Hit matchDrivePoster(PhoneSearch.Hit h,Bitmap poster)throws Exception {
        byte[] vector=clip.embedding(poster);
        double score=clip.score(vector);
        if(tour!=null){
            score=contrast(score,clip.score(vector,clip.workplace));
            if(clip.detailQuery!=null)score=Math.min(score,clip.score(vector,clip.detailQuery));
        }
        return score>=0.205?h.matched(score,-1,"Похоже по миниатюре Google Диска"):null;
    }
    private PhoneSearch.Hit matchVideo(PhoneSearch.Hit hit,long duration) throws Exception {
        double best=-1,sceneSum=0,secondScene=-1,topScene=-1;
        int seen=0;
        long bestMillis=0;
        android.media.MediaMetadataRetriever retriever=null;
        try {
            if(duration<=0){
                retriever=new android.media.MediaMetadataRetriever();retriever.setDataSource(ctx,hit.uri());
                String value=retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION);
                if(value==null)return null;
                duration=Long.parseLong(value);
            }
            int samples=(int)Math.max(3,Math.min(21,Math.ceil(duration/15000.0)));
            // Tours often introduce the living room in the opening shot and cut back to it later.
            if(tour!=null)samples=(int)Math.max(5,Math.min(9,Math.ceil(duration/15000.0)));
            for(int i=0;i<samples;i++){
                int percent=samples==3?10+i*40:Math.round(100f*(i+.5f)/samples);
                if(tour!=null)percent=Math.round(96f*i/(samples-1));
                if(Thread.currentThread().isInterrupted())throw new InterruptedException();
                String frameKey=hit.uri()+(tour==null?"#frame-v1-":"#tour-sync-v2-")+percent;
                double red=0;
                byte[] vector;
                long millis;
                try(Cursor cursor=db.rawQuery("SELECT value FROM features WHERE uri=? AND stamp=?",new String[]{frameKey,hit.stamp()})){
                    if(cursor.moveToFirst()){
                        java.nio.ByteBuffer saved=java.nio.ByteBuffer.wrap(cursor.getBlob(0));
                        millis=saved.getLong();
                        if(tour!=null)red=saved.getDouble();
                        vector=new byte[saved.remaining()];
                        saved.get(vector);
                    }else{
                        if(retriever==null){retriever=new android.media.MediaMetadataRetriever();retriever.setDataSource(ctx,hit.uri());}
                        millis=duration*percent/100;
                        int mode=tour==null?android.media.MediaMetadataRetriever.OPTION_CLOSEST:android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC;
                        Bitmap frame=retriever.getScaledFrameAtTime(millis*1000,mode,320,320);
                        if(frame==null)continue;
                        try{vector=clip.embedding(frame);if(tour!=null)red=VideoTour.redFraction(frame);}finally{frame.recycle();}
                        var buffer=java.nio.ByteBuffer.allocate((tour==null?8:16)+vector.length).putLong(millis);
                        if(tour!=null)buffer.putDouble(red);
                        byte[] saved=buffer.put(vector).array();
                        db.execSQL("INSERT OR REPLACE INTO features VALUES(?,?,?)",new Object[]{frameKey,hit.stamp(),saved});
                    }
                }
                double scene=clip.score(vector);
                if(tour!=null)scene=contrast(scene,clip.score(vector,clip.workplace));
                double score=scene;
                seen++;sceneSum+=scene;
                if(scene>topScene){secondScene=topScene;topScene=scene;}else secondScene=Math.max(secondScene,scene);
                if(clip.detailQuery!=null){
                    score=clip.score(vector,clip.detailQuery);
                    if(clip.neutralFurniture!=null)score=contrast(score,clip.score(vector,clip.neutralFurniture));
                    // A little red in a frame supports a colour clue but cannot identify the object.
                    if(tour.needsRed())score+=Math.min(1,red/0.10)*0.045-0.025;
                }
                if(score>best){best=score;bestMillis=millis;}
            }
        } finally {if(retriever!=null)retriever.release();}
        if(tour!=null){
            if(seen<2 || secondScene<0.205)return null;
            double context=(secondScene+sceneSum/seen)/2;
            if(clip.detailQuery!=null && best<0.205)return null;
            double rank=clip.detailQuery==null?context:best*.75+context*.25;
            String why=clip.detailQuery==null?"Интерьер в нескольких кадрах":"Похожая примета";
            return hit.matched(rank,-1,String.format(Locale.ROOT,"%s · около %d:%02d",why,bestMillis/60000,bestMillis/1000%60)).withFrame(bestMillis,true);
        }
        return best>=0.205?hit.matched(best,-1,String.format(Locale.ROOT,"Похожий кадр около %d:%02d",bestMillis/60000,bestMillis/1000%60)).withFrame(bestMillis,false):null;
    }
    // Downrank ambiguous frames when the alternative description fits as well.
    private static double contrast(double wanted,double alternative){return wanted-Math.max(0,alternative-wanted+0.03);}
    String pageText(PhoneSearch.Hit h,PdfRenderer pdf,int i) throws IOException {
                    String page=null;
                    try(Cursor c=db.rawQuery("SELECT text FROM pages WHERE uri=? AND stamp=? AND page=?",new String[]{h.uri().toString(),h.stamp(),String.valueOf(i)})){
                        if(c.moveToFirst()) page=c.getString(0);
                    }
                    if(page==null) {
                        try(PdfRenderer.Page p=pdf.openPage(i)){page=readPage(p);}
                        db.execSQL("INSERT OR REPLACE INTO pages VALUES(?,?,?,?)",new Object[]{h.uri().toString(),i,h.stamp(),page});
                    }
        return page;
    }
    private static String words(String s) {
        return s.toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("(?<=\\p{L})-\\s*\\n\\s*(?=\\p{L})","")
                .replaceAll("[^\\p{L}\\p{N}]+"," ").strip();
    }
    static boolean typoCandidate(String terms){return terms.matches("\\p{L}{7,}");}
    private static boolean closeWord(String a,String b) {
        if(a.equals(b)) return true;
        if(a.length()<5 || b.length()<5 || Math.abs(a.length()-b.length())>1) return false;
        int i=0,j=0,edits=0;
        while(i<a.length() && j<b.length()){
            if(a.charAt(i)==b.charAt(j)){i++;j++;continue;}
            if(++edits>1) return false;
            if(a.length()>=b.length()) i++;
            if(b.length()>=a.length()) j++;
        }
        return edits+a.length()-i+b.length()-j<=1;
    }
    static String find(String text,String terms,boolean scanned) {
        String hay=words(text),needle=words(terms);
        if(needle.isEmpty()) return null;
        int pos=(" "+hay+" ").indexOf(" "+needle+" ");
        if(pos<0 && scanned) {
            String[] tokens=hay.split(" "), wanted=needle.split(" ");
            for(int i=0;i+wanted.length<=tokens.length;i++) {
                int j=0; while(j<wanted.length && closeWord(tokens[i+j],wanted[j])) j++;
                if(j==wanted.length) return String.join(" ",Arrays.copyOfRange(tokens,Math.max(0,i-3),Math.min(tokens.length,i+j+4)));
            }
        }
        if(pos<0) return null;
        return hay.substring(Math.max(0,pos-22),Math.min(hay.length(),pos+needle.length()+34));
    }
    private String readPage(PdfRenderer.Page page) throws IOException {
        StringBuilder text=new StringBuilder();
        if(Build.VERSION.SDK_INT>=35)
            for(var block:page.getTextContents()) text.append(block.getText()).append(' ');
        // A sparse native layer may be just a running header on a scanned page.
        if(text.toString().strip().length()>=40) return text.toString();
        prepareOcr();
        float scale=Math.min(3f,2300f/Math.max(page.getWidth(),page.getHeight()));
        Bitmap image=Bitmap.createBitmap(Math.max(1,Math.round(page.getWidth()*scale)),Math.max(1,Math.round(page.getHeight()*scale)),Bitmap.Config.ARGB_8888);
        try {
            image.eraseColor(Color.WHITE);
            page.render(image,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            ocr.setImage(image); String scanned=ocr.getUTF8Text();
            if(scanned!=null) text.append(' ').append(scanned);
        } finally { ocr.clear(); image.recycle(); }
        return "[OCR]\n"+text.toString();
    }
    String screenText(Bitmap b) throws IOException {
        prepareOcr();
        try{ocr.setImage(b);return Objects.toString(ocr.getUTF8Text(),"");}finally{ocr.clear();}
    }
    private void prepareOcr() throws IOException {
        if(ocr==null) {
            for(String lang:new String[]{"rus","ukr","eng"}) Clip.asset(ctx,"tessdata/"+lang+".traineddata");
            ocr=new TessBaseAPI();
            if(!ocr.init(new File(ctx.getFilesDir(),"content-v1").getPath(),"rus+ukr+eng")) throw new IOException("OCR unavailable");
            ocr.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO);
        }
    }
    String imageText(PhoneSearch.Hit hit) throws IOException {
        try(Cursor c=db.rawQuery("SELECT text FROM pages WHERE uri=? AND stamp=? AND page=-1",key(hit))){
            if(c.moveToFirst())return c.getString(0);
        }
        prepareOcr();
        Bitmap bitmap=ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.getContentResolver(),hit.uri()),(decoder,info,src)->{
            android.util.Size size=info.getSize();
            double scale=Math.min(1,2100.0/Math.max(size.getWidth(),size.getHeight()));
            decoder.setTargetSize(Math.max(1,(int)(size.getWidth()*scale)),Math.max(1,(int)(size.getHeight()*scale)));
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
        });
        String value;
        try{ocr.setImage(bitmap);value=ocr.getUTF8Text();}finally{ocr.clear();bitmap.recycle();}
        if(value==null)value="";
        db.execSQL("INSERT OR REPLACE INTO pages VALUES(?,?,?,?)",new Object[]{hit.uri().toString(),-1,hit.stamp(),value});
        return value;
    }
    public void close() {
        db.close(); if(ocr!=null) ocr.end();
        if(clip!=null) try {clip.close();} catch(Exception ignored){}
    }
}
