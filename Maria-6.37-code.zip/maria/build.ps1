param(
    [string]$Sdk = $env:ANDROID_HOME,
    [string]$Jdk = $env:JAVA_HOME,
    [string]$Keystore = (Join-Path $env:USERPROFILE '.android/debug.keystore'),
    [string]$Destination = (Join-Path $PSScriptRoot 'build')
)
$ErrorActionPreference = 'Stop'
function Invoke-BuildTool($Tool, [string[]]$Arguments) {
    & $Tool @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Tool failed ($LASTEXITCODE)" }
}
if (!$Sdk -or !$Jdk) { throw 'Set ANDROID_HOME and JAVA_HOME or supply -Sdk and -Jdk.' }
$bt = Join-Path $Sdk 'build-tools/36.0.0'
$platform = Join-Path $Sdk 'platforms/android-35/android.jar'
$java = Join-Path $Jdk 'bin/java.exe'
$src = Join-Path $PSScriptRoot 'src/main'
$stage = Join-Path $Destination ([guid]::NewGuid().ToString('N'))
$classes = Join-Path $stage 'classes'
$dex = Join-Path $stage 'dex'
New-Item -ItemType Directory -Path $classes,$dex -Force | Out-Null
$compiled = Join-Path $stage 'resources.zip'
$unsigned = Join-Path $stage 'unsigned.apk'
$aligned = Join-Path $stage 'aligned.apk'
$apk = Join-Path $Destination 'Jarvis-Search.apk'
Invoke-BuildTool "$bt/aapt2.exe" @('compile','--dir',"$src/res",'-o',$compiled)
Invoke-BuildTool "$bt/aapt2.exe" @('link','-o',$unsigned,'--manifest',"$src/AndroidManifest.xml",'-I',"$Sdk/platforms/android-37.0/android.jar",'--version-code','54','--version-name','6.37',$compiled)
$jars = @(Get-ChildItem "$PSScriptRoot/libs" -Filter '*.jar' | ForEach-Object FullName)
$classPath = (@($platform) + $jars) -join ';'
$sources = @(Get-ChildItem "$src/java" -Recurse -Filter '*.java' | ForEach-Object FullName)
Invoke-BuildTool "$Jdk/bin/javac.exe" (@('--release','17','-encoding','UTF-8','-classpath',$classPath,'-d',$classes) + $sources)
$bytecode = Join-Path $stage 'bytecode.jar'
Invoke-BuildTool "$Jdk/bin/jar.exe" @('cf',$bytecode,'-C',$classes,'.')
Invoke-BuildTool $java (@('-cp',"$bt/lib/d8.jar",'com.android.tools.r8.D8','--min-api','29','--lib',$platform,'--output',$dex,$bytecode) + $jars)
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::Open($unsigned,'Update')
try {
    foreach ($asset in Get-ChildItem "$src/assets" -File -Recurse) {
        $assetName='assets/'+[IO.Path]::GetRelativePath("$src/assets",$asset.FullName).Replace('\','/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$asset.FullName,$assetName,[IO.Compression.CompressionLevel]::Fastest) | Out-Null
    }
    foreach ($lib in Get-ChildItem "$src/jniLibs/arm64-v8a" -Filter '*.so') {
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$lib.FullName,("lib/arm64-v8a/"+$lib.Name)) | Out-Null
    }
    [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,"$dex/classes.dex",'classes.dex') | Out-Null }
finally { $archive.Dispose() }
Invoke-BuildTool "$bt/zipalign.exe" @('-f','4',$unsigned,$aligned)
Invoke-BuildTool $java @('-jar',"$bt/lib/apksigner.jar",'sign','--ks',$Keystore,'--ks-key-alias','androiddebugkey','--ks-pass','pass:android','--out',$apk,$aligned)
Invoke-BuildTool $java @('-jar',"$bt/lib/apksigner.jar",'verify',$apk)
Write-Output $apk
