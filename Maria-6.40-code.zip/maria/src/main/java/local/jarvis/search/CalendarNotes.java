package local.jarvis.search;

import android.Manifest;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Calendars;
import android.provider.CalendarContract.Events;
import android.provider.CalendarContract.Reminders;
import java.time.*;
import java.util.*;

final class CalendarNotes {
    static final int PERMISSION=217;
    private static final String MARKER="Напоминание создано Марией.";
    private static final String MATCH="calendar_id=? AND dtstart=? AND title=? AND description=? AND deleted=0";
    private final SearchActivity activity;
    private String title="";
    private long due;
    private LocalDate listDay;
    CalendarNotes(SearchActivity a){activity=a;}
    void saveState(Bundle b){b.putString("calendarNote",title);b.putLong("calendarDue",due);if(listDay!=null)b.putString("calendarDay",listDay.toString());}
    void restore(Bundle b){if(b!=null){title=b.getString("calendarNote","");due=b.getLong("calendarDue");if(b.containsKey("calendarDay"))listDay=LocalDate.parse(b.getString("calendarDay"));}}
    boolean allowed(String permission){return activity.checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED;}
    void add(String name,long when){
        listDay=null;title=name.strip();due=when;
        if(!allowed(Manifest.permission.READ_CALENDAR)||!allowed(Manifest.permission.WRITE_CALENDAR)){
            activity.requestPermissions(new String[]{Manifest.permission.READ_CALENDAR,Manifest.permission.WRITE_CALENDAR},PERMISSION);return;
        }
        permitted();
    }
    private record Calendar(long id,String name,String account,boolean primary){}
    void permitted(){
        if(title.isBlank()&&listDay==null)return;
        String note=title;long time=due;LocalDate day=listDay;title="";due=0;listDay=null;
        if(!allowed(Manifest.permission.READ_CALENDAR)||day==null&&!allowed(Manifest.permission.WRITE_CALENDAR)){
            activity.reply("Для работы с Google Календарём разрешите Марии доступ к календарю в настройках Android.");return;
        }
        if(!ScreenTask.unlocked(activity)||activity.isFinishing())return;
        var choices=new ArrayList<Calendar>();
        String[] columns={Calendars._ID,Calendars.CALENDAR_DISPLAY_NAME,Calendars.ACCOUNT_NAME,Calendars.IS_PRIMARY};
        try(Cursor c=activity.getContentResolver().query(Calendars.CONTENT_URI,columns,
                "account_type=? AND ownerAccount=account_name AND sync_events=1 AND visible=1 AND calendar_access_level>=?",new String[]{"com.google",String.valueOf(Calendars.CAL_ACCESS_OWNER)},"isPrimary DESC, _id ASC")){
            if(c==null)throw new IllegalStateException();
            while(c.moveToNext())choices.add(new Calendar(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3)!=0));
        }catch(RuntimeException e){activity.reply("Android не предоставил список календарей Google.");return;}
        if(choices.isEmpty()){activity.reply("В Android нет доступного для записи личного календаря Google с включённой синхронизацией.");return;}
        long saved=activity.getSharedPreferences("calendarNotes",0).getLong("id",-1);
        for(var cal:choices)if(cal.id==saved){use(cal,note,time,day);return;}
        String drive=DriveFiles.account(activity);
        var preferred=choices.stream().filter(c->c.primary && c.account.equalsIgnoreCase(drive)).findFirst();
        if(preferred.isPresent()){use(preferred.get(),note,time,day);return;}
        if(choices.size()==1){use(choices.get(0),note,time,day);return;}
        new AlertDialog.Builder(activity).setTitle("В какой Google Календарь добавлять напоминания?")
            .setItems(choices.stream().map(c->c.name+" · "+c.account).toArray(String[]::new),(dialog,i)->{
                var cal=choices.get(i);activity.getSharedPreferences("calendarNotes",0).edit().putLong("id",cal.id).apply();use(cal,note,time,day);
            }).setNegativeButton("Отмена",null).show();
    }
    private void use(Calendar cal,String note,long time,LocalDate day){
        if(!ScreenTask.unlocked(activity)||activity.isFinishing())return;
        if(day!=null){list(cal,day);return;}
        if(time<=System.currentTimeMillis()){activity.reply("Это время уже прошло. Назовите новое время.");return;}
        try{
            long id=store(activity.getContentResolver(),cal.id,note,time);
            activity.record("Google Календарь","Проверены событие "+id+" и уведомление в момент начала");
            ActionReceipt.remember(activity,"remind",note,time,"В Google Календаре «"+cal.name+"» сохранено «"+note+"» с уведомлением на");
            activity.reply(ActionReceipt.report(activity,"remind"));
        }catch(Exception e){
            activity.record("Google Календарь","Не удалось проверить запись · "+e.getClass().getSimpleName());
            activity.reply("Не удалось подтвердить событие с уведомлением. Проверьте запись в Google Календаре.");
        }
    }
    private record Event(long id,long calendar,String title,long start,long end){}
    private static final java.util.regex.Pattern CLOCK=java.util.regex.Pattern.compile("(?<![\\d:])(?:([01]?\\d|2[0-3])[:.]([0-5]\\d)|(?:на|в|с|из) ([01]?\\d|2[0-3])(?: час(?:а|ов)?)?)(?![\\d:.])");
    boolean moveRequest(String raw){
        String q=ActionReceipt.norm(raw).replace('\n',' ');
        if(!q.matches(".*\\b(?:перенеси|перенести|перенес[ие]м|передвинь|сдвинь)\\b.*") ||
                q.matches(".*\\b(?:файл|фото|папку|видео|будильник|таймер)\\b.*"))return false;
        var receipt=ActionReceipt.prefs(activity);
        boolean recent=recentReminder();
        if(!recent && !q.matches(".*(?:напоминани|просмотр|событи|встреч|задач|календар).*"))return false;
        if(q.matches(".*\\bне (?:нужно |надо )?(?:переноси|перенести|перенеси).*")){activity.reply("Оставила прежнее время.");return true;}
        if(q.matches(".*(?:на завтра|на сегодня|на послезавтра|на (?:понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье)|\\d[./]\\d[./]\\d).*")){
            activity.reply("Для смены даты откройте событие в Календаре. Я могу перенести его на другое время в тот же день.");return true;
        }
        var times=CLOCK.matcher(q);List<LocalTime> clocks=new ArrayList<>();
        while(times.find()){
            int hour=Integer.parseInt(times.group(1)==null?times.group(3):times.group(1));
            if(hour<12 && q.substring(times.end()).stripLeading().matches("^(?:дня|вечера)\\b.*"))hour+=12;
            clocks.add(LocalTime.of(hour,times.group(2)==null?0:Integer.parseInt(times.group(2))));
        }
        if(clocks.isEmpty() || clocks.size()>2){activity.askDetail(q,"На какое время перенести напоминание?");return true;}
        String words=CLOCK.matcher(q).replaceAll(" ").replaceAll("\\b(?:мария|мари|ну|вот|да|нет|не|я|ты|мне|пожалуйста|хочу|нужно|поставь|поставила|установила|наверное|где-то|перенеси|перенести|перенесем|передвинь|сдвинь|это|этот|эту|то|его|её|ее|только|что|сегодня|последнее|напоминание|событие|задачу|встречу|с|из|на|в|и|утра|дня|вечера|часов|часа|час)\\b"," ").replaceAll("\\s+"," ").strip();
        return move(words,clocks,recent,q);
    }
    boolean movePlan(String raw,String args){
        if(PhoneTasks.googleTasks(raw)){activity.reply("Эту задачу можно перенести в приложении Google Задачи. Я умею менять время созданных мной событий в Календаре.");return true;}
        String[] fields=args.split("\\|",-1);
        String question="Как называется напоминание и на какое время его перенести?";
        if(fields.length!=3){activity.askDetail(raw,question);return true;}
        String words=ActionReceipt.norm(fields[0]),q=ActionReceipt.norm(raw);
        boolean recent=recentReminder();
        if(words.equals("@last")){
            if(!recent){activity.askDetail(raw,"Как называется событие, которое нужно перенести?");return true;}
            words="";
        }else if(words.isEmpty() || !q.contains(words)){activity.askDetail(raw,question);return true;}
        words=words.replaceAll("\\bи\\b"," ").replaceAll("\\s+"," ").strip();
        List<LocalTime> clocks=new ArrayList<>();
        try{
            if(!fields[1].isBlank())clocks.add(LocalTime.parse(fields[1]));
            clocks.add(LocalTime.parse(fields[2]));
        }catch(java.time.DateTimeException invalid){activity.askDetail(raw,"На какое время перенести это событие?");return true;}
        if(!ActionReceipt.suppliedTime(q)){activity.askDetail(raw,"На какое время перенести это событие?");return true;}
        return move(words,clocks,recent,raw);
    }
    private boolean recentReminder(){
        var p=ActionReceipt.prefs(activity);
        return "remind".equals(p.getString("last","")) && System.currentTimeMillis()-p.getLong("remind_at",0)<600000;
    }
    private boolean move(String words,List<LocalTime> clocks,boolean recent,String q){
        var receipt=ActionReceipt.prefs(activity);
        if(!allowed(Manifest.permission.READ_CALENDAR)||!allowed(Manifest.permission.WRITE_CALENDAR)){
            activity.reply("Для переноса нужен доступ к календарю Android.");return true;
        }
        var zone=ZoneId.systemDefault();var r=activity.getContentResolver();
        List<Event> matches=new ArrayList<>();
        try(var c=r.query(Events.CONTENT_URI,new String[]{"_id","calendar_id","title","dtstart","dtend","rrule","rdate"},
                "description=? AND deleted=0 AND dtstart>=? AND account_type=? AND allDay=0",
                new String[]{MARKER,Long.toString(System.currentTimeMillis()),"com.google"},null)){
            if(c==null)throw new IllegalStateException();
            while(c.moveToNext()){
                String name=ActionReceipt.norm(c.getString(2)).replaceAll("\\bи\\b"," ").replaceAll("\\s+"," ").strip();
                if(words.isEmpty()){
                    if(!recent || !c.getString(2).equals(receipt.getString("remind_note","")) || c.getLong(3)!=receipt.getLong("remind_due",0))continue;
                }else if(!(" "+name+" ").contains(" "+words+" "))continue;
                if(clocks.size()==2 && !Instant.ofEpochMilli(c.getLong(3)).atZone(zone).toLocalTime().equals(clocks.get(0)))continue;
                if(c.getString(5)!=null || c.getString(6)!=null || c.isNull(4))continue;
                matches.add(new Event(c.getLong(0),c.getLong(1),c.getString(2),c.getLong(3),c.getLong(4)));
            }
        }catch(RuntimeException e){activity.reply("Не удалось прочитать события календаря.");return true;}
        if(matches.size()!=1){activity.askDetail(q,matches.isEmpty()?"Как точно называется будущее напоминание Марии в календаре?":"Есть несколько подходящих событий. Уточните название и прежнее время.");return true;}
        var e=matches.get(0);long when=Instant.ofEpochMilli(e.start).atZone(zone).toLocalDate().atTime(clocks.get(clocks.size()-1)).atZone(zone).toInstant().toEpochMilli();
        if(when<=System.currentTimeMillis()){activity.reply("Это время уже прошло.");return true;}
        try{
            var values=new ContentValues();values.put(Events.DTSTART,when);values.put(Events.DTEND,when+(e.end-e.start));
            var uri=ContentUris.withAppendedId(Events.CONTENT_URI,e.id);
            if(r.update(Events.CONTENT_URI,values,"_id=? AND dtend=? AND "+MATCH,new String[]{""+e.id,""+e.end,""+e.calendar,""+e.start,e.title,MARKER})!=1)throw new IllegalStateException();
            try(var c=r.query(uri,new String[]{"dtstart","dtend","deleted"},null,null,null)){
                if(c==null||!c.moveToFirst()||c.getLong(0)!=when||c.getLong(1)!=when+(e.end-e.start)||c.getInt(2)!=0)throw new IllegalStateException();
            }
            ActionReceipt.remember(activity,"remind",e.title,when,"В Google Календаре «"+e.title+"» перенесено на");
            activity.record("Перенос в календаре","ID "+e.id+" · "+ActionReceipt.stamp(e.start)+" → "+ActionReceipt.stamp(when));
            activity.reply(ActionReceipt.report(activity,"remind"));
        }catch(RuntimeException ex){activity.reply("Не удалось подтвердить перенос. Проверьте время в Google Календаре.");}
        return true;
    }
    private static synchronized long store(ContentResolver r,long cal,String note,long time) throws Exception{
        String[] args={Long.toString(cal),Long.toString(time),note,MARKER};
        long id=lookup(r,args);
        if(id<0){
            var values=new ContentValues();
            values.put(Events.CALENDAR_ID,cal);values.put(Events.TITLE,note);values.put(Events.DESCRIPTION,MARKER);
            values.put(Events.DTSTART,time);values.put(Events.DTEND,time+60000);
            values.put(Events.EVENT_TIMEZONE,ZoneId.systemDefault().getId());values.put(Events.AVAILABILITY,Events.AVAILABILITY_FREE);
            values.put(Events.HAS_ALARM,1);
            var ops=new ArrayList<ContentProviderOperation>();
            ops.add(ContentProviderOperation.newAssertQuery(Events.CONTENT_URI).withSelection(MATCH,args).withExpectedCount(0).build());
            ops.add(ContentProviderOperation.newInsert(Events.CONTENT_URI).withValues(values).build());
            ops.add(ContentProviderOperation.newInsert(Reminders.CONTENT_URI).withValueBackReference(Reminders.EVENT_ID,1)
                .withValue(Reminders.MINUTES,0).withValue(Reminders.METHOD,Reminders.METHOD_ALERT).build());
            r.applyBatch(CalendarContract.AUTHORITY,ops);id=lookup(r,args);
        }
        if(id<0)throw new IllegalStateException();
        try(Cursor c=r.query(Reminders.CONTENT_URI,new String[]{Reminders._ID},"event_id=? AND minutes=0 AND method=?",
                new String[]{Long.toString(id),Integer.toString(Reminders.METHOD_ALERT)},null)){
            if(c==null||!c.moveToFirst())throw new IllegalStateException();
        }
        return id;
    }
    private static long lookup(ContentResolver r,String[] args){
        try(Cursor c=r.query(Events.CONTENT_URI,new String[]{Events._ID},MATCH,args,null)){
            if(c==null)throw new IllegalStateException();return c.moveToFirst()?c.getLong(0):-1;
        }
    }
    static void open(SearchActivity a,LocalDate day){
        var notes=a.calendarNotes;notes.title="";notes.listDay=day==null?LocalDate.now():day;
        if(notes.allowed(Manifest.permission.READ_CALENDAR))notes.permitted();
        else a.requestPermissions(new String[]{Manifest.permission.READ_CALENDAR},PERMISSION);
    }
    private void list(Calendar cal,LocalDate day){
        var zone=ZoneId.systemDefault();
        var range=CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(range,day.atStartOfDay(zone).toInstant().toEpochMilli());
        ContentUris.appendId(range,day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()-1);
        var entries=new ArrayList<String>();
        try(Cursor c=activity.getContentResolver().query(range.build(),new String[]{"begin","title","allDay"},
                "calendar_id=? AND (eventStatus!=2 OR eventStatus IS NULL)",
                new String[]{Long.toString(cal.id)},"begin ASC")){
            if(c==null)throw new IllegalStateException();
            while(c.moveToNext()){
                String at=c.getInt(2)!=0?"Весь день":Instant.ofEpochMilli(c.getLong(0)).atZone(zone).toLocalTime().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
                entries.add(at+" · "+c.getString(1));
            }
            activity.reply("Google Календарь «"+cal.name+"», "+day+". "+(entries.isEmpty()?"Событий нет.":String.join("; ",entries)));
        }catch(RuntimeException e){activity.reply("Не удалось прочитать выбранный календарь Google.");}
    }
}
