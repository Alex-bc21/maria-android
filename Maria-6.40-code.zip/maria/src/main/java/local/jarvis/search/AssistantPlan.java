package local.jarvis.search;

import java.util.Locale;
import org.json.*;

/** Only typed operations cross the boundary from language understanding to Android. */
record AssistantPlan(Tool tool,String argument) {
    enum Tool { BATTERY, STORAGE, RAM, SCREEN, SCREEN_NUMBER, SCREEN_ROUTE, DOCUMENT, PHOTO, VIDEO, FILE, FILE_TEXT, APP, MAP, RESULT, DRAFT, REMINDERS, REMIND, MOVE_REMINDER, ALARM, CHECK_ALARM, SAVED_PHOTOS, MEDIA_PERIOD, LOCATION_PAUSE, LAST_ACTION, GOOGLE_ADD, GOOGLE_LIST, READ_SCREEN, NAVIGATE, TIMER, HISTORY, CLEANUP, CHAT, CLARIFY }
    static final String INSTRUCTIONS="""
        Classify the Russian user's intent for a phone assistant. Output exactly one line TOOL|argument. Never perform or explain an action.
        BATTERY = phone battery level; STORAGE = free disk space; RAM = free RAM. SCREEN = interpret, read or explain what is currently displayed, or give advice about something visible. DOCUMENT = question about an already opened document.
        PHOTO, VIDEO, FILE = locate personal media or a file; argument = search topic in Russian. APP = launch installed app, argument = original name or purpose. MAP = directions to a named place, argument = exact place from request. RESULT = open numbered result, argument = number starting at 1.
        CHAT = general knowledge, conversation, hypothetical question. CLARIFY = missing necessary details, unsupported action, or multiple different operations. Do not invent values. Use empty argument for tools without parameters.
        CHECK_ALARM = inspect the actual upcoming alarm. ALARM = create an alarm with an explicitly requested time.
        MOVE_REMINDER = change time of an existing calendar event on the same date. If previousActionType=remind, a correction can refer to it as @last. Argument: exact event name or @last, vertical bar, old HH:mm or empty, vertical bar, new HH:mm. Never invent a time.
        SAVED_PHOTOS = images added to the phone on a date; argument сегодня, вчера or ISO date. MEDIA_PERIOD = revise the preceding photo search date, e.g. all|google to remove date and use Google Photos. LOCATION_PAUSE = turn off location temporarily, argument number of seconds.
        NAVIGATE = directly operate current screen, argument direction|visible label, direction down/up/empty. Only an explicitly requested action, never a discussion.
        Examples: «Телефон скоро сядет?» -> BATTERY| ; «Есть куда сохранить большой фильм?» -> STORAGE| ; «О чём эта открытая страница?» -> SCREEN| ; «Как устроен аккумулятор?» -> CHAT| ; «Хочу посмотреть кадры с лошадьми из моей галереи» -> PHOTO|лошади ; «Сотри все сообщения» -> CLARIFY|
        """;
    static AssistantPlan online(String request,String available,String sealedKey,boolean document,int results) throws Exception {
        JSONArray tools=new JSONArray();
        for(Tool t:Tool.values()){
            if(t==Tool.DOCUMENT && !document || t==Tool.RESULT && results==0)continue;
            tools.put(t.name());
        }
        JSONObject properties=new JSONObject().put("tool",new JSONObject().put("type","string").put("enum",tools))
                .put("argument",new JSONObject().put("type","string"));
        JSONObject schema=new JSONObject().put("type","object").put("properties",properties).put("additionalProperties",false)
                .put("required",new JSONArray().put("tool").put("argument"));
        JSONObject format=new JSONObject().put("type","json_schema").put("name","phone_action").put("schema",schema).put("strict",true);
        JSONObject data=new JSONObject().put("request",request).put("available_context",available).put("local_date",java.time.LocalDate.now().toString());
        String instructions="Выбери инструмент для русскоязычного помощника на Android по смыслу запроса. "
                +"BATTERY, STORAGE, RAM — фактические показатели телефона, без аргумента. SCREEN — вопрос о содержимом текущего экрана, выборе кнопки или изображении. "
                +"SCREEN_NUMBER — скопировать видимый номер. SCREEN_ROUTE — маршрут к видимому адресу. DOCUMENT — вопрос по открытому PDF. "
                +"PHOTO и VIDEO — личные фото и видео по сюжету, аргумент описывает искомое на русском. FILE — поиск по названию; FILE_TEXT — поиск по тексту внутри файла. Сохрани детали поиска. "
                +"APP — открыть приложение, MAP — открыть маршрут до места. Для них верни дословное название или назначение из запроса. RESULT — открыть номер из текущей выдачи, аргумент целое число от 1. "
                +"DRAFT — подготовить выбранный файл в мессенджере, argument = имя адресата дословно из запроса, затем « в » и WhatsApp, Telegram, Viber или Plus. Если имя или мессенджер неизвестны, CLARIFY: сначала уточни недостающего получателя или мессенджер. Сам файл при необходимости даст выбрать Android. "
                +"CHECK_ALARM — узнать действующее состояние будильников в Android. MOVE_REMINDER — перенос времени существующего события в тот же день, в том числе поправка к только что созданному (например «давай лучше в час дня»). argument ровно название|старое HH:mm|новое HH:mm. Название дословно из слов пользователя; @last допустимо только при previousActionType=remind и отсылке к нему. Если старое время не названо, среднее поле пустое. Не придумывай время, дату или объект. Для другой даты запроси уточнение и объясни ограничение. При смене темы не используй предыдущий объект. Не создавай новое для переноса. Для напоминания без времени уточни время. "
                +"ALARM — разбудить, системный будильник в Часах: argument «завтра в HH:mm» или «в HH:mm». LAST_ACTION — вопрос об уже сделанном, argument alarm, google или remind. GOOGLE_ADD — создать именно Google Задачу, argument «завтра в HH:mm ; название»; GOOGLE_LIST — список Google Задач, argument today или tomorrow. READ_SCREEN — прочитать текст вслух, argument start или continue. REMINDERS — список напоминаний; REMIND — поставить задачу или напоминание в Google Календарь по умолчанию. GOOGLE_ADD только при прямом указании сервиса Google Tasks / Google Задачи. Для REMIND верни argument в формате «через N минут задача» или «завтра в HH:mm задача» или «yyyy-MM-dd в HH:mm задача» для конкретной даты, только с явно указанными временем и задачей. TIMER — установить таймер, argument целое число секунд от 1 до 86400, только при названной длительности. "
                +"SAVED_PHOTOS — пользователь ищет фото на телефоне по дате сохранения или загрузки, без описания сюжета; argument сегодня, вчера, позавчера, неделю или yyyy-MM-dd. MEDIA_PERIOD — поправка ТОЛЬКО периода предыдущего поиска медиа (mediaSearch=true), argument период|источник, например all|google, вчера|current. Не добавляй отменённый период к словам поиска. Если пользователь просит новый сюжет, выбери PHOTO/VIDEO. LOCATION_PAUSE — временно отключить общую геолокацию и включить обратно, argument число явно названных секунд от 1 до 3600. Учитывай отрицания и различай вопрос и поручение. "
                +"NAVIGATE — пользователь хочет взаимодействовать с уже открытым экраном. В argument ровно два поля через вертикальную черту: down или up или пусто, затем дословная подпись кнопки из слов пользователя или пусто. Это одна прокрутка, одно нажатие либо прокрутка и затем нажатие. Например «покажи, что там ниже по странице» → down|, «хочу заглянуть во вкладку Отзывы» → |Отзывы. Если непонятно где нажать или действие выходит за эти возможности, CLARIFY. Вопрос как что-то сделать — не разрешение нажимать. Чтение поста — READ_SCREEN, передача файла — DRAFT. "
                +"HISTORY — журнал Марии; CLEANUP — только посмотреть отчёт о дубликатах и мусоре. "
                +"CHAT — общий вопрос: дай краткий ответ в argument по-русски. Ты не имеешь текущих данных без инструмента. Не обещай действия. "
                +"CLARIFY — при неопределённости или отсутствии инструмента задай конкретный короткий вопрос либо объясни ограничение в argument. "
                +"Нет инструмента, собирающего остатки и долги сразу по банковским приложениям: объясни это, предложи выбрать выписку; SCREEN только для одного открытого экрана. Для вопроса о подтверждении действия выбирай LAST_ACTION. Не выбирай действие, которое пользователь отрицает или только обсуждает. Не придумывай аргументы или успешное выполнение. Учитывай уточнение, но при смене темы исполняй новый запрос.";
        JSONObject body=new JSONObject().put("model","gpt-4.1-mini").put("store",false).put("max_output_tokens",400)
                .put("instructions",instructions).put("input",data.toString()).put("text",new JSONObject().put("format",format));
        JSONObject chosen=new JSONObject(OpenAIResponses.text(body,sealedKey));
        Tool tool=Tool.valueOf(chosen.getString("tool"));String arg=chosen.getString("argument").strip();
        if(arg.length()>(tool==Tool.CHAT?1500:260) || arg.matches("(?s).*[\\p{Cc}&&[^\\n\\t]].*"))return clarify();
        return new AssistantPlan(tool,arg);
    }

    /** Resolve simple references against known device context when the network is unavailable. */
    static AssistantPlan contextual(String input,String context){
        String q=ActionReceipt.norm(input);
        boolean correction=q.matches("(?s).*(?:планы поменялись|вместо|лучше|передумал|пусть|давай|перенес|сдвин|передвин).*");
        boolean refers=q.matches("(?s).*\\b(?:это|его|ее|её|этот|эту|этом|того|тот же|то же)\\b.*");
        if(context.contains("previousActionType=remind") && correction && refers &&
                !q.matches("(?s).*(?:\\bне\\b|другую|новую|будильник|фото|файл|таймер|сообщени|на завтра|на сегодня|на послезавтра).*")){
            var clock=java.util.regex.Pattern.compile("(?:\\b(?:в|на)\\s+)?(\\d{1,2}(?::[0-5]\\d)?|час|два|три|четыре|пять|шесть|семь|восемь|девять|десять|одиннадцать|двенадцать)\\s*(утра|дня|вечера|ночи)?\\b").matcher(q);
            if(clock.find()){
                String token=clock.group(1),period=clock.group(2);
                String[] digits=token.split(":");int hour=Character.isDigit(token.charAt(0))?Integer.parseInt(digits[0]):java.util.List.of("","час","два","три","четыре","пять","шесть","семь","восемь","девять","десять","одиннадцать","двенадцать").indexOf(token);
                if(hour<12 && ("дня".equals(period)||"вечера".equals(period)))hour+=12;
                if(hour==12 && "ночи".equals(period))hour=0;
                if(hour<24 && !clock.find())return new AssistantPlan(Tool.MOVE_REMINDER,String.format(Locale.ROOT,"@last||%02d:%02d",hour,digits.length==2?Integer.parseInt(digits[1]):0));
            }
        }
        if(q.matches("(?s).*\\b(?:перенеси|перенести|передвинь|сдвинь)\\b.*") && !PhoneTasks.googleTasks(q) &&
            q.matches("(?s).*(?:напоминани|событи|просмотр|встреч).*"))return new AssistantPlan(Tool.MOVE_REMINDER,"");
        if(q.matches("(?s).*(?:во сколько|когда|проверь|сработает ли|установлен ли).*") && q.matches("(?s).*(?:разбуд|будильник).*"))return new AssistantPlan(Tool.CHECK_ALARM,"");
        if(context.contains("mediaSearch=true") && q.matches("(?s).*(?:за все время|сними ограничение по дате|дату убери|без привязки к дате).*") &&
                !q.matches("(?s)^(?:найди|поищи|ищи|покажи мне фото с).*"))
            return new AssistantPlan(Tool.MEDIA_PERIOD,"all|"+(q.matches("(?s).*(?:google|гугл)\\s*(?:фото|photos).*")?"google":"current"));
        return null;
    }
    static AssistantPlan parse(String line){
        if(line==null)return clarify();
        String[] fields=line.strip().split("\\|",2);
        if(fields.length!=2 || fields[1].length()>200 || line.strip().contains("\n"))return clarify();
        try{
            var tool=Tool.valueOf(fields[0].strip().toUpperCase(Locale.ROOT));
            String arg=fields[1].strip();
            if(arg.matches(".*[\\p{Cc}<>].*"))return clarify();
            return new AssistantPlan(tool,arg);
        }catch(IllegalArgumentException unknown){return clarify();}
    }
    static AssistantPlan clarify(){return new AssistantPlan(Tool.CLARIFY,"");}
}
