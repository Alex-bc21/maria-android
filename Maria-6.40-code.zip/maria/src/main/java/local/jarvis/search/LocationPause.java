package local.jarvis.search;

import android.app.*;
import android.content.*;
import android.location.LocationManager;
import android.os.*;
import android.provider.Settings;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;
import java.util.*;
import java.util.regex.*;

final class LocationPause {
    private static final Pattern REQUEST=Pattern.compile("(?iu)^(?:(?:мария|мари|пожалуйста)\\s+)*(?:отключи|выключи|отключить|выключить)\\s+(?:мне\\s+)?(?:gps|джи[ -]?пи[ -]?эс|геолокацию|локацию|местоположение|определение местоположения)\\s+(?:(?:и\\s+)?(?:потом\\s+|затем\\s+)?(?:включи|включить|верни)(?:\\s+(?:его|её|ее|обратно|назад|снова))*\\s+через|на)\\s+(\\d{1,4}|тридцать|тридцати|полминуты|десять|двадцать|одну|один|две|два|пять|пятнадцать|сорок|одну минуту)(?:\\s+(секунд[аыу]?|сек|с|минут[аыу]?|мин))?(?:\\s+и\\s+(?:(?:потом|затем)\\s+)?(?:включи|верни)(?:\\s+(?:его|её|ее|обратно|назад|снова))*)?[.!]?$");
    static int seconds(String q){
        Matcher m=REQUEST.matcher(q.strip().toLowerCase(Locale.ROOT).replaceAll("[,!?]"," ").replaceAll("\\s+"," ").strip());
        if(!m.matches())return 0;
        String n=m.group(1),unit=m.group(2);
        if(unit==null)return n.equals("полминуты")?30:n.equals("одну минуту")?60:0;
        int amount=switch(n){case "один","одну"->1;case "две","два"->2;case "пять"->5;case "десять"->10;case "пятнадцать"->15;case "двадцать"->20;case "тридцать","тридцати"->30;case "сорок"->40;default->n.matches("\\d+")?Integer.parseInt(n):0;};
        int seconds=amount*(unit.startsWith("мин")?60:1);
        return seconds>=1 && seconds<=3600?seconds:0;
    }

    private static final String SETTINGS="com.android.settings";
    private final ScreenTask service;
    private final SharedPreferences prefs;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable tick=this::advance;
    private long turn,limit;
    private int seconds;
    private boolean changing,enabling,pressed;
    LocationPause(ScreenTask s){service=s;prefs=s.getSharedPreferences("location_pause",Context.MODE_PRIVATE);}
    boolean changing(){return changing;}
    private boolean enabled(){return service.getSystemService(LocationManager.class).isLocationEnabled();}
    private Intent settings(){return new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);}
    boolean start(int secs,long id){
        if(changing || prefs.contains("due"))return false;
        turn=id;seconds=secs;open(false);return true;
    }
    private void report(String text){
        SearchJournal.get(service).add(turn,"Геолокация",text);
        Toast.makeText(service,text,Toast.LENGTH_SHORT).show();
    }
    private void open(boolean on){
        changing=true;enabling=on;pressed=false;limit=SystemClock.elapsedRealtime()+5500;
        service.locationEvents(true);
        try{service.startActivity(settings());later(220);}
        catch(RuntimeException e){failure();}
    }
    private void later(long ms){handler.removeCallbacks(tick);handler.postDelayed(tick,ms);}
    private void endStep(){changing=false;handler.removeCallbacks(tick);service.locationEvents(false);}
    void stop(){changing=false;handler.removeCallbacks(tick);if(prefs.contains("due") && !enabled())notifyOwner();}
    void resume(){
        if(changing || !prefs.contains("due"))return;
        turn=prefs.getLong("turn",0);
        long left=prefs.getLong("due",0)-System.currentTimeMillis();
        if(left>0){later(Math.min(left,3600000));return;}
        if(enabled()){done();return;}
        if(!ScreenTask.unlocked(service)){notifyOwner();return;}
        if(!service.screenIdle()){later(500);return;}
        open(true);
    }
    private void done(){
        prefs.edit().clear().commit();
        service.getSystemService(NotificationManager.class).cancel(638);
        report("Геолокация включена. Проверила состояние в Android.");
    }
    private void notifyOwner(){
        var nm=service.getSystemService(NotificationManager.class);
        String channel="location_restore";
        nm.createNotificationChannel(new NotificationChannel(channel,"Возврат геолокации",NotificationManager.IMPORTANCE_DEFAULT));
        var target=PendingIntent.getActivity(service,638,settings(),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        try{nm.notify(638,new Notification.Builder(service,channel).setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Геолокация ещё выключена").setContentText("Разблокируйте телефон. Нажмите, чтобы открыть настройки геолокации.")
            .setContentIntent(target).setOnlyAlertOnce(true).setAutoCancel(true).build());}catch(SecurityException ignored){}
    }
    private void failure(){
        boolean restore=prefs.contains("due");
        endStep();
        if(restore && enabled()){
            if(enabling){done();return;}
            prefs.edit().clear().commit();
            report("Android не подтвердил выключение. Геолокация включена.");return;
        }
        report(restore?"Android пока не подтвердил включение геолокации. Откройте настройки локации.":"Не нашла главный переключатель локации. Проверьте настройки.");
        if(restore){notifyOwner();if(!enabling)resume();}
    }
    private boolean saveRestore(long due){
        return prefs.edit().putLong("due",due).putLong("turn",turn).commit();
    }
    private void advance(){
        if(!changing){resume();return;}
        if(!ScreenTask.unlocked(service)){failure();return;}
        if(pressed && enabled()==enabling){
            if(enabling){endStep();done();return;}
            saveRestore(System.currentTimeMillis()+seconds*1000L);
            report("Геолокация выключена. Включу через "+seconds+" с.");endStep();resume();return;
        }
        if(SystemClock.elapsedRealtime()>=limit){failure();return;}
        if(!pressed){
            var root=service.getRootInActiveWindow();
            var control=locationSwitch(root);
            if(control!=null){
                if(enabled()==enabling){
                    if(enabling){endStep();done();return;}
                    if(!saveRestore(System.currentTimeMillis()+seconds*1000L)){failure();return;}
                    report("Геолокация уже выключена. Включу через "+seconds+" с.");endStep();resume();return;
                }
                if(!enabling && !saveRestore(System.currentTimeMillis()+seconds*1000L)){failure();return;}
                pressed=control.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                if(!pressed){failure();return;}
            }
        }
        later(120);
    }
    private AccessibilityNodeInfo locationSwitch(AccessibilityNodeInfo root){
        if(root==null || !SETTINGS.contentEquals(Objects.toString(root.getPackageName(),"")))return null;
        var rows=root.findAccessibilityNodeInfosByViewId(SETTINGS+":id/sesl_switchbar_container");
        if(rows.size()!=1)return null;
        var row=rows.get(0);
        if(!row.isVisibleToUser() || !row.isEnabled() || !row.isClickable())return null;
        String label=Objects.toString(row.getText(),"").strip().toLowerCase(Locale.ROOT);
        if(!Set.of("локация","местоположение","геолокация","location","розташування","місцезнаходження","локація").contains(label))return null;
        var switches=row.findAccessibilityNodeInfosByViewId(SETTINGS+":id/sesl_switchbar_switch");
        if(switches.size()!=1 || !switches.get(0).isCheckable() || switches.get(0).isChecked()!=enabled())return null;
        return row;
    }
}
