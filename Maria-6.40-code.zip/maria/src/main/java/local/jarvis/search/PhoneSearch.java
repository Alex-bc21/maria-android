package local.jarvis.search;

import android.content.ContentResolver;
import android.content.Context;
import android.content.ContentUris;
import android.content.UriPermission;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;
import android.provider.MediaStore;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

final class PhoneSearch {
    record Hit(String name, String path, String mime, Uri uri, long date, String stamp, double score, int page, String reason, Uri original, long frameMillis, boolean keyFrame) {
        Hit(String name,String path,String mime,Uri uri,long date,String stamp,double score,int page,String reason,Uri original){
            this(name,path,mime,uri,date,stamp,score,page,reason,original,-1,false);
        }
        Hit withFrame(long ms,boolean key){return new Hit(name,path,mime,uri,date,stamp,score,page,reason,original,ms,key);}
        Hit(String name,String path,String mime,Uri uri,long date,String stamp){this(name,path,mime,uri,date,stamp,0,-1,"",uri);}
        Hit matched(double score,int page,String reason){return new Hit(name,path,mime,uri,date,stamp,score,page,reason,original);}
    }
    interface Progress { void update(int examined,List<Hit> best); }
    private final ContentIndex index;
    private final Progress progress;
    private int examined;
    private long lastUpdate;
    record Result(List<Hit> hits, int count, int skipped, boolean hasSource, String notice) {}
    static final int DISPLAY_LIMIT = 100;
    static final Comparator<Hit> ORDER = Comparator.comparingDouble(Hit::score).reversed().thenComparing(Comparator.comparingLong(Hit::date).reversed())
            .thenComparing(Hit::name, String.CASE_INSENSITIVE_ORDER).thenComparing(h -> h.uri().toString());

    static final class Query {
        boolean images, videos, pdf, textDocuments, scans, documents;
        final boolean downloadedVideos,savedPhotos;
        long from, until = Long.MAX_VALUE;
        final List<String> words = new ArrayList<>();
        Query(String text) {
            downloadedVideos=text.startsWith("скачанные видео за ");
            savedPhotos=text.startsWith("сохраненные фото");
            if(savedPhotos)text=text.substring("сохраненные ".length());
            if(downloadedVideos)text=text.substring("скачанные ".length());
            LocalDate today = LocalDate.now();
            for (String word : text.toLowerCase(Locale.ROOT).trim().split("\\s+")) {
                switch (word) {
                    case "", "найди", "покажи", "файл", "файлы", "за", "мои", "мне", "все", "с", "названием", "именем" -> {}
                    case "скрин","скриншот","скриншоты","снимок","фото", "фотографии", "фотографию", "картинки" -> images = true;
                    case "видео","ролик","ролики","видеоролик" -> videos = true;
                    case "документ","документы" -> documents=true;
                    case "scan-text" -> scans=true;
                    case "document-text" -> textDocuments=true;
                    case "pdf", ".pdf", "пдф", "пэдээф" -> pdf = true;
                    case "сегодня" -> setDates(today, today.plusDays(1));
                    case "вчера" -> setDates(today.minusDays(1), today);
                    case "неделю" -> setDates(today.minusDays(6), today.plusDays(1));
                    default -> words.add(word);
                }
            }
        }
        private void setDates(LocalDate start, LocalDate end) {
            ZoneId zone = ZoneId.systemDefault();
            from = start.atStartOfDay(zone).toInstant().toEpochMilli();
            until = end.atStartOfDay(zone).toInstant().toEpochMilli();
        }
        void applyPeriod(String label){
            if(label.isEmpty())return;
            LocalDate now=LocalDate.now();
            if(label.matches("\\d{4}-\\d\\d-\\d\\d")){LocalDate day=LocalDate.parse(label);setDates(day,day.plusDays(1));return;}
            if(label.equals("позавчера")){setDates(now.minusDays(2),now.minusDays(1));return;}
            if(label.equals("вчера")){setDates(now.minusDays(1),now);return;}
            if(label.equals("сегодня")){setDates(now,now.plusDays(1));return;}
            if(label.equals("неделю")){setDates(now.minusDays(6),now.plusDays(1));return;}
            String[] months={"январ","феврал","март","апрел","ма","июн","июл","август","сентябр","октябр","ноябр","декабр"};
            for(int i=0;i<12;i++)if(label.startsWith(months[i])){
                String[] v=label.split(" ");int year=v.length>1?Integer.parseInt(v[1]):now.getYear()-(i+1>now.getMonthValue()?1:0);
                LocalDate date=LocalDate.of(year,i+1,1);setDates(date,date.plusMonths(1));return;
            }
        }
        boolean contractSearch(){
            return words.size()==1 && ("договор".equals(words.get(0)) || "договір".equals(words.get(0)));
        }
        boolean accepts(Hit h) {
            if(documents && !documentMime(h.mime()) && !documentMime(mimeForName(h.name())))return false;
            if (scans && !h.mime().startsWith("image/") && !h.mime().equals("application/pdf"))return false;
            if (textDocuments && !h.mime().startsWith("text/") && !h.mime().equals("application/pdf"))return false;
            if (videos && !h.mime().startsWith("video/")) return false;
            if (images && !h.mime().startsWith("image/")) return false;
            if (pdf && !h.mime().equals("application/pdf") && !h.name().toLowerCase(Locale.ROOT).endsWith(".pdf")) return false;
            String location = (h.path() + "/" + h.name()).toLowerCase(Locale.ROOT);
            boolean matches=contractSearch() ? location.contains("договор") || location.contains("договір") : words.stream().allMatch(location::contains);
            return h.date() >= from && h.date() < until && matches;
        }
    }

    private static final List<String> DOCUMENT_TYPES=List.of("application/pdf","application/rtf","application/msword","application/vnd.ms-excel","application/vnd.ms-powerpoint","application/epub+zip","application/vnd.google-apps.document","application/vnd.google-apps.spreadsheet","application/vnd.google-apps.presentation");
    private static final List<String> DOCUMENT_PREFIXES=List.of("text/","application/vnd.openxmlformats-officedocument.","application/vnd.oasis.opendocument.","application/vnd.ms-word.","application/vnd.ms-excel.","application/vnd.ms-powerpoint.");
    static boolean documentMime(String mime){
        if(mime==null)return false;
        for(String prefix:DOCUMENT_PREFIXES)if(mime.startsWith(prefix))return true;
        return DOCUMENT_TYPES.contains(mime);
    }
    static String driveDocumentFilter(){
        List<String> clauses=new ArrayList<>();
        for(String mime:DOCUMENT_TYPES)clauses.add("mimeType = '"+mime+"'");
        for(String prefix:DOCUMENT_PREFIXES)clauses.add("mimeType contains '"+prefix+"'");
        return "("+String.join(" or ",clauses)+")";
    }
    private static String mimeForName(String name){
        int dot=name.lastIndexOf('.');
        return dot<0?null:MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(dot+1).toLowerCase(Locale.ROOT));
    }
    static boolean allFiles(){return Build.VERSION.SDK_INT>=30 && Environment.isExternalStorageManager();}
    private final ContentResolver resolver;
    private final Context context;
    final Query query;
    boolean photosOnly,driveOnly,googlePhotosRequested;
    Set<String> matchedMedia;
    Set<String> within;
    private final Queue<Hit> top = new PriorityQueue<>(DISPLAY_LIMIT, ORDER.reversed());
    private final Set<String> visited = new HashSet<>();
    private final Set<String> mediaIds = new HashSet<>();
    private int count, skipped, checked;
    java.util.function.Consumer<String> trace=ignored->{};
    private String source="";
    private int startCount,startChecked,startSkipped;
    private long lastCheckpoint;
    private void source(String next){
        if(!source.isEmpty())trace.accept(summary());
        source=next;startCount=count;startChecked=checked;startSkipped=skipped;
        lastCheckpoint=android.os.SystemClock.elapsedRealtime();
        if(!next.isEmpty())trace.accept(next+" · начат поиск");
    }
    private String summary(){return source+" · просмотрено записей "+(checked-startChecked)+", совпадений "+(count-startCount)+", ошибок "+(skipped-startSkipped);}
    private void gallerySearch() throws InterruptedException {
        source(query.videos?"Видео телефона":"Изображения телефона");
        try{photos();}catch(RuntimeException error){skipped++;trace.accept(source+" · "+error.getClass().getSimpleName());}
    }
    private final ContentRequest contents;

    PhoneSearch(Context context, String text, ContentIndex index, Progress progress,ContentRequest contents) {
        this.contents=contents;
        this.index=index; this.progress=progress;
        this.context = context;
        this.resolver = context.getContentResolver();
        query = new Query(text);
    }
    Result run(boolean gallery) throws InterruptedException {
        try{return runSources(gallery);}
        finally{source("");}
    }
    private Result runSources(boolean gallery) throws InterruptedException {
        if(driveOnly){
            boolean connected=!DriveFiles.account(context).isEmpty();
            String notice=connected?driveSearch():"Подключите Google Диск в источниках Марии.";
            if(!connected)trace.accept("Google Диск · аккаунт не подключён");
            List<Hit> hits=new ArrayList<>(top);hits.sort(ORDER);
            return new Result(hits,count,skipped,connected,notice);
        }
        List<UriPermission> folders = resolver.getPersistedUriPermissions();
        if (!photosOnly && gallery && !query.pdf && !query.textDocuments && !query.documents && !query.scans) {
            gallerySearch();
        }
        if(!gallery && (query.images || query.videos || query.scans))trace.accept("Медиатека · доступ отсутствует");
        if(query.downloadedVideos || query.savedPhotos){
            List<Hit> local=new ArrayList<>(top);
            local.sort(ORDER);
            return new Result(local,count,skipped,gallery,"");
        }
        boolean checkDocuments=!photosOnly && !query.images && !query.videos;
        boolean includeDrive=!photosOnly && !googlePhotosRequested;
        boolean drive=includeDrive && !DriveFiles.account(context).isEmpty();
        String notice="";
        boolean driveFirst=checkDocuments && contents!=null && drive;
        if(driveFirst)notice=driveSearch();
        if(checkDocuments)sharedDocuments();
        for (UriPermission p : folders) {
            if (!photosOnly && p.isReadPermission() && DocumentsContract.isTreeUri(p.getUri())) {
                if(googlePhotosRequested && SelectedItems.DRIVE.equals(SelectedItems.source(context,p.getUri())))continue;
                source("Папка · "+DocumentsContract.getTreeDocumentId(p.getUri()));
                try { folder(p.getUri()); } catch (RuntimeException unavailable) { skipped++; }
            }
        }
        source("Добавленные файлы и снимки");
        List<Hit> selected=SelectedItems.list(context);
        for(Hit item:selected){checkCancelled();if(!photosOnly||SelectedItems.PHOTOS.equals(item.path()))add(item);}
        if(query.scans && gallery && !photosOnly){
            gallerySearch();
        }
        if(drive && !driveFirst)notice=driveSearch();
        else if(includeDrive && !drive && !query.images)notice="Поиск по всему Google Диску не подключён.";
        if(includeDrive && !drive)trace.accept("Google Диск · аккаунт не подключён");
        if(!googlePhotosRequested && query.images && selected.stream().noneMatch(h->SelectedItems.PHOTOS.equals(h.path())))notice+=(notice.isEmpty()?"":" ")+"Снимки Google Фото ещё не добавлены.";
        if(photosOnly)notice="Источник: добавленные снимки Google Фото.";
        List<Hit> hits = new ArrayList<>(top);
        hits.sort(ORDER);
        return new Result(hits,count,skipped,checkDocuments || !folders.isEmpty() || !selected.isEmpty() || drive || gallery,notice);
    }
    private String driveSearch() throws InterruptedException {
            source("Google Диск");
            if(progress!=null){List<Hit> partial=new ArrayList<>(top);partial.sort(ORDER);progress.update(examined,partial);}
            try{
                Set<String> indexed=new HashSet<>();
                DriveFiles.search(context,query,contents,Integer.MAX_VALUE,trace,item->{checked++;if((within==null||within.contains(item.uri().toString()))&&item.date()>=query.from && item.date()<query.until){
                    if(driveOnly && !query.words.isEmpty()){
                        String name=item.name().toLowerCase(Locale.ROOT);
                        boolean inName=query.words.stream().allMatch(name::contains);
                        item=item.matched(inName?1:0,-1,inName?"Совпадение в названии":"По индексу Google Диска");
                    }
                    if(contents!=null && contents.visual())indexed.add(item.uri().toString());
                    rank(item);
                }publishProgress();});
                if(index!=null && contents!=null && contents.visual() && (driveOnly || query.from>0 || query.until<Long.MAX_VALUE))
                    return drivePosters(indexed);
                if(driveOnly && contents!=null && contents.visual() && index==null){
                    String notice="Проверен индекс Диска. На телефоне не удалось запустить сравнение миниатюр.";
                    trace.accept(notice);return notice;
                }
            }catch(InterruptedException cancel){throw cancel;}
            catch(Exception error){
                skipped++;trace.accept("Google Диск · "+DriveFailure.code(error));
                return DriveFailure.notice(error);
            }
            return "";
    }
    private String drivePosters(Set<String> indexed)throws Exception {
        List<Hit> recent=new ArrayList<>();
        DriveFiles.search(context,query,null,30,trace,recent::add);
        int decoded=0,failed=0;
        for(Hit item:recent){
            checkCancelled();
            String key=item.uri().toString();
            if(indexed.contains(key) || within!=null && !within.contains(key))continue;
            checked++;
            try{
                android.graphics.Bitmap bitmap=DriveFiles.thumbnail(context,item.uri());
                if(bitmap==null){failed++;continue;}
                try{
                    Hit match=index.matchDrivePoster(item,bitmap);
                    if(match!=null)rank(match);
                    decoded++;
                }finally{bitmap.recycle();}
            }catch(DriveFailure.Http unavailable){
                if(unavailable.status!=403 && unavailable.status!=404 && unavailable.status!=410)throw unavailable;
                failed++;
            }catch(java.io.FileNotFoundException | android.graphics.ImageDecoder.DecodeException unreadable){failed++;}
            publishProgress();
        }
        String notice="Google Диск · проверено миниатюр: "+decoded+" (до 30 последних файлов по дате изменения).";
        if(failed>0)notice+=" Без доступной миниатюры: "+failed+".";
        trace.accept(notice);return notice;
    }
    private void add(Hit hit) throws InterruptedException {add(hit,0);}
    private void add(Hit hit,long duration) throws InterruptedException {
        checked++;
        long now=android.os.SystemClock.elapsedRealtime();
        if(now-lastCheckpoint>=30000){trace.accept(summary()+" · поиск продолжается");lastCheckpoint=now;}
        if(within!=null&&!within.contains(hit.uri().toString()))return;
        if (!query.accepts(hit)) return;
        if(index!=null) {
            try { hit=index.match(hit,duration); }
            catch (InterruptedException e) { throw e; }
            catch (Exception e) {
                if(skipped==startSkipped)trace.accept(source+" · ошибка чтения "+e.getClass().getSimpleName());
                if(skipped==0) android.util.Log.w("JarvisContent","Skipped file: "+e.getClass().getSimpleName());
                skipped++; hit=null;
            }
            examined++;
        }
        if(hit!=null)rank(hit);
        publishProgress();
    }
    private void publishProgress(){
        if(progress!=null && android.os.SystemClock.elapsedRealtime()-lastUpdate>=1300) {
            lastUpdate=android.os.SystemClock.elapsedRealtime();
            List<Hit> best=new ArrayList<>(top); best.sort(ORDER);
            progress.update(examined,best);
        }
    }
    private void rank(Hit hit){if(matchedMedia!=null)matchedMedia.add(hit.uri().toString());count++;top.add(hit);if(top.size()>DISPLAY_LIMIT)top.remove();}
    private static void checkCancelled() throws InterruptedException {
        if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
    }
    private void sharedDocuments() throws InterruptedException {
        if(allFiles()){
            for(StorageVolume v:context.getSystemService(StorageManager.class).getStorageVolumes()){
                File root=v.getDirectory();
                if(root==null || !(Environment.MEDIA_MOUNTED.equals(v.getState()) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(v.getState())))continue;
                source("Общая память · "+v.getDescription(context));
                walkDocuments(root,v.isPrimary()?"primary":v.getUuid());
            }
        }else{
            source("Документы в системном каталоге Android · ограниченный доступ");
            for(String volume:MediaStore.getExternalVolumeNames(context)){
                Uri base=MediaStore.Files.getContentUri(volume);
                String[] cols={"_id","_display_name","relative_path","mime_type","date_modified","_size"};
                try(Cursor c=resolver.query(base,cols,"media_type IN (0,6) AND is_pending=0",null,null)){
                    if(c==null){skipped++;continue;}
                    while(c.moveToNext()){
                        checkCancelled();
                        String name=c.getString(1),path=c.getString(2),mime=c.getString(3);
                        if(name==null)continue;
                        if(!documentMime(mime))mime=mimeForName(name);
                        if(!documentMime(mime))continue;
                        if(path==null)path="";
                        String storage=MediaStore.VOLUME_EXTERNAL_PRIMARY.equals(volume)?"primary":volume;
                        if(!mediaIds.add((storage+":"+path+name).toLowerCase(Locale.ROOT)))continue;
                        add(new Hit(name,path,mime,ContentUris.withAppendedId(base,c.getLong(0)),c.getLong(4)*1000,c.getLong(4)+"/"+c.getLong(5)));
                    }
                }catch(RuntimeException unavailable){skipped++;trace.accept("Каталог Android · "+unavailable.getClass().getSimpleName());}
            }
        }
    }
    private void walkDocuments(File root,String volume) throws InterruptedException {
        Deque<File> pending=new ArrayDeque<>();pending.push(root);
        while(!pending.isEmpty()){
            checkCancelled();
            File dir=pending.pop();
            String path=root.toPath().relativize(dir.toPath()).toString();
            File[] entries=dir.listFiles();
            if(entries==null){skipped++;continue;}
            for(File file:entries){
                checkCancelled();
                String name=file.getName();
                if(Files.isSymbolicLink(file.toPath()))continue;
                if(file.isDirectory()){
                    if(path.equalsIgnoreCase("Android") && (name.equalsIgnoreCase("data") || name.equalsIgnoreCase("obb")))continue;
                    pending.push(file);continue;
                }
                if(name.startsWith(".trashed-") || name.startsWith(".pending-"))continue;
                String mime=mimeForName(name);
                if(!documentMime(mime) || !file.isFile() || !file.canRead())continue;
                String relative=path.isEmpty()?name:path+"/"+name;
                if(!mediaIds.add((volume+":"+relative).toLowerCase(Locale.ROOT)))continue;
                long time=file.lastModified();
                add(new Hit(name,path.isEmpty()?"/":path,mime,Uri.fromFile(file),time,time+"/"+file.length()));
            }
        }
    }
    private void photos() throws InterruptedException {
        for (String volume : MediaStore.getExternalVolumeNames(context)) {
            Uri base = query.videos ? MediaStore.Video.Media.getContentUri(volume) : MediaStore.Images.Media.getContentUri(volume);
            String[] columns = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.RELATIVE_PATH,
                    MediaStore.Images.Media.DATE_TAKEN, MediaStore.Images.Media.DATE_MODIFIED, MediaStore.Images.Media.SIZE};
            String selection=null;
            String[] args=null;
            boolean visualVideo=contents!=null && contents.video() && !query.downloadedVideos;
            if(visualVideo){
                columns=Arrays.copyOf(columns,8);columns[7]=MediaStore.Video.VideoColumns.DURATION;
            }
            if(query.downloadedVideos || query.savedPhotos){
                columns=Arrays.copyOf(columns,9);
                columns[7]=MediaStore.MediaColumns.DATE_ADDED;
                columns[8]=MediaStore.MediaColumns.IS_DOWNLOAD;
                selection="date_added >= ? AND date_added < ?";
                args=new String[]{Long.toString(query.from/1000),Long.toString(query.until/1000)};
            }
            try (Cursor c = resolver.query(base, columns, selection, args, "date_modified DESC")) {
                if (c == null) { skipped++; continue; }
                while (c.moveToNext()) {
                    checkCancelled();
                    String name = c.getString(1), path = c.getString(3);
                    if (name == null) continue;
                    if (path == null) path = "";
                    String storage = volume.equals(MediaStore.VOLUME_EXTERNAL_PRIMARY) ? "primary" : volume;
                    String id = storage + ":" + path + name;
                    if(!mediaIds.add(id.toLowerCase(Locale.ROOT)) && query.scans)continue;
                    long date = c.getLong(4);
                    if(query.downloadedVideos || query.savedPhotos){
                        if(query.downloadedVideos && !downloadLocation(path,c.getInt(8)!=0))continue;
                        date=c.getLong(7)*1000;
                    }
                    add(new Hit(name, path, c.isNull(2) ? (query.videos ? "video/*" : "image/*") : c.getString(2),
                            ContentUris.withAppendedId(base, c.getLong(0)), date > 0 ? date : c.getLong(5)*1000,c.getLong(5)+"/"+c.getLong(6)),visualVideo?c.getLong(7):0);
                }
            }
        }
    }
    static boolean downloadLocation(String folder,boolean markedDownload){
        String p="/"+folder.toLowerCase(Locale.ROOT)+"/";
        if(p.contains("/dcim/camera/") || p.contains("/sent/") || p.contains("/.statuses/"))return false;
        return markedDownload || p.contains("/download/") || p.contains("/downloads/")
                || p.contains("/movies/telegram/") || p.contains("/telegram video/")
                || p.contains("/movies/viber/") || p.contains("/viber/media/viber videos/")
                || p.contains("/whatsapp video/") || p.contains("/whatsapp business video/");
    }
    private record Dir(String id, String path) {}
    private void folder(Uri tree) throws InterruptedException {
        String root = DocumentsContract.getTreeDocumentId(tree);
        Deque<Dir> dirs = new ArrayDeque<>();
        dirs.add(new Dir(root, root.substring(root.lastIndexOf(':') + 1)));
        String[] columns = {Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME,
                Document.COLUMN_MIME_TYPE, Document.COLUMN_LAST_MODIFIED,Document.COLUMN_SIZE};
        while (!dirs.isEmpty()) {
            checkCancelled();
            Dir dir = dirs.removeFirst();
            if (!visited.add(tree.getAuthority() + "/" + dir.id())) continue;
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, dir.id());
            try (Cursor c = resolver.query(children, columns, null, null, null)) {
                if (c == null) { skipped++; continue; }
                while (c.moveToNext()) {
                    checkCancelled();
                    String id = c.getString(0), name = c.getString(1), mime = c.getString(2);
                    if (id == null || name == null || mime == null) continue;
                    if (Document.MIME_TYPE_DIR.equals(mime)) {
                        dirs.addLast(new Dir(id, dir.path() + "/" + name));
                    } else if (!"com.android.externalstorage.documents".equals(tree.getAuthority())
                            || !mediaIds.contains(id.toLowerCase(Locale.ROOT))) {
                        if(query.scans && "com.android.externalstorage.documents".equals(tree.getAuthority()))
                            mediaIds.add(id.toLowerCase(Locale.ROOT));
                        add(new Hit(name, dir.path(), mime, DocumentsContract.buildDocumentUriUsingTree(tree,id), c.getLong(3),c.getLong(3)+"/"+c.getLong(4)));
                    }
                }
            } catch (RuntimeException unavailable) { skipped++; }
        }
    }
}
