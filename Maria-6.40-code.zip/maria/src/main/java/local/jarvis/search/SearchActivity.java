package local.jarvis.search;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.*;
import android.provider.DocumentsContract;
import java.util.concurrent.atomic.AtomicLong;
import android.view.*;
import android.view.inputmethod.*;
import android.widget.*;
import java.text.DateFormat;
import java.util.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.concurrent.*;

public class SearchActivity extends Activity {
    private static final int GALLERY=10, TREE=11, MIC=12, ACCOUNT=13, PICK_PHOTO=14, PICK_FILE=15;
    
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private Future<?> pending;
    private int generation;
    private long activeNativeToken;
    private EditText field;
    private TextView status;
    private GridView list;
    private LinearLayout page;

    private static final AtomicLong sequence=new AtomicLong();
    private Voice speech;
    private SearchJournal journal;
    private long turn,voiceTurn;
    String lastAppQuery="";
    void record(String kind,String detail){journal.add(turn,kind,detail);}
    FileActions files;
    private PhoneCleanup cleanup;
    private boolean hasSearch;
    private List<PhoneSearch.Hit> hits=Collections.emptyList();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        if(Build.VERSION.SDK_INT>=31)getWindow().setHideOverlayWindows(true);
        restoreAfterUnlock=state;
        if(Build.VERSION.SDK_INT>=33)registerReceiver(screenOff,new IntentFilter(Intent.ACTION_SCREEN_OFF),Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(screenOff,new IntentFilter(Intent.ACTION_SCREEN_OFF));
        screenOffRegistered=true;
        var keyguard=getSystemService(android.app.KeyguardManager.class);
        if(keyguard.isDeviceSecure() && ScreenTask.unlocked(this) && !manuallyLocked()){
            restoreAfterUnlock=null;initialize(state);
        }else showLock();
    }
    private static final int OWNER=164;
    private Bundle restoreAfterUnlock;
    private boolean confirming,screenOffRegistered;
    private boolean resumed;
    final CalendarNotes calendarNotes=new CalendarNotes(this);
    private boolean manuallyLocked(){return getSharedPreferences("settings",0).getBoolean("manualLock",false);}

    private final BroadcastReceiver screenOff=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){
            confirming=false;
            if(speech!=null)speech.stop();
            finish();
        }
    };
    private void showLock(){
        Studio style=new Studio(this);
        LinearLayout lock=style.column();lock.setGravity(Gravity.CENTER);lock.setPadding(style.dp(24),0,style.dp(24),0);
        lock.setBackgroundColor(Studio.BG);setContentView(lock);
        lock.addView(style.text("Мария заблокирована",26,Studio.TEXT,true));
        style.gap(lock,14);
        boolean secure=getSystemService(android.app.KeyguardManager.class).isDeviceSecure();
        TextView hint=style.text(secure?"Подтвердите вход средствами Android.":"Сначала настройте PIN, пароль или графический ключ в настройках блокировки телефона.",16,Studio.MUTED,false);
        hint.setGravity(Gravity.CENTER);lock.addView(hint);style.gap(lock,22);
        TextView enter=style.text("Открыть Марию",17,Studio.BG,true);enter.setGravity(Gravity.CENTER);
        enter.setBackground(style.surface(Studio.MINT,18,0));lock.addView(enter,style.lp(-1,52));
        style.action(enter,"Открыть Марию",this::requestOwner);
    }
    private void requestOwner(){
        if(confirming || isFinishing())return;
        android.app.KeyguardManager keyguard=getSystemService(android.app.KeyguardManager.class);
        Intent confirm=keyguard.createConfirmDeviceCredentialIntent("Мария","Открыть личный помощник");
        if(confirm==null){
            Toast.makeText(this,"Настройте блокировку экрана в Android",Toast.LENGTH_LONG).show();
            return;
        }
        confirming=true;
        try{startActivityForResult(confirm,OWNER);}
        catch(ActivityNotFoundException | SecurityException unavailable){
            confirming=false;
            Toast.makeText(this,"Android не смог подтвердить владельца",Toast.LENGTH_LONG).show();
        }
    }
    void authorizeScreen(String pkg,String description,Runnable run){
        if(page==null || !resumed || confirming || manuallyLocked() || isFinishing() || !ScreenTask.unlocked(this))return;
        record("Действие на экране",pkg+" · "+description);
        run.run();
    }
    private void initialize(Bundle state){
        calendarNotes.restore(state);
        journal=SearchJournal.get(this);
        files=new FileActions(this);files.restore(state);cleanup=new PhoneCleanup(this);
        book=new ObjectsBook(this);promises=new PromiseDialog(this);showingNotes=new ShowingNotes(this);promiseActions=new PromiseActions(this);Promises.recover(this);
        buildScreen();
        speech=new Voice(this,new Voice.Events(){
            public void speakingText(String text){greetingOnPlayback=text.startsWith("Привет!") || text.startsWith("Привет-привет!");record("Синтез речи",text);}
            public void status(String message){
                if(micMode!=AuraView.Mode.READY){heroTitle.setText(message);if(inResults)feedback(message);else record("Микрофон",message);}
                else feedback(message);
            }
            public void mic(AuraView.Mode mode){micMode=mode;refreshVoice();if(mode==AuraView.Mode.READY)heroTitle.setText("Чем помочь?");}
            public void level(float value){aura.level(value);smallAvatar.level(value);}
            public void mouth(float open,float round){aura.mouth(open,round);smallAvatar.mouth(open,round);}
            public void playing(boolean value){
                speaking=value;refreshVoice();
                if(value && greetingOnPlayback){aura.greet();smallAvatar.greet();}
                greetingOnPlayback=false;
            }
            public void recognized(String text){field.setText(text);dispatch(true);}
        });
        if(getSharedPreferences("settings",0).getBoolean("charge",true))ChargeIndex.schedule(this);
        String action=getIntent().getAction();
        if(state==null && "local.jarvis.TASK_RECEIPT".equals(action)){taskResult(getIntent());return;}
        if(ScreenItem.ACTION.equals(action)){
            if(state==null){acceptScreen(getIntent());return;}
            if(getLastNonConfigurationInstance() instanceof ScreenItem retained &&
                    SystemClock.elapsedRealtime()-retained.created<300000){
                screenItem=retained;
                if(this instanceof AssistPanel panel && retained.uri!=null)
                    panel.source(ScreenItem.displayName(this,retained.uri));
            }
        }
        if(state==null && (Intent.ACTION_SEND.equals(action)||Intent.ACTION_SEND_MULTIPLE.equals(action))){receiveShare(getIntent());return;}
        if(state==null && "local.jarvis.MIC".equals(action)){page.post(this::voice);return;}
        if(state==null && "local.jarvis.REMINDERS".equals(action)){Reminder.list(this);return;}
        if(state==null && "local.jarvis.OBJECT".equals(action)){String name=getIntent().getStringExtra("object");if(name!=null)book.show(name);return;}
        String supplied=getIntent().getStringExtra(SearchManager.QUERY);
        if(state!=null&&state.getBoolean("todayOpen")){page.post(()->showToday(false));return;}
        if(state==null && "local.jarvis.RESULTS".equals(action)&&supplied!=null){field.setText(supplied);search(supplied,false,false);return;}
        if(promises.pending() && (action==null||Intent.ACTION_MAIN.equals(action)||state!=null)){page.post(promises::ask);return;}
        if(showingNotes.pending()&&(action==null||Intent.ACTION_MAIN.equals(action)||state!=null)){page.post(showingNotes::edit);return;}
        if(state!=null){
            photosOnly=state.getBoolean("photosOnly");lastQuery=state.getString("last","");dateFilter=state.getString("period","");
            noteObject=state.getString("note","");book.current=state.getString("object","");
            String uri=state.getString("contract");
            if(uri!=null)contract=new PhoneSearch.Hit(state.getString("docName"),"", "application/pdf",Uri.parse(uri),0,state.getString("stamp"),0,-1,"",Uri.parse(state.getString("original",uri)));
            if(contract!=null){
                citationDocument=contract.uri()+"\n"+contract.stamp();lastContractTurn=state.getString("contractTurn","");
                ArrayList<String> labels=state.getStringArrayList("contractQuotes");int[] numbers=state.getIntArray("contractPages");
                if(labels!=null&&numbers!=null&&labels.size()==numbers.length){
                    List<PhoneSearch.Hit> restored=new ArrayList<>();
                    for(int i=0;i<numbers.length;i++)restored.add(contract.matched(1,numbers[i],labels.get(i)));
                    showItems(restored);
                }
            }
        }
        if (state!=null) field.setText(state.getString("query",""));
        else if (Intent.ACTION_SEARCH.equals(getIntent().getAction()) && supplied!=null) field.setText(supplied);
        if (state!=null) {

            if(state.getBoolean("results")) feedback(state.getString("message",""));
            if (state.getBoolean("searched")&&contract==null&&noteObject.isEmpty()) search(lastQuery,false,false,state.getBoolean("driveOnly")?SearchMode.DRIVE:state.getBoolean("googlePhotosRequested")?SearchMode.GOOGLE_PHOTOS:SearchMode.UNIFIED,false,false);
        } else if (Intent.ACTION_SEARCH.equals(getIntent().getAction()) && supplied!=null) dispatch(false,false);
    }
    ObjectsBook book;
    private PromiseDialog promises;
    ShowingNotes showingNotes;
    PromiseActions promiseActions;
    void prepareShowing(){
        invalidateWork();busy=false;speech.stop();promiseActions.clear();refreshVoice();
    }
    void startShowingPromise(ShowingNotes.Entry entry){promises.fromShowing(entry);}
    void listenForPromise(){if(today!=null&&today.isShowing())today.dismiss();voice();}
    private Today today;
    private void showToday(boolean aloud){
        prepareShowing();
        if(today==null)today=new Today(this);
        today.open(aloud);
    }
    void sayToday(String text,Runnable done){speech.say(text,done);}
    void stopTodayVoice(){speech.stop();}
    void resumePromise(){promises.ask();}
    private boolean spokenTurn;
    private String calendarRequest="";
    private void agenda(String command){
        if(!granted(Manifest.permission.READ_CALENDAR)){calendarRequest=command;requestPermissions(new String[]{Manifest.permission.READ_CALENDAR},23);return;}
        if(command.equals("выбери календарь показов"))Showing.chooseCalendar(this);
        else Showing.agenda(this,!command.equals("что у меня сегодня"));
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        if("local.jarvis.TASK_RECEIPT".equals(intent.getAction()) && page!=null && !confirming && ScreenTask.unlocked(this)){taskResult(intent);return;}
        if(ScreenItem.ACTION.equals(intent.getAction())){
            setIntent(intent);
            if(page!=null && !confirming && !isFinishing() && ScreenTask.unlocked(this)){
                acceptScreen(intent);
            }
            return;
        }
        if(!confirming && page!=null && "local.jarvis.MIC".equals(intent.getAction()))page.post(this::voice);
    }
    private PhoneSearch.Hit contract;
    private String lastContractTurn="";
    private String failedContractQuestion="";
    private LinearLayout contractRecovery;
    private void lastContractAnswer(){
        var saved=ContractHistory.load(this);
        if(saved==null){feedback("Сохранённого ответа по договору пока нет.");return;}
        invalidateWork();busy=false;speech.stop();contract=saved.document();
        citationDocument=contract.uri()+"\n"+contract.stamp();mentioned.clear();noteObject="";hasSearch=false;
        lastContractTurn=saved.question()+"\n"+saved.answer();field.setText("");
        showItems(saved.quotes());feedback("Сохранённый ответ · "+contract.name()+"\n"+saved.question()+"\n\n"+saved.answer());
    }
    private static final int CLOUD_PROFILE=26;
    private SharedPreferences cloudPrefs(){return getSharedPreferences("contract_ai",0);}
    boolean cloudReady(){return cloudPrefs().contains(DeviceCredential.SETTING)||cloudPrefs().contains("profile");}
    private void chooseCloudProfile(){
        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),CLOUD_PROFILE);
    }
    private void cloudSettings(){
        boolean direct=cloudPrefs().contains(DeviceCredential.SETTING);
        String status=direct?"Подключено напрямую с телефона":cloudReady()?"Подключено через сервер":"Подключение не настроено";
        String[] choices=direct?new String[]{"Напрямую с телефона","Файл подключения к серверу","Отключить","Понимание запросов"}:cloudReady()?new String[]{"Напрямую с телефона","Файл подключения к серверу","Отключить"}:
                new String[]{"Напрямую с телефона","Файл подключения к серверу"};
        new AlertDialog.Builder(this).setTitle(status).setItems(choices,(d,i)->{
            if(i==0){prepareDirect();return;}
            if(i==1){chooseCloudProfile();return;}
            if(i==3){assistantPrivacy();return;}
            invalidateWork();busy=false;cloudPrefs().edit().clear().apply();lastContractTurn="";refreshVoice();
            feedback("OpenAI отключён. Доступен поиск цитат на телефоне.");
        }).setNegativeButton("Закрыть",null).show();
    }
    private void assistantPrivacy(){
        boolean enabled=cloudPrefs().getBoolean("understand_online",false);
        new AlertDialog.Builder(this).setTitle("Понимание запросов")
                .setMessage("Для свободных формулировок в OpenAI передаются текст запроса, ваше уточнение и признаки контекста: есть ли экран, документ и результаты. Снимок передаётся только с отдельным подтверждением.")
                .setPositiveButton(enabled?"Оставить на телефоне":"Включить OpenAI",(d,w)->{
                    if(!enabled && !cloudPrefs().contains(DeviceCredential.SETTING)){reply("Сначала подключите OpenAI напрямую.");return;}
                    cloudPrefs().edit().putBoolean("understand_online",!enabled).apply();
                    feedback(enabled?"Понимание запросов на телефоне.":"Понимание запросов через OpenAI включено.");
                }).setNegativeButton("Закрыть",null).show();
    }
    private void prepareDirect(){
        try{
            String fingerprint=DeviceCredential.prepare(this);
            new AlertDialog.Builder(this).setTitle("Прямое подключение OpenAI")
                .setMessage("Текст выбранного PDF и ваш вопрос будут отправляться в OpenAI по интернету телефона. Для настройки перенесите зашифрованный ключ. Код сверки: "+fingerprint)
                .setPositiveButton("Принять ключ",(d,w)->{
                    try{
                        DeviceCredential.accept(this,cloudPrefs());
                        invalidateWork();busy=false;lastContractTurn="";refreshVoice();
                        feedback("OpenAI подключён напрямую с телефона.");
                    }catch(Exception e){feedback("Не удалось принять ключ. Повторите перенос для этого телефона.");}
                }).setNegativeButton("Закрыть",null).show();
        }catch(Exception e){feedback("Не удалось подготовить защищённое хранилище Android.");}
    }
    private String citationDocument="";
    private final Set<String> mentioned=new HashSet<>();
    private String noteObject="",lastQuery="",dateFilter="";
    private boolean photosOnly;
    private GoogleSearch photoLibraryQuery;
    private TextView photoLibraryButton,folderRecovery;
    private static final int RETRY_FOLDER=175, SHARED_DOCUMENT_ACCESS=176;
    private enum SearchMode { UNIFIED, PREFER_PHOTOS, GOOGLE_PHOTOS, DRIVE }
    private SearchMode searchMode=SearchMode.UNIFIED;
    private boolean showingPhotoLibrary,awaitingMediaClue,questionOnReturn;
    private Set<String> mediaCandidates=Collections.emptySet();
    private String mediaQuestion="";
    private Set<String> within=null;
    private Runnable notificationAction;

    private void toolsMenu(){
        String[] choices={"Мои объекты","Поиск по надписи","Добавить виджет микрофона","Индексация на зарядке","Задачи и напоминания","Команды телефона","Ответы OpenAI по договору","Последний ответ по договору","Итоги показов","Мои клиенты","Управление обещаниями","Сегодня","История запросов","Голос Марии","Очистка телефона","Совместимость устройства"};
        new AlertDialog.Builder(this).setTitle("Инструменты").setItems(choices,(d,i)->{
            if(i==0)book.choose(book::show);
            if(i==1)compose("Найди скрин, где написано ");
            if(i==4)Reminder.list(this);
            if(i==5)showCommands();
            if(i==6)cloudSettings();
            if(i==7)lastContractAnswer();
            if(i==8)showingNotes.browse();
            if(i==9)showingNotes.choosePerson("");
            if(i==10)promiseActions.choose();
            if(i==11)showToday(false);
            if(i==12)journal.show(this);
            if(i==14)cleanup.open();
            if(i==15)new AlertDialog.Builder(this).setTitle("Совместимость устройства").setMessage(DeviceSupport.description()).setPositiveButton("Понятно",null).show();
            if(i==13)new AlertDialog.Builder(this).setTitle("Голос Марии")
                .setMessage("Приветствия записаны голосом Coral. Для озвучки всех ответов этим голосом текст реплик передаётся в OpenAI через интернет телефона. Без связи работает локальный голос.")
                .setPositiveButton("Все ответы Coral",(dialog,which)->{
                    if(!cloudPrefs().contains(DeviceCredential.SETTING)){feedback("Сначала подключите OpenAI напрямую с телефона.");return;}
                    cloudPrefs().edit().putBoolean(BrightVoice.PREFERENCE,true).apply();
                    feedback("Звонкий голос Coral включён для всех ответов.");
                }).setNeutralButton("Только приветствия",(dialog,which)->{
                    cloudPrefs().edit().remove(BrightVoice.PREFERENCE).apply();feedback("Озвучка ответов на телефоне.");
                }).setNegativeButton("Закрыть",null).show();
            if(i==2){
                android.appwidget.AppWidgetManager wm=getSystemService(android.appwidget.AppWidgetManager.class);
                if(wm.isRequestPinAppWidgetSupported())wm.requestPinAppWidget(new ComponentName(this,JarvisWidget.class),null,null);
                else feedback("На главном экране телефона удерживайте пустое место → Виджеты → Мария.");
            }
            if(i==3){if(!DeviceSupport.nativeModels()){feedback("Индексация изображений доступна в полной ARM64-версии.");return;}boolean on=getSharedPreferences("settings",0).getBoolean("charge",true);
                new AlertDialog.Builder(this).setTitle("Индексация на зарядке").setMessage(on?"Включена. Android подготовит фотографии и надписи во время зарядки.":"Выключена.")
                    .setPositiveButton(on?"Выключить":"Включить",(x,y)->{
                        getSharedPreferences("settings",0).edit().putBoolean("charge",!on).apply();
                        if(on)getSystemService(android.app.job.JobScheduler.class).cancel(ChargeIndex.ID);else ChargeIndex.schedule(this);
                    }).setNegativeButton("Закрыть",null).show();}
        }).show();
    }
    private void phoneMenu(){
        String[] options={"Найти приложение","Найти видео","Настройки ассистента","Действия на экране","Примеры команд","Сегодня","Google Фото","Безопасность и доступ"};
        new AlertDialog.Builder(this).setTitle("Действия на телефоне").setItems(options,(d,i)->{
            switch(i){
                case 0 -> compose("Найди приложение для ");
                case 1 -> compose("Найди видео ");
                case 2 -> PhoneTasks.handle(this,"открой настройки ассистента");
                case 3 -> startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));
                case 4 -> showCommands();
                case 5 -> showToday(false);
                case 6 -> googlePhotos();
                case 7 -> securitySettings();
            }
        }).show();
    }
    private void securitySettings(){
        boolean enabled=ScreenTask.ready();
        AlertDialog.Builder panel=new AlertDialog.Builder(this).setTitle("Безопасность и доступ")
                .setMessage(ScreenTask.accessStatus(this)+
                    "\n\nНа разблокированном телефоне Мария выполняет ваши команды без повторного отпечатка. Выключение экрана отменяет команду и закрывает Марию.")
                .setNegativeButton("Закрыть",null)
                .setNeutralButton("Заблокировать", (dialog,button)->{
                    getSharedPreferences("settings",0).edit().putBoolean("manualLock",true).apply();
                    ScreenTask.cancel();finishAffinity();
                });
        if(enabled)panel.setPositiveButton("Отключить нажатия",(dialog,button)->{
            ScreenTask.disableControl();Toast.makeText(this,"Управление экраном выключено",Toast.LENGTH_SHORT).show();
        });
        panel.show();
    }
    private void showCommands(){
        new AlertDialog.Builder(this).setTitle("Что можно поручить Марии").setMessage(
            "«Найди приложение для почты»\n«Открой настройки ассистента»\n«Открой настройки и нажми Bluetooth»\n«Открой YouTube и найди джаз»\n\n"+
            "«Найди фото, где видна собака»\n«Найди скрин, где написано заказ»\n«Найди PDF со словами срок доставки»\n«Найди видео за вчера»\n«Поделись вторым фото»")
            .setPositiveButton("Закрыть",null).show();
    }
    private void googlePhotos(){
        String[] actions={"Искать во всей библиотеке Google Фото","Искать в добавленных в Марию снимках","Добавить снимки из Google Фото"};
        new AlertDialog.Builder(this).setTitle("Google Фото").setItems(actions,(d,i)->{
            if(i==2){pickItems(true);return;}
            if(i==0){searchGoogleApp(GoogleSearch.Source.PHOTOS);return;}
            photosOnly=true;within=null;contract=null;noteObject="";dateFilter="";field.setText("Найди фото");search("фото",false,false);
        }).show();
    }
    private void searchGoogleApp(GoogleSearch.Source source){
        EditText input=new EditText(this);input.setSingleLine();input.setHint(source==GoogleSearch.Source.PHOTOS?"Например, собака":"Например, договор");
        new AlertDialog.Builder(this).setTitle("Поиск в приложении "+source.title).setView(input)
            .setPositiveButton("Искать",(x,y)->{
                String terms=input.getText().toString().trim();
                if(!terms.isEmpty())try{
                    turn=journal.begin("Поиск в "+source.title,terms);
                    startActivity(new GoogleSearch(source,terms).intent());record(source.title,"Запрос передан приложению: "+terms);
                }
                catch(ActivityNotFoundException e){feedback("Приложение "+source.title+" недоступно.");}
            }).setNegativeButton("Отмена",null).show();
    }
    private void openPhotoLibrary(){
        if(photoLibraryQuery==null)return;
        Intent intent=photoLibraryQuery.terms().isEmpty()
                ?getPackageManager().getLaunchIntentForPackage(GoogleSearch.Source.PHOTOS.app):photoLibraryQuery.intent();
        if(intent==null){feedback("Приложение Google Фото недоступно.");return;}
        try{
            showingPhotoLibrary=true;
            startActivity(intent);
            record("Google Фото",photoLibraryQuery.terms().isEmpty()?"Открыта медиатека без ограничения по дате.":"Запрос передан приложению: "+photoLibraryQuery.terms()+". Итоговую выдачу показывает Google Фото.");
        }catch(ActivityNotFoundException | SecurityException e){record("Ошибка Google Фото",e.getClass().getSimpleName());showingPhotoLibrary=false;feedback("Приложение Google Фото недоступно.");}
    }
    void withNotifications(Runnable action){
        if(Build.VERSION.SDK_INT<33||granted(Manifest.permission.POST_NOTIFICATIONS)){action.run();return;}
        notificationAction=action;requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},19);
    }
    void newNote(String name){
        hasSearch=false;noteObject=name;contract=null;showItems(Collections.emptyList());field.setText("");
        feedback("Заметка для «"+name+"». Нажмите «Говорить» или введите текст.");
    }
    void askAbout(PhoneSearch.Hit hit){
        String id=hit.uri()+"\n"+hit.stamp();
        if(!id.equals(citationDocument)){citationDocument=id;mentioned.clear();lastContractTurn="";}
        invalidateWork();busy=false;
        contract=hit;hasSearch=false;noteObject="";speech.stop();showItems(Collections.emptyList());field.setText("");
        feedback(hit.name()+(cloudReady()?"\nЗадайте вопрос своими словами. Текст договора и вопрос будут переданы в OpenAI.":"\nПоиск цитат на телефоне. Чтобы сопоставлять условия, подключите OpenAI в разделе «Инструменты»."));
    }
    private void answerContract(String question){
        answerContract(question,false);
    }
    private void answerContract(String question,boolean localOnly){
        if(contract==null)return;
        PhoneSearch.Hit document=contract;invalidateWork();int token=generation;
        String profile=cloudPrefs().getString("profile","");
        String sealedKey=cloudPrefs().getString(DeviceCredential.SETTING,"");
        if(!localOnly && (!sealedKey.isEmpty() || !profile.isEmpty())){
            String previous=lastContractTurn;
            busy=true;refreshVoice();showItems(Collections.emptyList());feedback("Сопоставляю условия договора через OpenAI…");
            pending=worker.submit(()->{
                try{
                    var answer=CloudContract.ask(this,document,question,previous,sealedKey.isEmpty()?CloudContract.Profile.load(profile):null,sealedKey);
                    runOnUiThread(()->{if(generation==token){
                        ContractHistory.save(this,document,question,answer);
                        lastContractTurn=question+"\n"+answer.text();showItems(answer.quotes());reply(answer.text(),CoralDelivery.DOCUMENT);
                    }});
                }catch(Exception|LinkageError e){
                    String message=e instanceof CloudContract.Issue?e.getMessage():"Не удалось прочитать PDF или получить ответ по сети. Проверьте файл и подключение.";
                    runOnUiThread(()->{if(generation==token){
                        reply(message);failedContractQuestion=question;contractRecovery.setVisibility(View.VISIBLE);
                    }});
                }
            });return;
        }
        busy=true;refreshVoice();feedback("Читаю «"+document.name()+"»…");
        pending=worker.submit(()->{
            try{
                List<Contract.Citation> citations=Contract.find(this,document,question);
                runOnUiThread(()->{
                    if(generation!=token)return;busy=false;refreshVoice();
                    boolean overview=Contract.overview(question);
                    if(overview && Contract.continuation(question) && !citations.isEmpty()){
                        citations.removeIf(c->mentioned.contains(c.key()));
                        if(citations.isEmpty()){showItems(Collections.emptyList());reply("Я уже показал все найденные фрагменты этого договора. Скажите «О чём этот договор?», чтобы повторить обзор.");return;}
                    }
                    if(citations.isEmpty()){showItems(Collections.emptyList());reply(overview?"Не удалось выделить читаемые условия в этом PDF. Проверьте текст на странице.":"По этому вопросу не нашла подходящего пункта. Можно назвать номер или попросить обзор договора.");return;}
                    if(overview){
                        List<PhoneSearch.Hit> summary=new ArrayList<>();
                        StringBuilder spoken=new StringBuilder("Вот что есть в договоре. ");
                        for(var c:citations){
                            if(summary.size()==3)break;
                            String excerpt=c.text().length()<=235?c.text():c.text().substring(0,235).replaceFirst("\\s+\\S*$","")+"…";
                            mentioned.add(c.key());
                            summary.add(document.matched(c.score(),c.page(),"Цитата"+(c.scan()?" со скана":"")+" · страница "+(c.page()+1)+"\n«"+excerpt+"»"));
                            spoken.append("Страница ").append(c.page()+1).append(". ").append(excerpt).append(" ");
                        }
                        showItems(summary);feedback(spoken.toString().strip()+"\nНажмите на фрагмент, чтобы открыть его страницу.");speech.say(spoken.toString(),null,CoralDelivery.DOCUMENT);return;
                    }
                    mentioned.add(citations.get(0).key());
                    List<PhoneSearch.Hit> rows=new ArrayList<>();
                    for(var c:citations)rows.add(document.matched(c.score(),c.page(),"Цитата"+(c.scan()?" со скана":"")+" · страница "+(c.page()+1)+"\n«"+c.text()+"»"));
                    showItems(rows);
                    var first=rows.get(0);feedback("Поиск цитат на телефоне. "+(rows.size()==1?"Нашла один фрагмент.":"Подходящих фрагментов: "+rows.size()+". Выберите страницу для просмотра."));
                    try{FilePreview.show(this,first);}catch(Exception e){feedback(first.reason());}
                    speech.say("Страница "+(first.page()+1)+". "+citations.get(0).text().substring(0,Math.min(citations.get(0).text().length(),3000))+
                        (rows.size()>1?" В списке есть другие подходящие фрагменты.":""),null,CoralDelivery.DOCUMENT);
                });
            }catch(Exception e){runOnUiThread(()->{if(generation==token)reply("Не удалось прочитать договор. Проверьте доступ к файлу.");});}
        });
    }
    void shareFiles(List<PhoneSearch.Hit> files){
        invalidateWork();int token=generation;busy=true;refreshVoice();feedback("Готовлю файлы для отправки…");
        pending=worker.submit(()->{
            try{
                ArrayList<Uri> streams=new ArrayList<>();
                for(var hit:files){
                    if(DriveFiles.remote(hit.uri())){
                        var tmp=DriveFiles.download(this,hit);try{streams.add(ShareFiles.copy(this,tmp));}finally{new java.io.File(tmp.uri().getPath()).delete();}
                    }else streams.add(ShareFiles.copy(this,hit));
                }
                runOnUiThread(()->{
                    if(generation!=token)return;busy=false;refreshVoice();
                    Intent send=new Intent(streams.size()==1?Intent.ACTION_SEND:Intent.ACTION_SEND_MULTIPLE).setType(files.size()==1?files.get(0).mime():"*/*");
                    if(streams.size()==1)send.putExtra(Intent.EXTRA_STREAM,streams.get(0));else send.putParcelableArrayListExtra(Intent.EXTRA_STREAM,streams);
                    ClipData data=ClipData.newRawUri("Подборка",streams.get(0));for(int i=1;i<streams.size();i++)data.addItem(new ClipData.Item(streams.get(i)));
                    send.setClipData(data);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);feedback("Подборка готова.");startActivity(Intent.createChooser(send,"Поделиться подборкой"));
                });
            }catch(Exception e){runOnUiThread(()->{if(generation==token)reply("Не удалось прочитать один из выбранных файлов.");});}
        });
    }
    private ScreenItem screenItem;
    private final ScreenReading reading=new ScreenReading();
    private void taskResult(Intent i){
        String result=i.getStringExtra("report");if(result!=null){turn=journal.begin("Итог действия","Google Задачи");reply(result);}
    }
    private void navigateScreen(ScreenNavigation action){
        if(action==null){reply("Какую кнопку нажать или в какую сторону прокрутить страницу?");return;}
        if(action.manualLabel()){reply("Последнее нажатие оставляю вам.");return;}
        var source=screenItem;
        if(!(this instanceof AssistPanel) || source==null || source.origin.isBlank() ||
                SystemClock.elapsedRealtime()-source.created>300000){
            reply("Откройте нужный экран и вызовите меня поверх него боковой кнопкой.");return;
        }
        if(!ScreenTask.ready()){reply(ScreenTask.accessStatus(this));return;}
        long request=turn;
        authorizeScreen(source.origin,action.description(),()->{
            if(ScreenTask.navigate(source.origin,action,request)){finish();return;}
            reply("На этом экране управление недоступно.");
        });
    }
    private void readPublication(){
        var source=screenItem;
        if(source==null||source.origin.isBlank()||!(this instanceof AssistPanel)||
                !ScreenTask.ready()||SystemClock.elapsedRealtime()-source.created>300000){
            if(source!=null && !source.origin.isBlank() && !ScreenTask.ready()){
                String access=ScreenTask.accessStatus(this);record("Специальные возможности",access);Toast.makeText(this,access,Toast.LENGTH_LONG).show();
            }
            readScreen(false,true,true);return;
        }
        long request=turn;
        authorizeScreen(source.origin,"Прочитать открытую публикацию целиком и прокрутить её до конца текста",()->{
            if(ScreenTask.readPost(source,request)){finish();return;}
            readScreen(false,true,true);
        });
    }
    private void readScreen(boolean resume,boolean continuous){
        readScreen(resume,continuous,false);
    }
    private void readScreen(boolean resume,boolean continuous,boolean publication){
        ScreenItem source=screenItem;
        if(source==null || SystemClock.elapsedRealtime()-source.created>300000){reply("Вызовите меня поверх текста, который нужно прочитать.");return;}
        invalidateWork();int token=generation;
        if(resume && reading.matches(source)){speakPart(token,continuous);return;}
        feedback("Читаю текст открытого экрана…");busy=true;refreshVoice();
        pending=worker.submit(()->{
            String raw=source.text;
            if(!publication || raw.strip().length()<80)try{raw=source.read(this);}catch(Exception failure){raw=source.text;}
            String body=publication?PostReader.beforeComments(raw):raw;
            runOnUiThread(()->{
                if(token!=generation || isFinishing())return;
                reading.load(source,body);busy=false;refreshVoice();
                record("Источник","Текст текущего экрана · чтение на телефоне");
                if(!reading.more()){reply("На этом экране не удалось разобрать текст.");return;}
                speakPart(token,continuous);
            });
        });
    }
    private void speakPart(int token,boolean continuous){
        if(token!=generation || isFinishing() || !ScreenTask.unlocked(this))return;
        if(!reading.more()){reply("Дочитала видимую часть. Для продолжения нужен следующий экран текста.");return;}
        String part=reading.next();feedback(part);record("Чтение","Передан фрагмент · символов "+part.length());
        speech.say(part,()->{if(continuous && reading.more())speakPart(token,true);});
    }
    private Messenger.Destination pickForRecipient;
    private static final int PICK_SCREEN_FILE=182;
    private void acceptScreen(Intent i){
        screenItem=ScreenItem.take(i.getStringExtra("capture"));
        field.setText("");
        if(screenItem==null){feedback("Вызовите Марию ещё раз поверх нужного экрана.");return;}
        if(screenItem.article!=null){
            turn=screenItem.articleTurn;
            if(screenItem.article.isEmpty()){
                if(!screenItem.readingNotice.isBlank())Toast.makeText(this,screenItem.readingNotice,Toast.LENGTH_LONG).show();
                readScreen(false,true,true);
            }else{
                reading.article(screenItem,screenItem.article+(screenItem.readingNotice.isEmpty()?"":"\n"+screenItem.readingNotice));
                speakPart(generation,true);
            }
            return;
        }
        turn=journal.begin("Системный помощник","Разобрать открытый экран");record("Экран","Получен по системному жесту · снимок "+(screenItem.picture!=null?"есть":"недоступен")+" · оригинал "+(screenItem.uri!=null?"есть":"недоступен"));
        if(this instanceof AssistPanel panel){
            panel.source(screenItem.uri==null?null:ScreenItem.displayName(this,screenItem.uri));
            feedback("Чем помочь?");
        }else feedback((screenItem.uri==null?"":("Выбран файл «"+ScreenItem.displayName(this,screenItem.uri)+"».\n"))+"Можно сказать «проложи туда маршрут», «скопируй этот номер» или «отправь этот файл Анне в WhatsApp».");
        page.postDelayed(()->{if(!isFinishing() && hasWindowFocus() && ScreenTask.unlocked(this) && !field.hasFocus())voice();},350);
    }
    private boolean screenCommand(String original){
        String q=original.strip().replaceFirst("(?iu)^(?:мария|мари|джарвис)[, ]+","").replaceFirst("[.!?]+$","").strip();
        boolean route=q.matches("(?iu)(?:проложи|построй|открой|покажи) (?:мне )?(?:туда маршрут|маршрут (?:туда|до этого адреса|по этому адресу))");
        boolean number=q.matches("(?iu)(?:скопируй|скопировать) (?:мне )?(?:этот |этот телефонный )?(?:номер(?: телефона)?|телефон)(?: с экрана)?");
        var share=java.util.regex.Pattern.compile("(?iu)^(?:отправь|перешли|пошли|отошли) (?:этот файл|это фото|этот документ|этот снимок|это видео) (.{1,80})$").matcher(q);
        boolean send=share.matches();
        boolean visual=(screenItem!=null || q.toLowerCase(Locale.ROOT).contains("экране")) &&
                q.matches("(?iu)(?:опиши|рассмотри|разбери)(?: мне)? (?:картинку|изображение|фото|фотографию)(?: на (?:этом )?экране)?");
        boolean describe=visual || ScreenItem.describes(q);
        boolean help=q.matches("(?iu)(?:разберись|посмотри|помоги).*на экране.*");
        if(!route&&!number&&!send&&!help&&!describe)return false;
        invalidateWork();busy=false;
        if(screenItem!=null && SystemClock.elapsedRealtime()-screenItem.created>300000)screenItem=null;
        if(describe){
            record("Маршрут","Описание текущего экрана");
            if(screenItem==null)reply("Откройте нужное приложение и вызовите меня боковой кнопкой поверх него.");
            else if(visual)confirmScreenVision(screenItem);
            else readScreen(false,false);
            return true;
        }
        if(help){
            if(screenItem==null)reply("Откройте нужный экран и вызовите меня системным жестом помощника.");
            else understand(original);
            return true;
        }
        if(send){
            var destination=Messenger.parse(share.group(1));
            if(destination.app()==null){reply("Назовите WhatsApp, Viber, Plus или Telegram.");return true;}
            if(destination.name().isBlank()){reply("Назовите получателя.");return true;}
            if(screenItem==null || screenItem.uri==null){
                pickForRecipient=destination;
                feedback("Выберите файл для "+destination.app().title+".");
                try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),PICK_SCREEN_FILE);}
                catch(ActivityNotFoundException e){pickForRecipient=null;reply("Откройте файл и выберите «Поделиться → Мария».");}
            }else prepareMessage(screenItem.uri,destination);
            return true;
        }
        if(screenItem==null){reply("Откройте скриншот и вызовите меня системным жестом. Можно также выбрать «Поделиться → Мария».");return true;}
        ScreenItem source=screenItem;
        int token=generation;busy=true;refreshVoice();feedback("Читаю текст на экране…");
        pending=worker.submit(()->{
            List<String> found;
            try{found=ScreenItem.candidates(source.read(this),number);}
            catch(Exception e){found=ScreenItem.candidates(source.text,number);}
            List<String> choices=found;
            runOnUiThread(()->{
                if(token!=generation||isFinishing())return;
                busy=false;refreshVoice();record("Экран",number?"Поиск номера · вариантов "+choices.size():"Поиск адреса · вариантов "+choices.size());
                if(choices.isEmpty()){reply(number?"Номер не разобрала. Увеличьте его на экране и вызовите меня снова.":"Адрес не разобрала. Увеличьте адрес или поделитесь исходной картинкой.");return;}
                if(choices.size()==1){applyScreenValue(choices.get(0),number);return;}
                new AlertDialog.Builder(this).setTitle(number?"Какой номер скопировать?":"Куда построить маршрут?")
                    .setItems(choices.toArray(new String[0]),(d,n)->applyScreenValue(choices.get(n),number)).setNegativeButton("Отмена",null).show();
            });
        });
        return true;
    }
    private void applyScreenValue(String value,boolean number){
        if(number){
            ClipData clip=ClipData.newPlainText("Номер",value);
            PersistableBundle flags=new PersistableBundle();flags.putBoolean("android.content.extra.IS_SENSITIVE",true);
            clip.getDescription().setExtras(flags);getSystemService(ClipboardManager.class).setPrimaryClip(clip);reply("Номер скопирован.");return;
        }
        try{startActivity(new Directions(value,List.of()).maps());record("Экран","Адрес передан в Google Карты");feedback("Открыла маршрут в Google Картах.");}
        catch(ActivityNotFoundException|SecurityException e){reply("Google Карты не смогли открыть маршрут.");}
    }
    private void confirmScreenVision(ScreenItem source){
        confirmScreenVision(source,"Опиши изображение на экране.");
    }
    private void confirmScreenVision(ScreenItem source,String question){
        if(source.picture==null && source.uri==null){reply("Android не передал изображение этого экрана.");return;}
        if(!cloudPrefs().contains(DeviceCredential.SETTING)){reply("Для описания изображения подключите OpenAI в инструментах Марии.");return;}
        new AlertDialog.Builder(this).setTitle("Описать изображение?")
                .setMessage("Мария отправит в OpenAI один снимок и ваш вопрос: «"+question+"».")
                .setPositiveButton("Описать снимок",(d,w)->{
                    if(!ScreenTask.unlocked(this) || source!=screenItem || SystemClock.elapsedRealtime()-source.created>300000){
                        feedback("Снимок устарел. Вызовите Марию заново.");return;
                    }
                    describeScreen(source,true,question);
                }).setNegativeButton("Отмена",null).show();
    }
    private void describeScreen(ScreenItem source,boolean visual){
        describeScreen(source,visual,"Что на экране?");
    }
    private void describeScreen(ScreenItem source,boolean visual,String question){
        busy=true;refreshVoice();
        feedback(visual?"Рассматриваю снимок…":"Читаю открытый экран…");
        int token=generation;
        pending=worker.submit(()->{
            String answer;
            boolean offerImage=false;
            if(visual){
                try{answer=ScreenVision.describe(this,source,cloudPrefs().getString(DeviceCredential.SETTING,""),question);}
                catch(Exception e){answer=e instanceof CloudContract.Issue?e.getMessage():"Не удалось получить описание снимка от OpenAI. Можно прочитать надписи на телефоне.";}
            }else{
                String raw;
                try{raw=source.read(this);}catch(Exception e){raw=source.text;}
                String visible=ScreenItem.excerpt(raw);
                offerImage=visible.isEmpty() && (source.picture!=null || source.uri!=null) && cloudPrefs().contains(DeviceCredential.SETTING);
                answer=!visible.isEmpty()?"На экране вижу "+visible+".":source.picture==null && source.uri==null?
                        "Android не передал содержимое этого экрана.":"Не разобрала надписей на этом экране.";
            }
            String result=answer;boolean offer=offerImage;
            runOnUiThread(()->{
                if(token!=generation || isFinishing() || !ScreenTask.unlocked(this))return;
                record("Источник",visual?"Снимок экрана · запрос в OpenAI":"Содержимое экрана · текст Android и локальное распознавание");
                reply(result);
                if(offer)confirmScreenVision(source);
            });
        });
    }
    void selectForCommand(Uri uri,String name){
        screenItem=new ScreenItem();screenItem.uri=uri;
        feedback("Выбран файл «"+name+"». Скажите, например, «Отправь этот файл Анне в WhatsApp».");
    }
    private void prepareMessage(Uri uri,Messenger.Destination destination){
        Messenger app=destination.app();
        String name=destination.name();
        String fileName=ScreenItem.displayName(this,uri);
        Runnable launch=()->{
            try{
                String mime=getContentResolver().getType(uri);
                Intent share=new Intent(Intent.ACTION_SEND).setType(mime==null?"application/octet-stream":mime).setPackage(app.pkg)
                    .putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                share.setClipData(ClipData.newRawUri("Вложение",uri));
                app.address(this,share);
                if(ScreenTask.ready())ScreenTask.recipient(app,name,turn);
                startActivity(share);
                record("Экран","Открываю выбор получателя для файла · "+app.title);
            }catch(ActivityNotFoundException|SecurityException e){ScreenTask.cancel();reply("Не удалось открыть вложение в "+app.title+".");}
        };
        if(ScreenTask.ready())authorizeScreen(app.pkg,fileName+" → "+name+" · "+app.title,launch);
        else new AlertDialog.Builder(this).setTitle(fileName).setMessage(app.title+" · "+name+"\nСлужба действий выключена. Выберите чат вручную.")
            .setPositiveButton("Открыть "+app.title,(d,w)->launch.run()).setNegativeButton("Отмена",null).show();
    }

    private void receiveShare(Intent intent){
        ArrayList<Uri> items=new ArrayList<>();
        if(Intent.ACTION_SEND_MULTIPLE.equals(intent.getAction())){ArrayList<Uri> batch=intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);if(batch!=null)items.addAll(batch);}
        else {Uri item=intent.getParcelableExtra(Intent.EXTRA_STREAM);if(item!=null)items.add(item);}
        items.removeIf(u->u==null||!"content".equals(u.getScheme())||ShareFiles.AUTH.equals(u.getAuthority()));
        String text=intent.getStringExtra(Intent.EXTRA_TEXT);
        if(items.isEmpty()){if(text!=null)book.choose(name->book.note(name,text));else feedback("Файл недоступен.");return;}
        if(items.size()==1){
            screenItem=new ScreenItem();screenItem.uri=items.get(0);
            if(text!=null)screenItem.text=text;
            new AlertDialog.Builder(this).setTitle(ScreenItem.displayName(this,items.get(0)))
                .setItems(new String[]{"Сказать команду Марии","Ввести команду","Добавить к объекту"},(d,n)->{
                    if(n==2){saveShared(items);return;}
                    feedback("Выбран файл «"+ScreenItem.displayName(this,items.get(0))+"». Можно попросить отправить его или прочитать номер и адрес с картинки.");
                    if(n==0)page.post(this::voice);else {inputBar.setVisibility(View.VISIBLE);field.requestFocus();getSystemService(InputMethodManager.class).showSoftInput(field,InputMethodManager.SHOW_IMPLICIT);}
                }).show();return;
        }
        saveShared(items);
    }
    private void saveShared(ArrayList<Uri> items){
        book.choose(name->{
            invalidateWork();int token=generation;busy=true;refreshVoice();feedback("Добавляю файлы к объекту…");
            pending=worker.submit(()->{
                int count=0;
                for(Uri u:items){if(Thread.currentThread().isInterrupted())break;
                    try{var hit=SelectedItems.add(this,u,false);book.add(name,hit);count++;}catch(Exception ignored){}}
                String report="Добавлено файлов: "+count+" из "+items.size();
                runOnUiThread(()->{if(token==generation){busy=false;refreshVoice();feedback(report);book.show(name);}});
            });
        });
    }
    private void suggestBundle(String name,String request){
        List<PhoneSearch.Hit> files=book.files(name);
        if(request.isEmpty()||files.isEmpty()){book.bundle(name);return;}
        invalidateWork();int token=generation;long nativeToken=activeNativeToken;busy=true;refreshVoice();feedback("Подбираю материалы для «"+name+"»…");
        pending=worker.submit(()->{
            Set<String> selected=new HashSet<>();
            try{
                for(String part:request.split(",|\\s+и\\s+")){
                    String term=part.strip();if(term.isEmpty())continue;
                    if(term.length()>5)term=term.substring(0,term.length()-1);
                    for(var h:files)if(h.name().toLowerCase(Locale.ROOT).contains(term))selected.add(h.uri().toString());
                    try(ContentIndex index=new ContentIndex(this,new ContentRequest(true,part.strip()),nativeToken)){
                        var matches=new ArrayList<PhoneSearch.Hit>();
                        for(var h:files){if(Thread.currentThread().isInterrupted())return;
                            if(h.mime().startsWith("image/")&&!DriveFiles.remote(h.uri())){var match=index.match(h);if(match!=null)matches.add(match);}}
                        matches.sort(PhoneSearch.ORDER);for(var h:matches.subList(0,Math.min(3,matches.size())))selected.add(h.uri().toString());
                    }
                }
            }catch(Exception unavailable){}
            runOnUiThread(()->{if(token==generation){busy=false;refreshVoice();feedback("Проверьте предложенную подборку.");book.bundle(name,selected);}});
        });
    }
    private boolean refinement(String raw){
        String q=raw.toLowerCase(Locale.ROOT).strip();
        if(lastQuery.isEmpty() || !hasSearch)return false;
        if(q.matches("^(?:только |оставь |покажи )?(?:за |в )(?:октябр[ье]|ноябр[ье]|сентябр[ье]|декабр[ье]|январ[ье]|феврал[ье]|март[ае]?|апрел[ье]|ма[йе]|июн[ье]|июл[ье]|август[ае]?|вчера|сегодня|неделю)(?: \\d{4})?[.!]?$")){
            dateFilter=q.replaceFirst("^.*?(?:за |в )","").replaceAll("[.!]$","");search(lastQuery,false,false);return true;
        }
        ContentRequest previous=ContentRequest.parse(lastQuery);
        VideoTour previousTour=previous!=null && previous.video()?VideoTour.parse(previous.terms()):null;
        if(hasSearch && previousTour!=null && previousTour.clue().isEmpty()
                && (q.matches("(?:там |примета |с |в кадре ).+") || q.matches("[а-яё]+(?:ый|ий|ая|яя|ое|ее|ые|ие) [а-яё-]+[.!?]?"))){
            String clue=q.replaceFirst("^(?:там |примета |в кадре )","").replaceAll("[.!?]+$","");
            within=null;search("видео, где "+previous.terms()+" с "+clue,false,false);return true;
        }
        if(q.startsWith("покажи те, где ")||q.startsWith("только где ")||q.startsWith("оставь те, где ")){
            String words=q.substring(q.indexOf("где ")+4);
            if(previous!=null && previous.video()){
                within=null;search("видео, где "+previous.terms()+" и "+words,false,false);return true;
            }
            within=mediaCandidates.isEmpty()?null:mediaCandidates;
            ContentRequest prev=ContentRequest.parse(lastQuery);
            if(prev!=null&&prev.photo()&&!prev.lettering())words=prev.terms()+" и "+words;
            search("фото, где "+words,false,false);return true;
        }
        return false;
    }


    private int dp(int d) { return Math.round(d*getResources().getDisplayMetrics().density); }
    private Studio ui;
    private MediaResults adapter;
    private AuraView aura,smallAvatar;
    private boolean greetingOnPlayback;
    private final CompanionLines lines=new CompanionLines();
    private View home,results,back;
    private LinearLayout inputBar,homeTools,searchTools;
    private TextView headerTitle,heroTitle,heroAction,actionLabel;
    private LinearLayout voicePanel;
    private ImageView heroMic;
    private ImageView resultMic;
    private ScrollView feedbackScroll;
    private boolean inResults,busy,speaking;
    private AuraView.Mode micMode=AuraView.Mode.READY;

    private void buildScreen(){
        ui=new Studio(this);
        page=ui.column();page.setBackgroundColor(Studio.BG);
        page.setFocusableInTouchMode(true);
        page.setPadding(dp(20),dp(8),dp(20),dp(10));setContentView(page);
        getWindow().setStatusBarColor(Studio.BG);getWindow().setNavigationBarColor(Studio.BG);
        if(!(this instanceof AssistPanel) && Build.VERSION.SDK_INT>=30) page.setOnApplyWindowInsetsListener((v,i)->{
            android.graphics.Insets bars=i.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());
            v.setPadding(dp(20)+bars.left,dp(6)+bars.top,dp(20)+bars.right,dp(8)+bars.bottom);return i;
        });
        LinearLayout header=ui.row();page.addView(header,ui.lp(-1,52));
        back=ui.iconButton("back","Главный экран",Studio.TEXT,this::goHome);header.addView(back,ui.lp(48,48));
        back.setVisibility(View.GONE);
        smallAvatar=new AuraView(this);header.addView(smallAvatar,ui.lp(42,42));smallAvatar.setVisibility(View.GONE);
        TextView brand=headerTitle=ui.text("МАРИЯ",19,Studio.TEXT,true);brand.setLetterSpacing(.15f);
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        ImageView tools=ui.iconButton("controls","Инструменты",Studio.MUTED,this::toolsMenu);
        homeTools=ui.row();header.addView(homeTools);homeTools.addView(tools,ui.lp(48,48));ui.gap(homeTools,7);
        ImageView folder=ui.iconButton("folder","Источники поиска",Studio.MUTED,this::sources);
        homeTools.addView(folder,ui.lp(48,48));
        searchTools=ui.row();header.addView(searchTools);searchTools.setVisibility(View.GONE);
        searchTools.addView(ui.iconButton("keyboard","Ввести команду",Studio.TEXT,()->{
            inputBar.setVisibility(View.VISIBLE);compose(field.getText().toString());field.selectAll();
        }),ui.lp(48,48));
        ui.gap(searchTools,6);resultMic=ui.iconButton("mic","Говорить",Studio.BG,this::voiceAction);
        resultMic.setBackground(ui.surface(Studio.LILAC,16,0));searchTools.addView(resultMic,ui.lp(48,48));
        FrameLayout body=new FrameLayout(this);page.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        ScrollView landing=new ScrollView(this);landing.setFillViewport(true);landing.setVerticalScrollBarEnabled(false);
        home=landing;body.addView(landing);
        LinearLayout dashboard=ui.column();dashboard.setPadding(0,dp(12),0,dp(10));landing.addView(dashboard);
        voicePanel=ui.column();ui.tintCard(voicePanel,0xff382b48,0xff211f34);
        voicePanel.setPadding(dp(18),dp(17),dp(18),dp(13));
        dashboard.addView(voicePanel,ui.lp(-1,-2));
        heroTitle=ui.text("Чем помочь?",31,Studio.TEXT,false);
        heroTitle.setLetterSpacing(-.035f);
        LinearLayout introduction=ui.row();voicePanel.addView(introduction,ui.lp(-1,-2));
        introduction.addView(heroTitle,new LinearLayout.LayoutParams(0,-2,1));
        TextView sample=ui.text("Послушать голос",14,Studio.LILAC,true);sample.setGravity(Gravity.CENTER);
        introduction.addView(sample,ui.lp(-2,-2));
        sample.setMinHeight(dp(48));
        if(getResources().getConfiguration().fontScale>1.25f || getResources().getConfiguration().screenWidthDp<360){
            introduction.setOrientation(LinearLayout.VERTICAL);
            heroTitle.setLayoutParams(ui.lp(-1,-2));
        }
        ui.action(sample,"Послушать голос",()->{
            if(speech==null)return;
            speech.stop();
            speech.say(lines.greeting());
        });
        aura=new AuraView(this);
        int portraitHeight=Math.max(150,Math.min(234,getResources().getConfiguration().screenHeightDp-510));
        voicePanel.addView(aura,ui.lp(-1,portraitHeight));
        LinearLayout talk=ui.row();talk.setGravity(Gravity.CENTER);
        talk.setBackground(ui.shape(0xffe0c6fa,22,0));voicePanel.addView(talk,ui.lp(-1,48));
        heroMic=ui.icon("mic",Studio.BG);talk.addView(heroMic,ui.lp(23,23));ui.gap(talk,9);
        heroAction=ui.text("Говорить",18,Studio.BG,true);talk.addView(heroAction);
        ui.action(voicePanel,"Говорить",this::voiceAction);
        ui.gap(dashboard,14);
        TextView section=ui.text("Найти на телефоне",20,Studio.TEXT,true);
        dashboard.addView(section);ui.gap(dashboard,10);
        LinearLayout cards=ui.row();dashboard.addView(cards);
        card(cards,"photo","Фото","По описанию",Studio.MINT,0xff193034,0xff18292f,()->compose("Найди фото, на котором "));
        ui.gap(cards,8);
        card(cards,"video","Видео","По кадру",Studio.LILAC,0xff272742,0xff202234,()->compose("Найди видео, где "));
        ui.gap(dashboard,8);
        LinearLayout extras=ui.row();dashboard.addView(extras);
        card(extras,"doc","Файлы","По тексту",Studio.PEACH,0xff302a31,0xff28232b,()->compose("Найди файл со словами "));
        ui.gap(extras,8);
        card(extras,"apps","Приложения","По назначению",0xffaaceff,0xff1b2b40,0xff1a2334,()->compose("Найди приложение для "));
        LinearLayout shortcuts=ui.row();dashboard.addView(shortcuts);ui.gap(dashboard,2);
        actionLabel=ui.text("Галерея",15,Studio.MUTED,false);actionLabel.setGravity(Gravity.CENTER);
        shortcuts.addView(actionLabel,new LinearLayout.LayoutParams(0,dp(48),1));
        ui.action(actionLabel,"Открыть галерею",this::gallery);
        TextView actions=ui.text("Действия на телефоне",15,Studio.MINT,true);actions.setGravity(Gravity.CENTER);
        shortcuts.addView(actions,new LinearLayout.LayoutParams(0,dp(48),1.6f));
        ui.action(actions,"Действия на телефоне",this::phoneMenu);
        TextView history=ui.text("История запросов",15,Studio.LILAC,true);history.setGravity(Gravity.CENTER);
        dashboard.addView(history,ui.lp(-1,48));ui.action(history,"История запросов",()->journal.show(this));

        LinearLayout output=ui.column();output.setPadding(0,dp(12),0,0);results=output;body.addView(output);results.setVisibility(View.GONE);
        feedbackScroll=new ScrollView(this){
            @Override protected void onMeasure(int width,int height){
                if(!hits.isEmpty()){
                    int cap=Math.min(MeasureSpec.getSize(height),dp(hasSearch?80:160));
                    height=MeasureSpec.makeMeasureSpec(cap,MeasureSpec.AT_MOST);
                }
                super.onMeasure(width,height);
            }
        };feedbackScroll.setFillViewport(false);output.addView(feedbackScroll,ui.lp(-1,-2));
        status=ui.text("",17,Studio.TEXT,false);status.setPadding(dp(14),dp(12),dp(14),dp(12));status.setBackground(ui.shape(0xff22212e,16,Studio.EDGE));
        status.setLineSpacing(dp(2),1);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        feedbackScroll.addView(status);
        contractRecovery=ui.column();output.addView(contractRecovery,ui.lp(-1,-2));contractRecovery.setVisibility(View.GONE);
        TextView retryContract=ui.text("Повторить вопрос",16,Studio.LILAC,true);
        retryContract.setGravity(Gravity.CENTER);retryContract.setBackground(ui.surface(Studio.PANEL,14,Studio.EDGE));
        contractRecovery.addView(retryContract,ui.lp(-1,48));
        ui.action(retryContract,"Повторить вопрос",()->answerContract(failedContractQuestion));
        TextView localContract=ui.text("Найти цитаты на телефоне",16,Studio.MINT,true);
        localContract.setGravity(Gravity.CENTER);contractRecovery.addView(localContract,ui.lp(-1,48));
        ui.action(localContract,"Найти цитаты на телефоне",()->answerContract(failedContractQuestion,true));
        photoLibraryButton=ui.text("Вся библиотека Google Фото ↗",16,Studio.MINT,true);
        photoLibraryButton.setGravity(Gravity.CENTER);photoLibraryButton.setBackground(ui.surface(0xff253530,14,Studio.EDGE));
        ui.action(photoLibraryButton,"Показать результаты в Google Фото",this::openPhotoLibrary);
        output.addView(photoLibraryButton,ui.lp(-1,48));photoLibraryButton.setVisibility(View.GONE);
        folderRecovery=ui.text("Добавить папку и повторить поиск",16,Studio.MINT,true);folderRecovery.setGravity(Gravity.CENTER);
        folderRecovery.setBackground(ui.surface(Studio.PANEL,14,Studio.EDGE));output.addView(folderRecovery,ui.lp(-1,48));
        ui.action(folderRecovery,"Добавить папку и повторить поиск",()->{if(Build.VERSION.SDK_INT>=30 && !PhoneSearch.allFiles())sharedDocumentAccess();else chooseTree(RETRY_FOLDER);});folderRecovery.setVisibility(View.GONE);
        list=new GridView(this);list.setColumnWidth(dp(142));list.setNumColumns(1);
        list.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);list.setHorizontalSpacing(dp(6));list.setVerticalSpacing(dp(6));
        list.setSelector(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));list.setPadding(0,dp(6),0,dp(8));list.setClipToPadding(false);
        adapter=new MediaResults(ui,files::menu);list.setAdapter(adapter);
        list.setOnItemClickListener((p,v,pos,id)->open(adapter.getItem(pos)));
        list.setOnItemLongClickListener((parent,v,pos,id)->{
            var h=adapter.getItem(pos);book.choose(name->{book.add(name,h);book.show(name);});return true;
        });
        output.addView(list,new LinearLayout.LayoutParams(-1,0,1));

        inputBar=ui.row();inputBar.setPadding(dp(13),0,dp(4),0);inputBar.setBackground(ui.shape(Studio.PANEL,17,Studio.EDGE));page.addView(inputBar,ui.lp(-1,52));
        inputBar.addView(ui.icon("keyboard",Studio.MUTED),ui.lp(21,21));ui.gap(inputBar,10);
        field=new EditText(this);field.setTextSize(16);field.setSingleLine(true);field.setPadding(0,0,0,0);field.setBackground(null);
        field.setTextColor(Studio.TEXT);field.setHintTextColor(Studio.MUTED);field.setHint("Введите команду…");field.setContentDescription("Текст команды");
        field.setImeOptions(EditorInfo.IME_ACTION_SEARCH);inputBar.addView(field,new LinearLayout.LayoutParams(0,-1,1));
        field.setOnEditorActionListener((v,id,e)->{if(id==EditorInfo.IME_ACTION_SEARCH||(e!=null && e.getAction()==KeyEvent.ACTION_DOWN && e.getKeyCode()==KeyEvent.KEYCODE_ENTER)){submit();return true;}return false;});
        ImageView send=ui.iconButton("arrow","Выполнить команду",Studio.LILAC,this::submit);send.setBackground(ui.surface(0x00000000,14,0));inputBar.addView(send,ui.lp(48,48));
        
        if(this instanceof AssistPanel panel){
            searchTools.getChildAt(0).setVisibility(View.GONE);
            searchTools.getChildAt(1).setVisibility(View.GONE);
            field.setHint("Спросите Марию…");
            field.setOnClickListener(v->{if(micMode==AuraView.Mode.LISTEN)speech.stop();});
            panel.decorate(ui,page,header,this::screenActions);
        }
        page.requestFocus();
    }
    private void screenActions(){
        new AlertDialog.Builder(this).setTitle("Действия с экраном")
            .setItems(new String[]{"Проложить маршрут по адресу","Скопировать номер","Отправить файл…","Что на экране?","Описать изображение…"},(d,i)->{
                if(i==2){speech.stop();inputBar.setVisibility(View.VISIBLE);compose("Отправь этот файл ");return;}
                field.setText(switch(i){case 0 -> "проложи туда маршрут";case 1 -> "скопируй этот номер";case 3 -> "что на экране";default -> "опиши изображение на экране";});submit();
            }).setNegativeButton("Закрыть",null).show();
    }
    private View card(LinearLayout row,String icon,String title,String sub,int tint,int start,int end,Runnable click){
        LinearLayout card=ui.column();ui.tintCard(card,start,end);card.setPadding(dp(15),dp(10),dp(14),dp(10));
        LinearLayout head=ui.row();card.addView(head);head.addView(ui.icon(icon,tint),ui.lp(24,24));head.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));head.addView(ui.icon("up",Studio.MUTED),ui.lp(16,16));
        ui.gap(card,6);card.addView(ui.text(title,18,Studio.TEXT,true));ui.gap(card,3);card.addView(ui.text(sub,13,Studio.MUTED,false));
        row.addView(card,new LinearLayout.LayoutParams(0,-2,1));ui.action(card,title+". "+sub,click);return card;
    }
    private void sources(){
        List<PhoneSearch.Hit> files=SelectedItems.list(this);
        long photos=files.stream().filter(h->SelectedItems.PHOTOS.equals(h.path())).count();
        String[] actions={"Папки телефона","Добавить снимки ("+photos+")",
            "Добавить файлы с Диска или телефона ("+(files.size()-photos)+")",
            DriveFiles.account(this).isEmpty()?"Подключить Google Диск целиком":"Аккаунт Google Диска","Искать в приложении Google Диск",PhoneSearch.allFiles()?"Доступ ко всей общей памяти · включён":"Разрешить поиск по общей памяти"};
        new AlertDialog.Builder(this).setTitle("Источники единого поиска").setItems(actions,(d,i)->{
            if(i==5)sharedDocumentAccess();
            else if(i==0)folders();
            else if(i==1||i==2)pickItems(i==1);
            else if(i==4)searchGoogleApp(GoogleSearch.Source.DRIVE);
            else if(DriveFiles.account(this).isEmpty())chooseAccount();
            else new AlertDialog.Builder(this).setTitle("Google Диск").setMessage(DriveFiles.account(this))
                    .setPositiveButton("Сменить аккаунт",(x,w)->chooseAccount())
                    .setNegativeButton("Отключить",(x,w)->{DriveFiles.account(this,"");goHome();}).show();
        }).setNegativeButton("Закрыть",null).show();
    }
    private void pickItems(boolean photos){
        Intent pick=new Intent(photos?Intent.ACTION_GET_CONTENT:Intent.ACTION_OPEN_DOCUMENT);
        pick.setType(photos?"image/*":"*/*").addCategory(Intent.CATEGORY_OPENABLE)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION).putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        try{startActivityForResult(pick,photos?PICK_PHOTO:PICK_FILE);}
        catch(ActivityNotFoundException|SecurityException ex){feedback("Приложение для выбора файлов недоступно. Проверьте системный файловый менеджер.");}
    }
    private void chooseAccount(){
        String active=DriveFiles.account(this);
        android.accounts.Account selected=active.isEmpty()?null:new android.accounts.Account(active,"com.google");
        Intent pick=new Intent("com.google.android.gms.common.account.CHOOSE_ACCOUNT")
                .setPackage("com.google.android.gms")
                .putExtra("allowableAccountTypes",new String[]{"com.google"})
                .putExtra("alwaysPromptForAccount",true)
                .putExtra("selectedAccount",selected)
                .putExtra("descriptionTextOverride","Аккаунт для поиска на Google Диске");
        try {
            startActivityForResult(pick,ACCOUNT);
        } catch(ActivityNotFoundException|SecurityException unavailable) {
            try { startActivityForResult(android.accounts.AccountManager.newChooseAccountIntent(
                    selected,null,new String[]{"com.google"},"Для поиска на Google Диске",null,null,null),ACCOUNT);
            } catch(ActivityNotFoundException|SecurityException missing){feedback("Google-аккаунты недоступны. Можно добавить файлы через системный выбор файлов.");}
        }
    }
    private void connectDrive(String name){
        android.accounts.AccountManager manager=android.accounts.AccountManager.get(this);
        manager.getAuthToken(new android.accounts.Account(name,"com.google"),DriveFiles.SCOPE,null,this,future->{
            try{
                String token=future.getResult().getString(android.accounts.AccountManager.KEY_AUTHTOKEN);
                if(token==null)throw new java.io.IOException();
                feedback("Проверяю доступ к файлам на Google Диске…");
                worker.submit(()->{
                    try{
                        DriveFiles.verify(this,name);
                        DriveFiles.account(this,name);
                        runOnUiThread(()->feedback("Google Диск подключён. Теперь можно сказать «Найди договор»."));
                    }catch(Exception unavailable){
                        runOnUiThread(()->feedback("Не удалось прочитать Google Диск. Проверьте сеть и доступ Марии к Drive API. Отдельные файлы можно добавить в «Источниках поиска»."));
                    }
                });
            }catch(Exception e){
                String message=String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);
                String cause=e instanceof android.accounts.OperationCanceledException?"Выбор или авторизация отменены.":
                    message.contains("unregistered")||message.contains("invalid_client")?"Google не распознал OAuth-клиент этой сборки.":
                    e instanceof java.io.IOException?"Не удалось связаться с сервисом авторизации.":
                    "Сервис Google не выдал доступ ("+e.getClass().getSimpleName()+").";
                feedback(cause+" Поиск по всему Диску пока выключен.");
            }
        },null);
    }
    private void importItems(Intent data,boolean photos){
        Set<Uri> selected=new LinkedHashSet<>();
        if(data.getData()!=null)selected.add(data.getData());
        ClipData batch=data.getClipData();
        if(batch!=null)for(int i=0;i<batch.getItemCount();i++){
            Uri uri=batch.getItemAt(i).getUri();if(uri!=null)selected.add(uri);
        }
        invalidateWork();int token=generation;busy=true;hasSearch=false;hits=Collections.emptyList();adapter.set(hits);
        refreshVoice();feedback("Добавляю выбранные файлы в поиск…");
        pending=worker.submit(()->{
            int done=0;for(Uri uri:selected){
                if(Thread.currentThread().isInterrupted())return;
                try{SelectedItems.add(getApplicationContext(),uri,photos);done++;}catch(Exception ignored){}
            }
            String report="Добавлено в поиск: "+done+" из "+selected.size()+".";
            runOnUiThread(()->{if(generation==token){busy=false;refreshVoice();feedback(report);}});
        });
    }
    private void compose(String prefix){
        field.setText(prefix);field.requestFocus();field.setSelection(field.length());
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(field,InputMethodManager.SHOW_IMPLICIT);
    }
    private void submit(){if(field.getText().toString().trim().isEmpty()){compose("");return;}dispatch(false);}
    private void displayResults(boolean visible){
        if(inResults!=visible)inputBar.setVisibility(visible?View.GONE:View.VISIBLE);
        inResults=visible;
        homeTools.setVisibility(visible?View.GONE:View.VISIBLE);searchTools.setVisibility(visible?View.VISIBLE:View.GONE);
        smallAvatar.setVisibility(visible?View.VISIBLE:View.GONE);
        headerTitle.setText(visible?(hasSearch?"Поиск":"Мария"):"МАРИЯ");headerTitle.setLetterSpacing(visible?0:.15f);
        home.setVisibility(visible?View.GONE:View.VISIBLE);results.setVisibility(visible?View.VISIBLE:View.GONE);back.setVisibility(visible && !(this instanceof AssistPanel)?View.VISIBLE:View.GONE);
        if(this instanceof AssistPanel)inputBar.setVisibility(View.VISIBLE);
    }
    private void goHome(){
        turn=voiceTurn=0;awaitingMediaClue=false;questionOnReturn=false;mediaCandidates=Collections.emptySet();promises.clear();
        
        contract=null;noteObject="";photosOnly=false;lastQuery="";dateFilter="";within=null;field.setHint("Введите команду…");
        invalidateWork();speech.stop();busy=false;speaking=false;micMode=AuraView.Mode.READY;hasSearch=false;
        hits=Collections.emptyList();adapter.set(hits);field.setText("");page.requestFocus();displayResults(false);refreshVoice();
    }
    @Override public void onBackPressed(){if(this instanceof AssistPanel){finish();return;}if(inResults)goHome();else super.onBackPressed();}
    private void voiceAction(){
        if(promises.pending()&&micMode==AuraView.Mode.READY){busy=false;voice();return;}
        if(hasSearch&&!hits.isEmpty()&&micMode==AuraView.Mode.READY){busy=false;voice();return;}
        if(busy){invalidateWork();hasSearch=false;busy=false;feedback("Остановлено.");refreshVoice();return;}
        if(speaking){speech.stop();speaking=false;refreshVoice();return;}
        voice();
    }
    private void refreshVoice(){
        AuraView.Mode mode=micMode!=AuraView.Mode.READY?micMode:busy?AuraView.Mode.WORK:speaking?AuraView.Mode.SPEAK:AuraView.Mode.READY;
        aura.mode(mode);smallAvatar.mode(mode);boolean active=mode!=AuraView.Mode.READY;
        String label=switch(mode){case LISTEN->"Завершить запись";case WORK->busy?"Остановить":"Распознаю…";case SPEAK->"Остановить голос";default->"Говорить";};
        if((promises.pending()||hasSearch&&!hits.isEmpty())&&micMode==AuraView.Mode.READY){label="Говорить";active=false;}
        heroAction.setText(label);voicePanel.setContentDescription(label);heroMic.setImageDrawable(ui.glyph(active?"stop":"mic",Studio.BG));
        resultMic.setContentDescription(label);resultMic.setImageDrawable(ui.glyph(active?"stop":"mic",Studio.BG));
        resultMic.setBackground(ui.surface(mode==AuraView.Mode.LISTEN?Studio.MINT:Studio.LILAC,16,0));
    }
    private void feedback(String message){feedback(message,turn);}
    private void feedback(String message,long answerTurn){
        failedContractQuestion="";contractRecovery.setVisibility(View.GONE);folderRecovery.setVisibility(View.GONE);
        photoLibraryButton.setVisibility(hasSearch && photoLibraryQuery!=null?View.VISIBLE:View.GONE);
        if(!message.startsWith("Проверено:") && !message.equals("Ищу на телефоне и Диске…"))journal.add(answerTurn,"Экран",message);
        displayResults(true);status.setText(message);
        boolean standalone=hits.isEmpty();
        feedbackScroll.setLayoutParams(standalone?new LinearLayout.LayoutParams(-1,0,1):ui.lp(-1,-2));
        list.setVisibility(standalone?View.GONE:View.VISIBLE);
    }
    private SpokenCommand pendingVideoSearch;
    private boolean askedVideoAccess;
    private boolean granted(String permission) { return checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED; }
    private String photoPermission() { return Build.VERSION.SDK_INT>=33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE; }
    private boolean partialGallery() { return Build.VERSION.SDK_INT>=34 && granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED); }
    @Override protected void onResume() {
        super.onResume();resumed=true;
        if(page!=null && !confirming && (!ScreenTask.unlocked(this) || manuallyLocked())){finish();return;}
        if(actionLabel==null || isFinishing())return;
        actionLabel.setText(granted(photoPermission()) ? "Открыть галерею" : partialGallery() ? "Выбранные фото" : "Подключить галерею");
    }
    @Override protected void onPause(){resumed=false;super.onPause();}
    @Override protected void onRestart(){
        super.onRestart();
        if(page!=null && !confirming && !ScreenTask.unlocked(this))finish();
        showingPhotoLibrary=false;
    }
    private void gallery() {
        
        if (granted(photoPermission())) {
            photosOnly=false;within=null;dateFilter="";field.setText("фото"); search(); return;
        }
        String[] permissions=Build.VERSION.SDK_INT>=34
                ? new String[]{photoPermission(),Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}
                : new String[]{photoPermission()};
        requestPermissions(permissions,GALLERY);
    }
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] results) {
        super.onRequestPermissionsResult(code,perms,results);
        if(page==null || isFinishing())return;
        if(code==28){
            SpokenCommand cmd=pendingVideoSearch;
            pendingVideoSearch=null;
            if(cmd!=null)search(cmd.text(),cmd.kind()==SpokenCommand.Kind.OPEN,cmd.latest());
            return;
        }
        if(code==CalendarNotes.PERMISSION){calendarNotes.permitted();return;}
        if(code==Today.CALENDAR){if(today!=null)today.refresh();return;}
        if(code==23){String command=calendarRequest;calendarRequest="";
            if(!command.isEmpty()&&granted(Manifest.permission.READ_CALENDAR))agenda(command);else reply("Для просмотра встреч нужен доступ к календарю.");return;}
        if(code==PromiseDialog.CALENDAR){if(granted(Manifest.permission.READ_CALENDAR))promises.calendar();else promises.ask();return;}
        if(code==19){Runnable action=notificationAction;notificationAction=null;if(action!=null&&granted(Manifest.permission.POST_NOTIFICATIONS))action.run();else feedback("Чтобы напоминание появилось, разрешите уведомления Марии.");return;}
        if (code==MIC) {
            if (granted(Manifest.permission.RECORD_AUDIO)) speech.listen();
            else feedback("Разрешите микрофон для голосового ввода или введите команду.");
            return;
        }
        if (code!=GALLERY) return;
        if (granted(photoPermission()) || partialGallery()) {
            if (field.length()==0) field.setText("фото");
            search();
        } else feedback("Для поиска фото откройте «Папки» и выберите папку с фотографиями или разрешите доступ к галерее в настройках Android.");
    }
    private void folders() {
        List<UriPermission> existing=getContentResolver().getPersistedUriPermissions();
        if (existing.isEmpty()) { chooseTree(); return; }
        String[] names=new String[existing.size()];
        for (int i=0;i<names.length;i++) names[i]=DocumentsContract.getTreeDocumentId(existing.get(i).getUri());
        new AlertDialog.Builder(this).setTitle("Папки для поиска").setItems(names,(dialog,i)->{
            new AlertDialog.Builder(this).setMessage("Убрать из поиска «"+names[i]+"»?")
                    .setPositiveButton("Убрать",(d,w)->{
                        getContentResolver().releasePersistableUriPermission(existing.get(i).getUri(),Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        search();
                    }).setNegativeButton("Отмена",null).show();
        }).setPositiveButton("Добавить папку",(d,w)->chooseTree()).setNegativeButton("Закрыть",null).show();
    }
    private void sharedDocumentAccess(){
        if(Build.VERSION.SDK_INT<30){folders();return;}
        Intent settings=new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:"+getPackageName()));
        try{startActivityForResult(settings,SHARED_DOCUMENT_ACCESS);}
        catch(ActivityNotFoundException unavailable){feedback("Android не открыл настройки доступа к общей памяти. Можно выбрать папки в источниках поиска.");}
    }
    private void chooseTree(){chooseTree(TREE);}
    private void chooseTree(int request) {
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(pick,request); }
        catch(ActivityNotFoundException|SecurityException unavailable){feedback("Выбор папки недоступен. Проверьте системный файловый менеджер.");}
    }
    private void voice() {
        if(micMode!=AuraView.Mode.LISTEN){
            voiceTurn=turn=journal.begin("Микрофон","Голосовой ввод");
            record("Микрофон","Запрошено распознавание");
        }
        invalidateWork();
        if (granted(Manifest.permission.RECORD_AUDIO)) speech.listen();
        else requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC);
    }
    private long invalidateWork() {
        generation++;
        if (pending!=null) pending.cancel(true);
        long id=sequence.incrementAndGet();
        activeNativeToken=id;
        LocalAnswer.cancel(id);
        return id;
    }
    private boolean lastMemoryQuestion;
    private void dispatch(boolean spoken) {
        dispatch(spoken,true);
    }
    private void dispatch(boolean spoken,boolean userCommand) {
        if(isFinishing() || confirming || !ScreenTask.unlocked(this))return;
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(field.getWindowToken(),0);
        if(inResults){page.requestFocus();if(!(this instanceof AssistPanel))inputBar.setVisibility(View.GONE);}
        speech.stop();
        String transcript=field.getText().toString();
        if(spoken && voiceTurn!=0){
            turn=voiceTurn;journal.recognized(turn,transcript);record("Распознано",transcript);
        }else turn=journal.begin(spoken?"Голос":"Запрос",transcript);
        String original=userCommand?CompanionLines.command(transcript):transcript;
        voiceTurn=0;
        spokenTurn=spoken;
        long previousClarification=clarifiedAt;
        if(userCommand && (clarification.isEmpty() || SystemClock.elapsedRealtime()-clarifiedAt>=120000) && practical(original)){if(clarifiedAt==previousClarification)clarification="";return;}
        if(userCommand && original.equalsIgnoreCase("настройки понимания запросов")){assistantPrivacy();return;}
        if(userCommand && !clarification.isEmpty()){
            String previous=clarification;clarification="";
            if(SystemClock.elapsedRealtime()-clarifiedAt<120000 && !original.isBlank() &&
                    !original.matches("(?iu)^(?:отмена|стоп|забудь)[.! ]*$")){
                understand(original,previous);return;
            }
            if(original.matches("(?iu)^(?:отмена|стоп|забудь)[.! ]*$")){reply("Хорошо.");return;}
        }
        boolean waiting=awaitingMediaClue && hasSearch && inResults;
        awaitingMediaClue=false;questionOnReturn=false;
        String follow=original.toLowerCase(Locale.ROOT).replaceAll("[,.!?]+"," ").replaceAll("\\s+"," ").strip();
        if(userCommand && PhoneCleanup.requested(original)){invalidateWork();busy=false;refreshVoice();cleanup.open();return;}
        if(userCommand && screenCommand(original))return;
        DeviceStatus.Request device=userCommand?DeviceStatus.parse(original,lastMemoryQuestion):null;
        lastMemoryQuestion=device!=null && (device.disk()||device.ram());
        Directions directions=userCommand?Directions.parse(original):null;
        if(device!=null || directions!=null){
            invalidateWork();contract=null;hasSearch=false;within=null;photoLibraryQuery=null;showItems(Collections.emptyList());
            if(device!=null){
                record("Маршрут","Состояние телефона · Android");
                String reading=DeviceStatus.read(this,device);
                record("Источник","Данные Android · "+reading);reply(reading);return;
            }
            String stops=directions.stops().isEmpty()?"":" через "+String.join(", затем ",directions.stops());
            record("Маршрут","Построение в Google Картах · "+directions.target()+stops);
            try{
                startActivity(directions.maps());
                record("Действие","Маршрут передан Google Картам · "+directions.target()+stops);
                feedback("Открыла маршрут до "+directions.destination()+stops+".");
            }catch(ActivityNotFoundException e){
                try{startActivity(new Intent(Intent.ACTION_VIEW,directions.uri()));record("Действие","Маршрут открыт по ссылке Google Карт");feedback("Открыла маршрут в браузере.");}
                catch(ActivityNotFoundException|SecurityException failure){reply("Не удалось открыть карты на телефоне.");}
            }catch(SecurityException e){reply("Android не разрешил открыть Google Карты.");}
            return;
        }
        String social=userCommand && !promises.pending() && !showingNotes.pending() && noteObject.isEmpty()?lines.social(original):null;
        if(social!=null){
            invalidateWork();awaitingMediaClue=waiting;smallAvatar.react(true);aura.react(true);reply(social);return;
        }
        if(userCommand && hasSearch && follow.matches("(?:(?:а теперь|теперь|покажи|ищи|найди|поищи|посмотри|открой|проверь|результаты|это|ещё|еще|тоже|только|и|в|на) )*(?:google|гугл) (?:фото|photos|диске?|drive)")){
            if(follow.endsWith("фото") || follow.endsWith("photos")){
                if(photoLibraryQuery==null)photoLibraryQuery=GoogleSearch.forPhotoQuery(lastQuery,ContentRequest.parse(lastQuery),dateFilter);
                if(photoLibraryQuery!=null){openPhotoLibrary();return;}
            }else{within=null;search(lastQuery,false,false,SearchMode.DRIVE,false);return;}
        }
        if(userCommand && currentMedia()!=null && follow.matches(".*\\b(?:за вс[её] время|за весь период|без ограничени[йя] по дате|за все даты)\\b.*")){
            understand(original);return;
        }
        if(waiting && userCommand){
            if(follow.matches("(?:(?:я |больше )?не (?:помню|знаю)(?: ничего| точно)?|без уточнения|покажи (?:все|всё|результаты)|пропусти|оставь как есть|отмена)")){
                reply("Оставила найденные варианты на экране.");return;
            }
            if(!follow.isBlank() && !MediaClue.newCommand(follow) && !SearchJournal.requested(original)
                    && GoogleSearch.parse(original,GoogleSearch.Source.PHONE)==null){
                MediaClue clue=MediaClue.parse(original);
                if(!clue.period().isEmpty())dateFilter=clue.period();
                else if(dateFilter.isEmpty())dateFilter=MediaClue.parse(lastQuery).period();
                boolean video=new PhoneSearch.Query(lastQuery).videos || ContentRequest.parse(lastQuery)!=null && ContentRequest.parse(lastQuery).video();
                within=mediaCandidates;
                record("Уточнение","К запросу «"+lastQuery+"» · "+original);
                search(clue.query(lastQuery,video),false,false,searchMode,true);return;
            }
        }
        if(SearchJournal.requested(original)){
            record("Экран","Открыта история запросов");journal.show(this);return;
        }
        if(userCommand && PhoneTasks.requestsGoogleDevices(original)){
            record("Маршрут","Устройства Google-аккаунта");
            Intent devices=new Intent(Intent.ACTION_VIEW,Uri.parse("https://myaccount.google.com/device-activity"));
            invalidateWork();hasSearch=false;contract=null;lastAppQuery="";photoLibraryQuery=null;showItems(Collections.emptyList());
            try{
                startActivity(devices);
                record("Источник","Google Аккаунт · открыта страница устройств");
                reply("Открыла страницу «Ваши устройства» в Google. На ней видны устройства выбранного аккаунта.");
            }catch(ActivityNotFoundException | SecurityException e){reply("Не удалось открыть страницу устройств Google на телефоне.");}
            return;
        }
        GoogleSearch explicit=GoogleSearch.parse(original,GoogleSearch.Source.PHONE);
        if(explicit!=null && explicit.source()==GoogleSearch.Source.PHOTOS){
            String terms=explicit.terms();
            boolean video=terms.matches("(?iu)^(?:видео|ролик|видеоролик)(?:[ ,].*)?$");
            String topic=video?terms.replaceFirst("(?iu)^\\S+[ ,]*",""):terms;
            MediaClue parts=MediaClue.parse(topic);
            if(!parts.period().isEmpty())topic=parts.text();
            photosOnly=false;contract=null;noteObject="";within=null;dateFilter=parts.period();
            String query=video?(topic.isEmpty()?"видео":"видео, где "+topic):(topic.isEmpty()?"фото":"фото, где "+topic);
            search(query,false,false,SearchMode.GOOGLE_PHOTOS,false);return;
        }
        RecallSearch recall=userCommand && noteObject.isEmpty() && !promises.pending() && !showingNotes.pending() && explicit==null
                ? RecallSearch.parse(original) : null;
        String raw=recall==null?original:"Найди "+recall.query();
        spokenTurn=spoken;
        if(userCommand&&Today.command(raw)){showToday(spoken);return;}
        if(userCommand&&raw.strip().matches("(?iu)(?:покажи |открой )?последний ответ(?: по договору)?[.!?]*")){
            lastContractAnswer();return;
        }
        String phoneCommand=raw.strip().toLowerCase(Locale.ROOT).replaceFirst("^(?:джарвис|джервис|jarvis)[,. ]+","")
                .replaceFirst("^пожалуйста[, ]+","").replaceAll("[.!?]+$","").replaceAll("\\s+"," ").strip();
        phoneCommand=phoneCommand.replaceFirst("^(?:ну (?:вот |так )?|а )","").strip();
        if(userCommand && phoneCommand.matches("где (?:ты )?(?:(?:его|её|это) )?(?:искал|искала|ищешь)(?: это| его| её)?")){
            reply(journal.lastSources());return;
        }
        if(userCommand && phoneCommand.matches("что ты (?:вообще )?(?:умеешь|можешь)(?: .*|$)")){showCommands();return;}
        if(userCommand && phoneCommand.matches("(?:найди (?:мне )?(?:его|её|ее) и открой|открой (?:мне )?(?:его|её|ее|это приложение|приложение на телефоне))") && !lastAppQuery.isEmpty()){
            phoneCommand="открой приложение "+lastAppQuery;
        }
        if(userCommand && phoneCommand.matches("(?:у меня |на телефоне |точно )+есть приложение .+"))
            phoneCommand=phoneCommand.replaceFirst("^.*?есть приложение ","найди приложение ");
        if(userCommand && (phoneCommand.matches("(?:найди|поищи|открой|покажи|запусти) (?:мне )?приложение .+")
                || phoneCommand.endsWith("ассистента") || phoneCommand.endsWith("ассистента google") || phoneCommand.startsWith("открой настройки"))
                && PhoneTasks.handle(this,phoneCommand)){
            invalidateWork();busy=false;refreshVoice();return;
        }
        if(userCommand && contract!=null && (recall!=null || SpokenCommand.datedVideo(raw)!=null)){contract=null;lastContractTurn="";}
        if(userCommand && contract!=null && cloudReady()){
            String intent=raw.strip().toLowerCase(Locale.ROOT).replaceAll("[.!?]+$","");
            if(raw.strip().matches("(?iu)(закрой договор|выйти из договора)[.!?]*")){
                invalidateWork();contract=null;lastContractTurn="";showItems(Collections.emptyList());reply("Договор закрыт.");return;
            }
            if(intent.matches("(найди|поищи|ищи) (фото(графии)?|договор|документ|файл|другой договор)( .*|$)") || intent.matches("открой первый (договор|файл|документ)( .*|$)")){
                contract=null;lastContractTurn="";
            }
        }
        if(userCommand&&promises.handle(raw,noteObject))return;
        if(userCommand&&showingNotes.handle(raw))return;
        if(userCommand&&promiseActions.handle(raw))return;
        if(!noteObject.isEmpty()){String name=noteObject;noteObject="";book.note(name,raw);return;}
        String command=phoneCommand;
        if(userCommand&&command.matches("что у меня сегодня|выбери календарь показов|(?:открой |проложи )?маршрут (?:к следующему|на следующий) показу?")){agenda(command);return;}
        ResultAction selection=ResultAction.parse(command);
        if(userCommand && selection!=null){
            invalidateWork();busy=false;refreshVoice();
            var hit=selection.select(hits,lastQuery);
            if(hit==null)reply("В текущих результатах нет такого файла. Проверьте номер и источник.");
            else if(selection.share())files.external(hit,Intent.ACTION_SEND,true);
            else if(selection.drive())files.openDrive(hit);
            else open(hit);
            return;
        }
        if(userCommand && command.matches("что (?:ты умеешь|ты можешь сделать на телефоне)|(?:покажи )?команды телефона")){showCommands();return;}
        if(userCommand && PhoneTasks.handle(this,command)){invalidateWork();busy=false;refreshVoice();return;}
        if(contract!=null && !raw.toLowerCase(Locale.ROOT).matches("^(найди|ищи|поищи|покажи фото|открой первый).*")){understand(raw);return;}
        if(refinement(raw))return;
        String phrase=raw.toLowerCase(Locale.ROOT).strip();
        if(phrase.startsWith("запиши ")||phrase.startsWith("добавь заметку ")){
            String note=raw.substring(raw.indexOf(' ')+1).replaceFirst("(?iu)^(?:заметку|по этому объекту)[:, ]+","");
            if(book.current.isEmpty())book.choose(name->book.note(name,note));else book.note(book.current,note);return;
        }
        if(phrase.startsWith("открой объект ")||phrase.startsWith("что у меня есть по ")){
            String term=phrase.replaceFirst("^(открой объект |что у меня есть по )","").replaceAll("[?.!]$","");
            for(String name:getSharedPreferences("objects",0).getAll().keySet())if(name.toLowerCase(Locale.ROOT).contains(term)){book.show(name);return;}
            book.choose(book::show);return;
        }
        if(phrase.startsWith("собери ")||phrase.startsWith("подготовь подборку")){
            String request=phrase.replaceFirst("^(собери|подготовь подборку)\\s*","").trim();
            if(book.current.isEmpty())book.choose(name->suggestBundle(name,request));else suggestBundle(book.current,request);return;
        }
        String mediaFollowup=hasSearch && new PhoneSearch.Query(lastQuery).videos
                ? SpokenCommand.datedVideo("видео "+raw) : null;
        SpokenCommand cmd=mediaFollowup!=null ? new SpokenCommand(SpokenCommand.Kind.FIND,mediaFollowup,false) : SpokenCommand.parse(raw,spoken);
        boolean directSearch=cmd.kind()==SpokenCommand.Kind.PICK || recall!=null || explicit!=null || mediaFollowup!=null
                || SpokenCommand.datedVideo(raw)!=null || raw.matches("(?iu)^(?:фото|видео|ролики|файл[ы]?|документ[ы]?|pdf|пдф)(?:\\s+.*)?$")
                || raw.matches("(?iu)^(?:найди|поищи|ищи|найти|открой|открыть|покажи|покажите) (?:мне )?(?:фото|видео|документ|файл|ролик|pdf|пдф|скрин|договор).*")
                || (!spoken && cmd.kind()==SpokenCommand.Kind.FIND && !raw.strip().contains(" "));
        if(userCommand && !directSearch && !raw.isBlank()){understand(raw);return;}
        photosOnly=false;
        dateFilter=recall==null?"":recall.period();within=null;contract=null;
        GoogleSearch cloud=explicit;
        if(cloud!=null){
            String q=cloud.terms();
            if(q.startsWith("type:pdf"))q=q.length()==8?"pdf":"pdf "+q.substring(8).trim();
            MediaClue parts=MediaClue.parse(q);
            if(!parts.period().isEmpty()){q=parts.text();dateFilter=parts.period();}
            RecallSearch scene=RecallSearch.parse("Найди "+q);
            if(scene!=null && ContentRequest.parse(scene.query())!=null && ContentRequest.parse(scene.query()).photo())q=scene.query();
            search(q,false,false,SearchMode.DRIVE,false);return;
        }
        if (cmd.kind()==SpokenCommand.Kind.PICK) {
            invalidateWork();
            int i=Integer.parseInt(cmd.text());
            busy=false;refreshVoice();
            if (i<hits.size()) open(hits.get(i));
            else reply("Такого результата пока нет. Сначала скажите, что найти.");
        } else if (cmd.kind()==SpokenCommand.Kind.ANSWER) {
            long id=invalidateWork();
            int token=generation;
            record("Маршрут","Ответ языковой модели на телефоне");hasSearch=false;
            hits=Collections.emptyList(); adapter.set(hits);
            busy=true;refreshVoice();feedback("Готовлю ответ на телефоне…");
            pending=worker.submit(()->{
                String answer=LocalAnswer.answer(getApplicationContext(),raw,id);
                runOnUiThread(()->{if (generation==token) reply(answer);});
            });
        } else {
            ContentRequest requestedContent=ContentRequest.parse(cmd.text());
            if(userCommand && (new PhoneSearch.Query(cmd.text()).videos || requestedContent!=null && requestedContent.video()) && !askedVideoAccess){
                String perm=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_VIDEO:photoPermission();
                if(!granted(perm)){
                    askedVideoAccess=true;pendingVideoSearch=cmd;
                    requestPermissions(Build.VERSION.SDK_INT>=34?new String[]{perm,Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}:new String[]{perm},28);
                    return;
                }
            }
            boolean preferPhotos=cmd.kind()==SpokenCommand.Kind.FIND && (requestedContent!=null?requestedContent.photo()&&!requestedContent.video():new PhoneSearch.Query(cmd.text()).images);
            search(cmd.text(),cmd.kind()==SpokenCommand.Kind.OPEN,cmd.latest(),preferPhotos?SearchMode.PREFER_PHOTOS:SearchMode.UNIFIED,false);
        }
    }
    private void pauseLocation(int seconds){
        if(!ScreenTask.ready()){reply(ScreenTask.accessStatus(this));return;}
        authorizeScreen("com.android.settings","Отключить геолокацию и включить через "+seconds+" с.",()->{
            if(!ScreenTask.pauseLocation(seconds,turn))reply("Уже выполняю действие на экране. Дождитесь его завершения.");
        });
    }
    private record MediaContext(String query,SearchMode mode,long at){}
    private static MediaContext recentMedia;
    private static MediaContext currentMedia(){
        return recentMedia!=null && SystemClock.elapsedRealtime()-recentMedia.at()<120000?recentMedia:null;
    }
    private static boolean mediaPeriod(String s){
        if(Set.of("сегодня","вчера","позавчера","неделю").contains(s))return true;
        try{LocalDate.parse(s);return true;}catch(java.time.DateTimeException e){return false;}
    }
    private void changeMediaPeriod(MediaContext previous,String period,boolean google){
        String query=previous.query();
        if(ContentRequest.parse(query)==null)query=query.replaceFirst("(?iu)\\s+(?:за )?(?:сегодня|вчера|позавчера|неделю)$","");
        if(google && query.equals("сохраненные фото"))query="фото";
        within=null;contract=null;photosOnly=false;dateFilter=period.equals("all")?"":period;
        record("Уточнение","Новый период: "+period+" · "+query);
        search(query,false,false,google?SearchMode.GOOGLE_PHOTOS:previous.mode(),false);
    }
    private boolean practical(String raw){
        String q=ActionReceipt.norm(raw);
        int pause=LocationPause.seconds(q);
        if(pause>0){pauseLocation(pause);return true;}
        ScreenNavigation movement=ScreenNavigation.simple(raw);
        if(movement!=null){navigateScreen(movement);return true;}
        var saved=MediaClue.savedPhotos(q);
        if(saved!=null){
            within=null;dateFilter=saved;photosOnly=false;contract=null;
            record("Источник даты","Дата добавления фото в медиатеку Android");
            search("сохраненные фото",false,false);return true;
        }
        if(SettingsCommands.handle(this,q))return true;
        if(q.contains("верси") && (q.contains("тво")||q.contains("у тебя")||q.contains("марии"))){
            try{reply("На телефоне установлена Мария "+getPackageManager().getPackageInfo(getPackageName(),0).versionName+".");}
            catch(Exception e){reply("Не удалось прочитать версию в Android.");}return true;
        }
        if(q.matches(".*(?:продолжай|продолжи|дочитай|читай дальше|чтение дальше).*") &&
                (q.contains("чит")||reading.matches(screenItem))){readScreen(true,true);return true;}
        if(q.matches("(?:пожалуйста )?(?:(?:можешь|можно) (?:мне )?)?(?:прочти|прочитай|прочитать|зачитай|читай|озвучь)(?: .*|$)") &&
                q.matches(".*(?:пост|стать[юя]|текст|публикаци|экран|вслух|целиком).*") && !q.contains("договор") && !q.contains("документ")){
            readPublication();return true;
        }
        if((q.contains("банковским приложениям")||q.contains("по всем банкам")) && (q.contains("долг")||q.contains("обязательств"))){
            reply("У меня нет выписок из ваших банков. Для сводки нужны данные каждого банка. Можно открыть конкретную выписку и задать вопрос по ней.");return true;
        }
        boolean alarm=q.contains("будильник")||q.contains("разбуд");
        boolean status=q.matches(".*(?:ты (?:установил|поставил|запланировал)|ты .*установил|како[емй]+ приложени.*(?:установ|разбуд)|где.*(?:установ|постав)|в часах ли).*");
        if(ActionReceipt.clockQuestion(q)){ActionReceipt.checkAlarm(this,q);return true;}
        if(alarm && q.matches("(?:мне )?будильник (?:на|в) .+") && ActionReceipt.due(q)>0){ActionReceipt.alarm(this,raw,q);return true;}
        if(q.matches(".*\\b(?:перенеси|перенести|передвинь|сдвинь)\\b.*") && !q.matches(".*\\b(?:файл|фото|видео|папку)\\b.*") && cloudPrefs().getBoolean("understand_online",false)){
            understand(raw);return true;
        }
        if(calendarNotes.moveRequest(q))return true;
        if(alarm && (status || q.contains("како") && q.contains("приложени"))){reply(ActionReceipt.report(this,"alarm"));return true;}
        if(alarm && (q.matches(".*(?:поставь|установи|заведи|разбуди).*")) && ActionReceipt.due(q)>0){ActionReceipt.alarm(this,raw,q);return true;}
        boolean google=PhoneTasks.googleTasks(q);
        if(google && q.matches(".*(?:удал|сотр|очист).*")){
            reply("Могу открыть Google Задачи и показать список. Удаление задач голосом пока недоступно.");return true;
        }
        if(google && !q.contains("это время") && (q.contains("какие")||q.contains("список")||q.startsWith("а в ")||q.contains("посмотри")||q.contains("покажи"))){
            var p=ActionReceipt.prefs(this);
            boolean tomorrow=q.contains("завтра") || !q.contains("сегодня") && p.getBoolean("listTomorrow",false) && System.currentTimeMillis()-p.getLong("listAt",0)<600000;
            tasks("",LocalDate.now().plusDays(tomorrow?1:0).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(),true);return true;
        }
        if(google && status){
            var p=ActionReceipt.prefs(this);
            if(!p.getString("last","").equals("google") || System.currentTimeMillis()-p.getLong("google_at",0)>600000){
                reply("Последнее действие в Google Задачах не подтверждает эту просьбу. Могу проверить список задач.");return true;
            }
            reply(ActionReceipt.report(this,"google"));return true;
        }
        if(google && q.contains("это время")){
            var p=ActionReceipt.prefs(this);long when=p.getLong("remind_due",0);
            if(when>System.currentTimeMillis() && System.currentTimeMillis()-p.getLong("remind_at",0)<600000){
                tasks(p.getString("remind_note",""),when,false);return true;
            }
        }
        if(google && q.matches(".*(?:напомни|добавь|создай|поставь|запланируй).*")){understand(raw);return true;}
        if(!google && PhoneTasks.scheduleRequest(this,raw))return true;
        if((q.contains("задач")||q.contains("напоминания")) && (q.contains("завтра")||q.contains("сегодня"))){
            ActionReceipt.prefs(this).edit().putBoolean("listTomorrow",q.contains("завтра")).putLong("listAt",System.currentTimeMillis()).apply();
            if(q.matches(".*(?:какие|покажи|список|что у меня).*")){var day=LocalDate.now().plusDays(q.contains("завтра")?1:0);if(PhoneTasks.local(q))Reminder.list(this,day);else CalendarNotes.open(this,day);return true;}
        }
        return false;
    }
    private void tasks(String title,long when,boolean list){
        if(!list && (title.isBlank()||when<=System.currentTimeMillis())){askDetail("Создать задачу в Google Задачах","Как назвать задачу и на какое время её поставить?");return;}
        Intent launch=getPackageManager().getLaunchIntentForPackage(GoogleTasksFlow.PKG);
        if(launch==null){reply("На телефоне не найдено приложение Google Задачи.");return;}
        if(!ScreenTask.ready()){startActivity(launch);reply("Открыла Google Задачи. "+ScreenTask.accessStatus(this));return;}
        var task=new GoogleTasksFlow(title,when,list,turn);
        authorizeScreen(GoogleTasksFlow.PKG,list?"Прочитать задачи текущего списка на "+task.at.toLocalDate():
            "Создать или назначить время одноимённой задаче «"+title+"» · "+ActionReceipt.stamp(when),()->{
                if(!ScreenTask.tasks(task)){reply("Служба действий Android недоступна.");return;}
                try{startActivity(launch);record("Действие","Открыт список Google Задач для "+(list?"чтения":"проверки записи"));}
                catch(RuntimeException e){ScreenTask.cancel();reply("Не удалось открыть Google Задачи.");}
            });
    }
    private static String clarification="";
    private static long clarifiedAt;
    void askDetail(String request,String question){
        String context=request+"\nВопрос Марии: "+question;
        clarification=context.length()<=1500?context:context.substring(0,700)+" … "+context.substring(context.length()-700);
        clarifiedAt=SystemClock.elapsedRealtime();reply(question);
    }
    void understand(String request){understand(request,"");}
    private void understand(String request,String previous){
        long id=invalidateWork(),activeTurn=turn;
        int token=generation;
        boolean captured=screenItem!=null && SystemClock.elapsedRealtime()-screenItem.created<=300000;
        boolean document=contract!=null;int results=hits.size();
        var receipts=ActionReceipt.prefs(this);String lastType=receipts.getString("last","");
        String recent=System.currentTimeMillis()-receipts.getLong(lastType+"_at",0)<600000?lastType:"";
        String available="mediaSearch="+(currentMedia()!=null)+", previousActionType="+recent+", screen="+captured+", selectedFile="+(captured && screenItem.uri!=null)+", openedDocument="+document+", resultCount="+results;
        String key=cloudPrefs().getBoolean("understand_online",false)?cloudPrefs().getString(DeviceCredential.SETTING,""):"";
        String instruction=previous.isEmpty()?request:previous+"\nПользователь: "+request;
        String userWords=instruction.replaceAll("(?m)^Вопрос Марии:.*$","").toLowerCase(Locale.ROOT);
        record("Маршрут","Выбор инструмента по смыслу · "+available);
        busy=true;refreshVoice();feedback("Разбираюсь, чем помочь…");
        pending=worker.submit(()->{
            AssistantPlan online=null;
            if(!key.isEmpty())try{online=AssistantPlan.online(instruction,available,key,document,results);}
            catch(Exception failure){
                String reason=failure.getClass().getSimpleName();
                var http=java.util.regex.Pattern.compile("Код (\\d{3})").matcher(String.valueOf(failure.getMessage()));
                if(http.find())reason="HTTP "+http.group(1);
                journal.add(activeTurn,"Понимание","OpenAI недоступен · "+reason+" · резерв на телефоне");
            }
            if(Thread.currentThread().isInterrupted())return;
            AssistantPlan contextual=online==null?AssistantPlan.contextual(request,available):null;
            AssistantPlan plan=online!=null?online:contextual!=null?contextual:LocalAnswer.understand(getApplicationContext(),instruction,available,id);
            String provider=online!=null?"OpenAI":contextual!=null?"Контекст на телефоне":"На телефоне";
            String answer=plan.tool()==AssistantPlan.Tool.CHAT?(online!=null && !plan.argument().isBlank()?plan.argument():LocalAnswer.answer(getApplicationContext(),request,id)):"";
            runOnUiThread(()->{
                if(generation!=token || turn!=activeTurn || isFinishing() || !ScreenTask.unlocked(this))return;
                busy=false;refreshVoice();record("Понимание",provider);record("Инструмент",plan.tool().name());
                switch(plan.tool()){
                    case BATTERY,STORAGE,RAM -> {
                        var reading=new DeviceStatus.Request(plan.tool()==AssistantPlan.Tool.STORAGE,
                                plan.tool()==AssistantPlan.Tool.RAM,plan.tool()==AssistantPlan.Tool.BATTERY);
                        String value=DeviceStatus.read(this,reading);record("Источник","Данные Android · "+value);reply(value);
                    }
                    case SCREEN -> {
                        if(!captured || screenItem==null || SystemClock.elapsedRealtime()-screenItem.created>300000)
                            reply("Вызовите меня боковой кнопкой поверх нужного экрана и задайте вопрос.");
                        else if(cloudPrefs().contains(DeviceCredential.SETTING) && (screenItem.picture!=null || screenItem.uri!=null))
                            confirmScreenVision(screenItem,request);
                        else describeScreen(screenItem,false);
                    }
                    case DOCUMENT -> {
                        if(contract!=null)answerContract(request);
                        else reply("Откройте нужный документ в Марии и задайте вопрос по нему.");
                    }
                    case HISTORY -> journal.show(this);
                    case CLEANUP -> cleanup.open();
                    case REMINDERS -> {if(PhoneTasks.local(userWords))Reminder.list(this);else CalendarNotes.open(this,userWords.contains("завтра")?LocalDate.now().plusDays(1):null);}
                    case CHECK_ALARM -> ActionReceipt.checkAlarm(this,userWords);
                    case ALARM -> {
                        if(ActionReceipt.clockQuestion(userWords))ActionReceipt.checkAlarm(this,userWords);
                        else if(!userWords.matches("(?s).*(?:будильник|разбуд|будить|подъ[её]м).*") || !ActionReceipt.suppliedTime(userWords))
                            askDetail(instruction,"Что именно сделать на телефоне?");
                        else ActionReceipt.alarm(this,request,plan.argument());
                    }
                    case MOVE_REMINDER -> {if(plan.argument().isBlank() && calendarNotes.moveRequest(userWords))return;calendarNotes.movePlan(userWords,plan.argument());}
                    case SAVED_PHOTOS -> {
                        if(!mediaPeriod(plan.argument())){askDetail(instruction,"За какой день искать сохранённые снимки?");return;}
                        within=null;contract=null;photosOnly=false;dateFilter=plan.argument();
                        record("Источник даты","Дата добавления фото в медиатеку Android");search("сохраненные фото",false,false);
                    }
                    case MEDIA_PERIOD -> {
                        var context=currentMedia();
                        String[] parts=plan.argument().split("\\|",-1);
                        if(context==null || parts.length!=2 || !(parts[0].equals("all")||mediaPeriod(parts[0])) || !Set.of("current","google").contains(parts[1])){
                            askDetail(instruction,"Для какого поиска и за какой период показать результаты?");return;
                        }
                        changeMediaPeriod(context,parts[0],parts[1].equals("google"));
                    }
                    case LOCATION_PAUSE -> {
                        int seconds=plan.argument().matches("[1-9]\\d{0,3}")?Integer.parseInt(plan.argument()):0;
                        if(seconds<1 || seconds>3600 || !userWords.matches("(?s).*(?:gps|геолокац|локаци|местоположен|джи.?пи.?эс).*") || !userWords.matches("(?s).*\\b(?:секунд\\p{L}*|минут\\p{L}*|полминуты|мин\\.?|сек\\.?)\\b.*")){
                            askDetail(instruction,"На сколько секунд выключить геолокацию?");return;
                        }
                        pauseLocation(seconds);
                    }
                    case LAST_ACTION -> {
                        String type=plan.argument();
                        if(!Set.of("alarm","remind","google").contains(type))type=ActionReceipt.prefs(this).getString("last","");
                        if(type.equals("alarm"))ActionReceipt.checkAlarm(this,userWords);
                        else if(type.equals("google") && !ActionReceipt.prefs(this).getString("last","").equals("google"))reply("Не вижу подтверждения недавней записи в Google Задачах.");
                        else reply(ActionReceipt.report(this,type));
                    }
                    case NAVIGATE -> navigateScreen(ScreenNavigation.fromPlan(plan.argument(),userWords));
                    case READ_SCREEN -> {if(plan.argument().equals("continue"))readScreen(true,true);else readPublication();}
                    case GOOGLE_LIST -> {var day=LocalDate.now().plusDays(plan.argument().equals("tomorrow")?1:0);if(PhoneTasks.googleTasks(userWords))tasks("",day.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(),true);else CalendarNotes.open(this,day);}
                    case GOOGLE_ADD -> {
                        String[] parts=plan.argument().split(" ; ",2);
                        if(parts.length!=2)askDetail(instruction,"Назовите время и название задачи для Google.");
                        else if(PhoneTasks.googleTasks(userWords))tasks(parts[1].strip(),ActionReceipt.due(ActionReceipt.norm(parts[0])),false);
                        else PhoneTasks.reminder(this,parts[0].strip()+" "+parts[1].strip(),PhoneTasks.local(userWords));
                    }
                    case TIMER -> {
                        String seconds=plan.argument();
                        if(!seconds.matches("[1-9]\\d{0,4}") || Integer.parseInt(seconds)>86400)
                            askDetail(instruction,"На сколько времени поставить таймер?");
                        else PhoneTasks.timer(this,Integer.parseInt(seconds));
                    }
                    case REMIND -> {
                        if(PhoneTasks.googleTasks(userWords))askDetail(instruction,"Как назвать задачу в Google Задачах и когда напомнить?");
                        else if(userWords.contains("будильник"))ActionReceipt.alarm(this,request,plan.argument());
                        else if(!ActionReceipt.suppliedTime(userWords))askDetail(instruction,"На какое время поставить это напоминание?");
                        else PhoneTasks.reminder(this,plan.argument(),PhoneTasks.local(userWords));
                    }
                    case DRAFT -> {
                        String target=plan.argument();
                        int at=target.lastIndexOf(" в ");
                        if(at<1 || target.length()>80 || !userWords.contains(target.substring(0,at).toLowerCase(Locale.ROOT))
                                || Messenger.parse(target).app()==null || !screenCommand("отправь этот файл "+target))
                            askDetail(instruction,"Для кого подготовить файл и в каком мессенджере?");
                    }
                    case SCREEN_NUMBER -> screenCommand("скопируй этот номер");
                    case SCREEN_ROUTE -> screenCommand("проложи туда маршрут");
                    case PHOTO,VIDEO,FILE,FILE_TEXT -> {
                        if(plan.argument().isBlank()){askDetail(instruction,"Что помните о том, что нужно найти?");return;}
                        String prefix=switch(plan.tool()){case PHOTO -> "фото, где ";case VIDEO -> "видео, где ";case FILE_TEXT -> "файл со словами ";default -> "";};
                        within=null;photosOnly=false;dateFilter="";contract=null;
                        search(prefix+plan.argument(),false,false,plan.tool()==AssistantPlan.Tool.PHOTO?SearchMode.PREFER_PHOTOS:SearchMode.UNIFIED,false);
                    }
                    case APP,MAP -> {
                        String name=plan.argument().strip();
                        if(name.isEmpty() || !userWords.contains(name.toLowerCase(Locale.ROOT)) ||
                                !name.matches("[\\p{L}\\p{N} .’'№-]{1,100}")){
                            askDetail(instruction,plan.tool()==AssistantPlan.Tool.MAP?"До какого места проложить маршрут?":"Какое приложение открыть?");return;
                        }
                        if(plan.tool()==AssistantPlan.Tool.APP)PhoneTasks.openApp(this,name.toLowerCase(Locale.ROOT),null,null,null,true);
                        else try{startActivity(new Directions(name,List.of()).maps());record("Действие","Адрес передан Картам · "+name);feedback("Передала адрес в Карты.");}
                        catch(ActivityNotFoundException|SecurityException e){reply("Не удалось открыть Карты.");}
                    }
                    case RESULT -> {
                        int index=plan.argument().matches("[1-9][0-9]{0,2}")?Integer.parseInt(plan.argument())-1:-1;
                        if(index>=0 && index<hits.size())open(hits.get(index));
                        else askDetail(instruction,hits.isEmpty()?"Какие файлы сначала найти?":"Какой по счёту результат открыть?");
                    }
                    case CHAT -> reply(answer);
                    case CLARIFY -> askDetail(instruction,plan.argument().isBlank()?"Уточните, пожалуйста, что должно получиться на телефоне?":plan.argument());
                }
            });
        });
    }
    void reply(String message) { reply(message,CoralDelivery.CONVERSATION); }
    private void reply(String message,CoralDelivery delivery) { busy=false;refreshVoice();feedback(message);speech.say(message,null,delivery); }
    void promiseReply(String message){
        promiseMessage(message,false);
    }
    void promiseMessage(String message,boolean question){
        invalidateWork();hasSearch=false;contract=null;noteObject="";field.setText("");showItems(Collections.emptyList());busy=false;refreshVoice();feedback(message);
        speech.say(message,question&&spokenTurn?()->{if(promises.pending()&&hasWindowFocus()&&!isFinishing()&&!isDestroyed())voice();}:null);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(isFinishing())return;
        if(request==OWNER){
            if(!confirming)return;
            confirming=false;
            if(result==RESULT_OK && ScreenTask.unlocked(this)){
                if(page==null){
                    getSharedPreferences("settings",0).edit().remove("manualLock").apply();
                    Bundle restore=restoreAfterUnlock;restoreAfterUnlock=null;
                    initialize(restore);
                }
            }
            return;
        }
        if(page==null)return;
        if(request==PhoneCleanup.TRASH || request==PhoneCleanup.CACHE){cleanup.result(request,result);return;}
        if(request==PICK_SCREEN_FILE){
            var destination=pickForRecipient;pickForRecipient=null;
            if(result==RESULT_OK && data!=null && destination!=null && ScreenItem.safe(this,data.getData())){
                screenItem=new ScreenItem();screenItem.uri=data.getData();prepareMessage(screenItem.uri,destination);
            }
            return;
        }
        if(request==SHARED_DOCUMENT_ACCESS){
            if(hasSearch && !lastQuery.isEmpty())search(lastQuery,false,false);
            else Toast.makeText(this,PhoneSearch.allFiles()?"Доступ к общей памяти включён":"Доступ ограничен выбранными папками и системным каталогом",Toast.LENGTH_SHORT).show();
            return;
        }
        if(request==FileActions.SAVE){files.saved(result==RESULT_OK && data!=null?data.getData():null);return;}
        if (result!=RESULT_OK || data==null) return;
        if(request==CLOUD_PROFILE && data.getData()!=null){
            try{
                String json=CloudContract.read(getContentResolver().openInputStream(data.getData()),16384);
                var profile=CloudContract.Profile.load(json);
                new AlertDialog.Builder(this).setTitle("Подключить сервер Марии?")
                    .setMessage("Сервер "+profile.url().getAuthority()+" будет получать текст открытого договора и ваш вопрос для ответа через OpenAI.")
                    .setPositiveButton("Подключить",(d,w)->{
                        invalidateWork();busy=false;lastContractTurn="";cloudPrefs().edit().remove(DeviceCredential.SETTING).putString("profile",json).apply();refreshVoice();feedback("Профиль сохранён. Откройте PDF и выберите «Спросить у OpenAI».");
                    }).setNegativeButton("Отмена",null).show();
            }catch(Exception e){feedback("Не удалось прочитать файл подключения Марии.");}
            return;
        }
        if(request==ACCOUNT){
            String account=data.getStringExtra(android.accounts.AccountManager.KEY_ACCOUNT_NAME);
            if(account!=null)connectDrive(account);
            return;
        }
        if(request==PICK_PHOTO||request==PICK_FILE){importItems(data,request==PICK_PHOTO);return;}
        if ((request==TREE || request==RETRY_FOLDER) && data.getData()!=null) {
            try { getContentResolver().takePersistableUriPermission(data.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (SecurityException e) { feedback("Android не предоставил доступ к папке. Выберите её ещё раз."); return; }
            if(request==RETRY_FOLDER && !lastQuery.isEmpty())search(lastQuery,false,false);else search();
        }
    }
    private void search() { String query=field.getText().toString();turn=journal.begin("Поиск",query);search(query,false,false); }
    private void search(String query,boolean autoOpen,boolean latest){search(query,autoOpen,latest,SearchMode.UNIFIED,false);}
    private void search(String query,boolean autoOpen,boolean latest,SearchMode mode,boolean clarified) {
        search(query,autoOpen,latest,mode,clarified,true);
    }
    private void search(String query,boolean autoOpen,boolean latest,SearchMode mode,boolean clarified,boolean launchLibrary) {
        awaitingMediaClue=false;questionOnReturn=false;searchMode=mode;mediaCandidates=Collections.emptySet();
        final boolean driveOnly=mode==SearchMode.DRIVE,explicitPhotos=mode==SearchMode.GOOGLE_PHOTOS;
        final boolean voiceRequest=spokenTurn;
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(field.getWindowToken(),0);
        long nativeToken=invalidateWork();
        if(turn==0)turn=journal.begin("Поиск",query);
        final long searchTurn=turn;
        lastAppQuery="";lastQuery=query;hasSearch=true;
        int token=generation;
        hits=Collections.emptyList();
        ContentRequest content=ContentRequest.parse(query);
        var mediaType=new PhoneSearch.Query(query);
        recentMedia=(mediaType.images || mediaType.videos || content!=null&&(content.video()||content.photo()))?new MediaContext(query,mode,SystemClock.elapsedRealtime()):null;
        boolean videos=(content!=null && content.video()) || new PhoneSearch.Query(query).videos;
        boolean gallery=granted(videos && Build.VERSION.SDK_INT>=33 ? Manifest.permission.READ_MEDIA_VIDEO : photoPermission()) || partialGallery();
        record("Маршрут",(content==null?"Имя, папка и дата":content.video()?"Поиск видео по кадрам":content.photo()&&!content.lettering()?"Поиск фото по изображению":"Поиск по тексту")+" · "+query+(dateFilter.isEmpty()?"":" · "+dateFilter));
        photoLibraryQuery=photosOnly||driveOnly?null:GoogleSearch.forPhotoQuery(query,content,dateFilter);
        busy=true;refreshVoice();feedback(content==null ? "Ищу…" : content.video() ? "Готовлю поиск по кадрам видео…" : content.photo() ? "Готовлю поиск по изображению…" : content.includeTextFiles() ? "Ищу фразу в документах…" : "Читаю страницы PDF…");
        final boolean selectedOnly=photosOnly;
        final Set<String> scope=within==null?null:new HashSet<>(within);
        final String period=dateFilter;
        adapter.set(hits);
        boolean translateVideo=content!=null && content.video() && VideoTour.parse(content.terms())==null && !driveOnly;
        if(launchLibrary && explicitPhotos && !translateVideo)openPhotoLibrary();
        pending=worker.submit(()->{
            try (ContentIndex index=searchIndex(content,driveOnly,nativeToken,description->{
                journal.add(searchTurn,"Описание для сравнения кадров",description);
                if(translateVideo)runOnUiThread(()->{
                    if(generation!=token)return;
                    photoLibraryQuery=new GoogleSearch(GoogleSearch.Source.PHOTOS,("videos of "+description+" "+MediaClue.googlePeriod(period)).strip());
                    if(launchLibrary && explicitPhotos)openPhotoLibrary();
                });
            })) {
                String filter=content==null ? query : content.scan() ? "scan-text" : content.video() ? "видео" : content.photo() ? "фото" : content.includeTextFiles() ? "document-text" : "pdf";
                PhoneSearch.Progress progress=content==null && (explicitPhotos || selectedOnly || DriveFiles.account(this).isEmpty())?null:(examined,best)->runOnUiThread(()->{
                    if(generation!=token) return;
                    showItems(best);
                    if(content==null || driveOnly){if(!driveOnly)feedback("Ищу на телефоне и Диске…");return;}
                    feedback("Проверено: "+examined+(content.visual()?" · похожих в подборке: ":" · найдено пока: ")+best.size()+". Поиск продолжается…");
                });
                PhoneSearch engine=new PhoneSearch(getApplicationContext(),filter,index,progress,content);
                engine.trace=(detail)->journal.add(searchTurn,"Источник",detail);
                boolean media=engine.query.images || engine.query.videos;
                if(media && !autoOpen)engine.matchedMedia=new HashSet<>();
                engine.driveOnly=driveOnly;engine.googlePhotosRequested=explicitPhotos;engine.photosOnly=selectedOnly;engine.within=scope;engine.query.applyPeriod(period);
                PhoneSearch.Result r=engine.run(gallery);
                runOnUiThread(()->{ if (generation!=token) return;
                    busy=false;refreshVoice();
                    mediaCandidates=engine.matchedMedia==null?Collections.emptySet():engine.matchedMedia;
                    boolean narrowed=clarified && scope!=null && mediaCandidates.size()<scope.size();
                    awaitingMediaClue=media && !autoOpen && (!clarified || narrowed) && mediaCandidates.size()>=MediaClue.ASK_AT && turn==searchTurn;
                    if(awaitingMediaClue){
                        String kind=videos?"видео":"фото";
                        mediaQuestion=narrowed && !period.isEmpty()?lines.pick("С датой разобрались. Что было в кадре?","А теперь подскажите, что было в кадре?"):
                                lines.pick("Что вы помните про "+kind+" — когда это было или что видно в кадре?",
                                        "Давайте сузим поиск. Помните, когда это было? Или что попало в кадр?",
                                        "Зацепимся за одну деталь. Что вам запомнилось на "+(videos?"видео?":"фото?"));
                        journal.add(searchTurn,"Вопрос об уточнении",mediaQuestion);
                    }
                    show(r,videos,searchTurn);
                    journal.add(searchTurn,"Результат",(content!=null && content.visual()?"Кандидатов по описанию ":"Совпадений ")+r.count()+", показано "+r.hits().size()+", ошибок чтения "+r.skipped());
                    if(!r.hits().isEmpty()){
                        List<String> first=new ArrayList<>();
                        for(var h:r.hits().subList(0,Math.min(5,r.hits().size())))
                            first.add(h.name()+(h.reason().isEmpty()?"":" · "+h.reason()));
                        journal.add(searchTurn,"Первые результаты",String.join("\n",first));
                    }
                    if(showingPhotoLibrary){questionOnReturn=awaitingMediaClue;return;}
                    if(awaitingMediaClue){askMedia(voiceRequest);return;}
                    if(launchLibrary && (mode==SearchMode.PREFER_PHOTOS && !clarified) && photoLibraryQuery!=null && hasWindowFocus()){openPhotoLibrary();return;}
                    if (autoOpen && !hits.isEmpty() && (latest || r.count()==1)) open(hits.get(0));
                    else if (autoOpen && hits.size()>1) reply(status.getText()+". Скажите «открой первый» или выберите файл.");
                    else if(!r.hasSource() || r.skipped()>0 || !r.notice().isEmpty())speech.say(status.getText().toString());
                    else {
                        smallAvatar.react(r.count()>0);aura.react(r.count()>0);
                        speech.say(lines.results(r.count(),content!=null && content.visual()),null,r.count()>0?CoralDelivery.FOUND:CoralDelivery.CLARIFY);
                    } });
            } catch (InterruptedException cancelled) {journal.add(searchTurn,"Статус","Поиск прерван");Thread.currentThread().interrupt(); }
            catch (Exception | LinkageError error) {
                if(launchLibrary && explicitPhotos && translateVideo)runOnUiThread(()->{if(generation==token && !showingPhotoLibrary && hasWindowFocus())openPhotoLibrary();});
                journal.add(searchTurn,"Ошибка поиска",error.getClass().getSimpleName()+(error instanceof java.io.IOException && String.valueOf(error.getMessage()).startsWith("Нужна модель")?" · отсутствует модель перевода":""));
                android.util.Log.w("JarvisContent","Search initialization failed",error);
                runOnUiThread(()->{ if (generation==token) {busy=false;refreshVoice();feedback("Не удалось запустить поиск. Проверьте доступ к источникам и установку моделей.",searchTurn);} });
            }
        });
    }
    private ContentIndex searchIndex(ContentRequest content,boolean driveOnly,long token,java.util.function.Consumer<String> translated)throws Exception{
        if(content==null || driveOnly && !content.visual())return null;
        try{return new ContentIndex(getApplicationContext(),content,token,translated);}
        catch(InterruptedException cancelled){throw cancelled;}
        catch(Exception | LinkageError unavailable){if(!driveOnly)throw unavailable;return null;}
    }
    private void askMedia(boolean voiceRequest){
        if(!hasWindowFocus() || isFinishing() || confirming)return;
        speech.say(mediaQuestion,voiceRequest?()->{
            if(awaitingMediaClue && hasWindowFocus() && !isFinishing() && !confirming)voice();
        }:null,CoralDelivery.CLARIFY);
    }
    @Override public void onWindowFocusChanged(boolean focus){
        super.onWindowFocusChanged(focus);
        if(focus && questionOnReturn && !showingPhotoLibrary && awaitingMediaClue && !confirming && !isFinishing()){
            questionOnReturn=false;askMedia(spokenTurn);
        }
    }
    private void show(PhoneSearch.Result r,boolean videos,long searchTurn) {
        showItems(r.hits());
        String message=!r.hasSource() ? "Выберите папку для файлов или разрешите доступ к галерее для поиска фото."
                : r.count()==0 ? "Среди проверенных файлов совпадений нет." : "Найдено: "+r.count();
        if(videos){
            String period=lastQuery.contains("сегодня")?" за сегодня":lastQuery.contains("вчера")?" за вчера":"";
            message=r.count()==0?"В доступных источниках видео"+period+" не найдено.":"Найдено видео"+period+": "+r.count()+".";
            if(new PhoneSearch.Query(lastQuery).downloadedVideos){
                message=r.count()==0?"В загрузках и папках мессенджеров видео"+period+" не найдено."
                        :"В загрузках и папках мессенджеров"+period+" найдено видео: "+r.count()+".";
            }
            if(Build.VERSION.SDK_INT>=33 && !granted(Manifest.permission.READ_MEDIA_VIDEO))
                message+=" Нет доступа ко всей видеогалерее. В настройках Android откройте Мария → Разрешения → Фото и видео.";
        }
        if(videos && ContentRequest.parse(lastQuery)!=null && r.count()==0 && photoLibraryQuery!=null)message="Среди проверенных файлов подходящий кадр не найден. Попробуйте поиск в Google Фото.";
        ContentRequest request=ContentRequest.parse(lastQuery);
        if(request!=null && request.visual() && r.count()>0)
            message=(videos?"Видео с возможным совпадением: ":"Фото с возможным совпадением: ")+r.count()+". Сначала самые похожие.";
        PhoneSearch.Query kind=new PhoneSearch.Query(lastQuery);
        boolean documentSearch=kind.documents || kind.pdf || kind.contractSearch() || request!=null && (!request.photo() || request.scan());
        boolean missingDocument=r.count()==0 && documentSearch;
        if(missingDocument && searchMode!=SearchMode.DRIVE){
            ArrayList<String> paths=new ArrayList<>();
            for(UriPermission p:getContentResolver().getPersistedUriPermissions())if(p.isReadPermission() && DocumentsContract.isTreeUri(p.getUri()))
                paths.add(DocumentsContract.getTreeDocumentId(p.getUri()).replaceFirst("^primary:",""));
            message= "Среди проверенных документов совпадений нет. "+(PhoneSearch.allFiles()?"Проверена общая память телефона.":"Проверен доступный системный каталог Android.")+(paths.isEmpty()?"":" Выбранные папки: "+String.join(", ",paths)+".");
        }
        if(searchMode==SearchMode.DRIVE)message=r.count()==0?"На Google Диске совпадений не получено.":"Google Диск · найдено "+r.count()+".";
        if (r.count()>hits.size()) message+=" · показаны первые "+hits.size();
        if (r.skipped()>0) message+=" · ошибок доступа или чтения: "+r.skipped();
        if(!r.notice().isEmpty())message+="\n"+r.notice();
        boolean limited=searchMode!=SearchMode.DRIVE && documentSearch && Build.VERSION.SDK_INT>=30 && !PhoneSearch.allFiles();
        if(limited)message+="\nПоиск по всей общей памяти выключен.";
        if(awaitingMediaClue)message+="\n"+mediaQuestion;
        feedback(message,searchTurn);
        if(limited || missingDocument && searchMode!=SearchMode.DRIVE){
            String label=limited?"Включить поиск по общей памяти":"Добавить папку и повторить поиск";
            folderRecovery.setText(label);folderRecovery.setContentDescription(label);folderRecovery.setVisibility(View.VISIBLE);
        }
    }
    private void showItems(List<PhoneSearch.Hit> items) {
        hits=items;
        if(!items.isEmpty() && this instanceof AssistPanel panel)panel.size(true);
        boolean gallery=hasSearch || items.stream().anyMatch(h->h.page()<0 && (DriveFiles.remote(h.original())
                || SelectedItems.DRIVE.equals(h.path()) || SelectedItems.PHOTOS.equals(h.path())
                || h.mime().startsWith("image/") || h.mime().startsWith("video/")));
        list.setNumColumns(gallery?GridView.AUTO_FIT:1);
        adapter.set(items,gallery);
        refreshVoice();
    }
    void open(PhoneSearch.Hit h) {
        awaitingMediaClue=false;questionOnReturn=false;
        if(h.page()>=0 && FilePreview.supported(h.mime())){preview(h);return;}
        if(DriveFiles.remote(h.original()))files.openDrive(h);
        else files.external(h,Intent.ACTION_VIEW,false);
    }
    void preview(PhoneSearch.Hit h) {
        if(DriveFiles.remote(h.uri())){
            invalidateWork();int token=generation;busy=true;refreshVoice();feedback("Загружаю файл с Google Диска…");
            pending=worker.submit(()->{
                try{
                    PhoneSearch.Hit preview=DriveFiles.download(this,h);
                    runOnUiThread(()->{if(generation==token){busy=false;refreshVoice();feedback(h.name());preview(preview);}
                        else new java.io.File(preview.uri().getPath()).delete();});
                }catch(Exception e){runOnUiThread(()->{if(generation==token)reply("Не удалось открыть файл с Google Диска. Проверьте формат, сеть и доступ.");});}
            });return;
        }
        if(!h.reason().startsWith("Цитата"))contract=null;
        if (FilePreview.supported(h.mime())) {
            try { FilePreview.show(this,h); speech.say("Открываю файл."); }
            catch (Exception e) { reply("Не удалось прочитать этот файл."); }
            return;
        }
        files.external(h,Intent.ACTION_VIEW,false);
    }
    @Override public Object onRetainNonConfigurationInstance(){return screenItem;}
    @Override public void onSaveInstanceState(Bundle state) {
        calendarNotes.saveState(state);
        if(page==null){super.onSaveInstanceState(state);return;}
        state.putBoolean("todayOpen",today!=null&&today.isShowing());

        state.putBoolean("googlePhotosRequested",searchMode==SearchMode.GOOGLE_PHOTOS);state.putBoolean("driveOnly",searchMode==SearchMode.DRIVE);state.putBoolean("photosOnly",photosOnly);state.putString("last",lastQuery);state.putString("period",dateFilter);state.putString("note",noteObject);state.putString("object",book.current);
        files.saveState(state);
        if(contract!=null){state.putString("contract",contract.uri().toString());state.putString("original",contract.original().toString());state.putString("docName",contract.name());state.putString("stamp",contract.stamp());}
        if(contract!=null && cloudReady()){
            state.putString("contractTurn",lastContractTurn);
            ArrayList<String> labels=new ArrayList<>();List<Integer> numbers=new ArrayList<>();
            for(var h:hits)if(h.reason().startsWith("Цитата")){labels.add(h.reason());numbers.add(h.page());}
            state.putStringArrayList("contractQuotes",labels);state.putIntArray("contractPages",numbers.stream().mapToInt(Integer::intValue).toArray());
        }
        state.putBoolean("results",inResults);
        state.putString("query",field.getText().toString());
        state.putBoolean("searched",hasSearch);
        state.putString("message",status.getText().toString());
        super.onSaveInstanceState(state);
    }
    @Override protected void onStop() {

        if(page==null){super.onStop();return;}
        cleanup.stop();
        if(today!=null)today.pauseSpeech();
        if(showingPhotoLibrary){
            speech.stop();super.onStop();return;
        }
        generation++;
        if(pending!=null) pending.cancel(true);
        if(activeNativeToken!=0 && activeNativeToken==sequence.get()) LocalAnswer.cancel(sequence.incrementAndGet());
        if(busy && inResults) feedback("Задача приостановлена. Нажмите стрелку, чтобы повторить.");
        busy=false;speaking=false;speech.stop();refreshVoice();
        super.onStop();
    }
    @Override public void onDestroy() {
        if(screenOffRegistered)unregisterReceiver(screenOff);
        if(page==null){worker.shutdownNow();super.onDestroy();return;}
        generation++;
        if(today!=null)today.close();
        adapter.close();
        cleanup.close();files.close();
        speech.close();
        worker.shutdownNow();
        super.onDestroy();
    }
}
