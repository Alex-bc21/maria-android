package local.jarvis.search;

import org.junit.Test;
import static org.junit.Assert.*;

/** Regression checks for the completed 6.40 command changes. */
public class Intent640Test {
    @Test public void reminderCorrectionRequiresRecentReminderAndExplicitTime() {
        String context="previousActionType=remind";
        assertEquals(new AssistantPlan(AssistantPlan.Tool.MOVE_REMINDER,"@last||13:00"),
                AssistantPlan.contextual("Давай лучше это в час дня",context));
        assertNull(AssistantPlan.contextual("Не передвигай его на час дня",context));
        assertNull(AssistantPlan.contextual("Давай лучше это в час дня","previousActionType=alarm"));
        assertFalse(ActionReceipt.suppliedTime("напомни завтра про встречу"));
        assertEquals(AssistantPlan.Tool.MOVE_REMINDER,AssistantPlan.parse("MOVE_REMINDER|@last||13:00").tool());
    }
    @Test public void alarmAndSavedPhotoQuestionsKeepTheirIntent() {
        assertEquals(AssistantPlan.Tool.CHECK_ALARM,AssistantPlan.contextual("Когда меня разбудит телефон?","").tool());
        assertEquals("сегодня",MediaClue.savedPhotos("покажи мне фото которое я сегодня сохранил на телефон"));
        assertNull(MediaClue.savedPhotos("покажи фото с белой лошадью"));
        assertTrue(new PhoneSearch.Query("сохраненные фото").savedPhotos);
        assertEquals(new AssistantPlan(AssistantPlan.Tool.MEDIA_PERIOD,"all|google"),
                AssistantPlan.contextual("Дату убери, в Google Фото за всё время","mediaSearch=true"));
        assertNull(AssistantPlan.contextual("Дату убери, в Google Фото за всё время","mediaSearch=false"));
        assertEquals(30,LocationPause.seconds("отключить GPS на 30 секунд и потом включи снова"));
    }
}
