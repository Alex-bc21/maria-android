plugins { id("com.android.application") version "9.3.1" }
android {
    namespace = "local.jarvis.search"
    compileSdk = 37
    testBuildType = "release"
    defaultConfig { testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"; applicationId = "local.jarvis.search"; minSdk = 29; targetSdk = 35; versionCode = 56; versionName = "6.39" }
    packaging { jniLibs { useLegacyPackaging = true } }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    flavorDimensions += "engine"
    productFlavors {
        create("portable") { dimension = "engine"; buildConfigField("boolean", "LOCAL_MODELS", "false") }
        create("full") { dimension = "engine"; buildConfigField("boolean", "LOCAL_MODELS", "true"); ndk { abiFilters += "arm64-v8a" } }
    }
    sourceSets {
        getByName("main") { assets.setSrcDirs(listOf("src/shared/assets")); jniLibs.setSrcDirs(emptyList<String>()) }
        getByName("full") { assets.setSrcDirs(listOf("src/main/assets")); jniLibs.setSrcDirs(listOf("src/main/jniLibs")) }
    }
    signingConfigs.getByName("debug") { storeFile = file(providers.gradleProperty("mariaKeystore").getOrElse(System.getProperty("user.home") + "/.android/debug.keystore")) }
    buildTypes { getByName("release") { signingConfig = signingConfigs.getByName("debug"); isMinifyEnabled = false } }
}
dependencies {
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("junit:junit:4.13.2")
    implementation(fileTree("libs") { include("*.jar"); exclude("kotlin-stdlib.jar") })
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
}




