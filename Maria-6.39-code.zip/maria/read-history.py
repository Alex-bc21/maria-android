"""Read Jarvis diagnostics from an authorized Android debugging connection."""
import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", help="ADB serial (required when several phones are connected)")
    parser.add_argument("--follow", action="store_true", help="also print new events until Ctrl+C")
    args = parser.parse_args()
    sdk = os.environ.get("ANDROID_HOME") or str(Path(os.environ.get("LOCALAPPDATA", "")) / "Android" / "Sdk")
    adb = shutil.which("adb") or str(Path(sdk) / "platform-tools" / ("adb.exe" if os.name == "nt" else "adb"))
    def run(*command):
        return subprocess.check_output([adb, *command], stderr=subprocess.STDOUT, encoding="utf-8", errors="replace", timeout=20)
    serial = args.device or os.environ.get("ANDROID_SERIAL")
    if not serial:
        devices = [line.split()[0] for line in run("devices").splitlines() if line.rstrip().endswith("\tdevice") and not line.startswith("emulator-")]
        if len(devices) != 1:
            parser.error("Подключите телефон и укажите --device СЕРИЙНЫЙ_НОМЕР.")
        serial = devices[0]
    after = 0
    while True:
        result = run("-s", serial, "shell", "content", "query", "--user", "0", "--uri",
                     f"content://local.jarvis.search.history/events?after={after}")
        if result.strip() != "No result found.":
            rows = re.findall(r"^Row: \d+ id=(\d+), turn=", result, re.MULTILINE)
            if not rows:
                raise RuntimeError(result.strip() or "Журнал недоступен")
            after = int(rows[-1])
            print(result.rstrip(), flush=True)
        elif not args.follow:
            print("В журнале пока нет запросов.")
        if not args.follow:
            return
        time.sleep(3)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except (OSError, RuntimeError, subprocess.SubprocessError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)