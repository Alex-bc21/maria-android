param(
    [string]$Sdk = $env:ANDROID_HOME,
    [string]$Jdk = $env:JAVA_HOME,
    [string]$Keystore = (Join-Path $env:USERPROFILE '.android/debug.keystore'),
    [string]$Destination = (Join-Path $PSScriptRoot 'build'),
    [ValidateSet('Portable','Full','Both')][string]$Variant = 'Portable'
)
$ErrorActionPreference = 'Stop'
if (!$Sdk -or !$Jdk) { throw 'Set ANDROID_HOME and JAVA_HOME or supply -Sdk and -Jdk.' }
if (!(Test-Path -LiteralPath $Keystore)) { throw 'Signing keystore is missing. Preserve the original key for updates.' }
$env:ANDROID_HOME=$Sdk
$env:JAVA_HOME=$Jdk
$variants=if($Variant -eq 'Both'){@('Portable','Full')}else{@($Variant)}
Push-Location $PSScriptRoot
try {
    $tasks=@($variants | ForEach-Object { "assemble${_}Release" })
    & ./gradlew.bat @tasks "-PmariaKeystore=$Keystore" --console=plain
    if($LASTEXITCODE -ne 0){throw "Gradle failed ($LASTEXITCODE)"}
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null
    foreach($flavor in $variants){
        $lower=$flavor.ToLowerInvariant()
        $apks=@(Get-ChildItem "build/outputs/apk/$lower/release" -Filter '*.apk')
        if($apks.Count -ne 1){throw 'Expected one APK per variant'}
        $target=Join-Path $Destination "Maria-$lower.apk"
        Copy-Item -LiteralPath $apks[0].FullName -Destination $target -Force
        if($flavor -eq $variants[0]){
            Copy-Item -LiteralPath $apks[0].FullName -Destination (Join-Path $Destination 'Jarvis-Search.apk') -Force
        }
        Write-Output $target
    }
} finally { Pop-Location }
