package local.jarvis.search;

import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import static org.junit.Assert.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** Runs on disposable AOSP emulators, including API 29 without Google services. */
public class CompatibilityTest {
    @Test public void portableCommandsWithoutNativeLibraries() throws Exception {
        var instrumentation=InstrumentationRegistry.getInstrumentation();
        var context=instrumentation.getTargetContext();
        assertFalse(DeviceSupport.nativeModels());
        LocalAnswer.cancel(100);
        assertNotNull(LocalAnswer.answer(context,"Привет",101));
        assertEquals(AssistantPlan.Tool.CLARIFY,LocalAnswer.understand(context,"привет","",102).tool());
        assertEquals("test", "  test  ".strip());
        assertTrue(" ".isBlank());
        assertEquals(2,java.util.List.of("a","b").size());
        try {DeviceSupport.requireModels(context);fail("Models must be explicitly unavailable");}
        catch(java.io.IOException expected){assertTrue(expected.getMessage().contains("ARM64"));}
        ChargeIndex.schedule(context);
        assertNull(context.getSystemService(android.app.job.JobScheduler.class).getPendingJob(ChargeIndex.ID));
        var activity=(SearchActivity)instrumentation.startActivitySync(new Intent(context,SearchActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        instrumentation.waitForIdleSync();
        Field field=SearchActivity.class.getDeclaredField("field");field.setAccessible(true);
        EditText input=(EditText)field.get(activity);
        assertNotNull("Test emulator must have a screen lock and be unlocked",input);
        assertTrue(input.getWidth()>0);
        Field title=SearchActivity.class.getDeclaredField("heroTitle");title.setAccessible(true);
        android.widget.TextView heading=(android.widget.TextView)title.get(activity);
        assertNotNull(heading.getLayout());
        assertTrue("Heading must fit at large font sizes",heading.getHeight()>=heading.getLayout().getHeight());
        int[] position=new int[2];heading.getLocationOnScreen(position);
        assertTrue("Heading must stay inside the display",position[0]+heading.getWidth()<=activity.getResources().getDisplayMetrics().widthPixels);
        System.out.println("Compatibility: API "+android.os.Build.VERSION.SDK_INT+", width="+activity.getResources().getConfiguration().screenWidthDp+"dp, fontScale="+activity.getResources().getConfiguration().fontScale);
        Method invalidate=SearchActivity.class.getDeclaredMethod("invalidateWork");invalidate.setAccessible(true);
        instrumentation.runOnMainSync(()->{try {invalidate.invoke(activity);}catch(Exception error){throw new AssertionError(error);}});
        assertTrue(activity.getWindow().getDecorView().getWidth()>0);
        instrumentation.runOnMainSync(activity::finish);
        instrumentation.waitForIdleSync();
    }

    @Test public void missingRecognizerKeepsTypedCommands() {
        var instrumentation=InstrumentationRegistry.getInstrumentation();
        var context=instrumentation.getTargetContext();
        if(android.speech.SpeechRecognizer.isRecognitionAvailable(context))return;
        String[] status={""};
        instrumentation.runOnMainSync(()->{
            Voice voice=new Voice(context,new Voice.Events(){
                public void speakingText(String s){} public void status(String s){status[0]=s;}
                public void recognized(String s){} public void mic(AuraView.Mode m){}
                public void level(float f){} public void playing(boolean b){} public void mouth(float a,float b){}
            });
            voice.listen();voice.close();
        });
        assertTrue(status[0].contains("ввести команду"));
    }
}
