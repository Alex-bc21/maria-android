package local.jarvis.search;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.spec.MGF1ParameterSpec;
import java.util.Arrays;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;

/** Only the public key and a device-bound ciphertext cross the USB connection. */
final class DeviceCredential {
    private static final String ALIAS="jarvis_openai_rsa_v1";
    static final String SETTING="device_key";

    private static KeyStore store() throws Exception {
        KeyStore keys=KeyStore.getInstance("AndroidKeyStore");
        keys.load(null);
        return keys;
    }
    private static File transferFile(Context context,String name) throws Exception {
        File dir=context.getExternalFilesDir(null);
        if(dir==null)throw new java.io.IOException("Storage unavailable");
        return new File(dir,name);
    }
    static String prepare(Context context) throws Exception {
        KeyStore keys=store();
        if(!keys.containsAlias(ALIAS)){
            KeyPairGenerator generator=KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA,"AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_DECRYPT)
                    .setKeySize(3072).setDigests(KeyProperties.DIGEST_SHA256,KeyProperties.DIGEST_SHA1)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
                    .setUnlockedDeviceRequired(true).build());
            generator.generateKeyPair();
        }
        byte[] pub=keys.getCertificate(ALIAS).getPublicKey().getEncoded();
        Files.write(transferFile(context,"jarvis-public.der").toPath(),pub);
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(pub);
        StringBuilder fingerprint=new StringBuilder();
        for(int i=0;i<12;i++)fingerprint.append(String.format(Locale.ROOT,"%02X",digest[i]));
        return fingerprint.toString();
    }
    static String open(byte[] envelope) throws Exception {
        Cipher cipher=Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        cipher.init(Cipher.DECRYPT_MODE,store().getKey(ALIAS,null),
                new OAEPParameterSpec("SHA-256","MGF1",MGF1ParameterSpec.SHA1,PSource.PSpecified.DEFAULT));
        byte[] clear=cipher.doFinal(envelope);
        try{
            String key=new String(clear,StandardCharsets.US_ASCII);
            if(!key.matches("sk-[A-Za-z0-9_-]{16,300}"))throw new java.security.InvalidKeyException();
            return key;
        }finally{Arrays.fill(clear,(byte)0);}
    }
    static void accept(Context context,SharedPreferences settings) throws Exception {
        File file=transferFile(context,"jarvis-key.bin");
        if(file.length()!=384)throw new java.io.IOException("Invalid envelope");
        byte[] envelope=Files.readAllBytes(file.toPath());
        open(envelope);
        if(!settings.edit().remove("profile").putString(SETTING,Base64.encodeToString(envelope,Base64.NO_WRAP)).commit())
            throw new java.io.IOException("Could not save");
        file.delete();
    }
}
