package local.jarvis.search;

import android.app.AlertDialog;
import android.content.*;
import android.text.*;
import android.widget.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

/** Confirmed showing notes and their editable, durable draft. */
final class ShowingNotes {
    record Entry(String id,String person,String object,String text,String promise,long created,boolean reminded) {}
    private final SearchActivity a;
    ShowingNotes(SearchActivity a){this.a=a;}
    private static SharedPreferences records(Context c){return c.getSharedPreferences("showing_notes",0);}
    private SharedPreferences draft(){return a.getSharedPreferences("showing_note_draft",0);}
    boolean pending(){return draft().contains("id");}
    static List<Entry> all(Context c){
        List<Entry> entries=new ArrayList<>();
        for(var value:records(c).getAll().values())try{
            JSONObject j=new JSONObject((String)value);
            entries.add(new Entry(j.getString("id"),j.getString("person"),j.getString("object"),j.getString("text"),
                j.optString("promise"),j.getLong("created"),j.optBoolean("reminded")));
        }catch(JSONException|ClassCastException ignored){}
        entries.sort(Comparator.comparingLong(Entry::created).reversed());return entries;
    }
    static List<Entry> forObject(Context c,String object){
        List<Entry> result=all(c);result.removeIf(e->!e.object().equals(object));return result;
    }
    static void reminderSaved(Context c,String id){
        if(id.isEmpty())return;
        try{
            JSONObject j=new JSONObject(records(c).getString(id,"{}"));j.put("reminded",true);
            records(c).edit().putString(id,j.toString()).commit();
        }catch(JSONException ignored){}
    }
    private List<String> people(){
        return all(a).stream().map(Entry::person).distinct().sorted().toList();
    }
    private static String nameKey(String value){
        // Used only to offer a selection for inflected names, never to merge records.
        return Showing.clean(value).replaceAll("(?<=\\p{L}{3})[аеуыи]\\b","");
    }
    boolean handle(String raw){
        String text=raw.strip(),command=Showing.clean(text);
        Matcher start=Pattern.compile("(?isu)^(?:я )?показал[аи]?\\s+(.+?)\\s+(?:квартиру|дом|объект|помещение)\\s+(?:на |по адресу )?([^.!?\\n]+)(?:[.!?]|$)(.*)").matcher(text);
        if(command.matches("(?:запиши )?итог(?:и)? показа.*")||start.matches()){
            if(pending()){
                a.reply("Есть несохранённый итог показа. Сначала сохраните или отмените его.");edit();return true;
            }
            String person="",object=Showing.active(a),note=text;
            if(start.matches()){person=start.group(1).strip();object=start.group(2).strip();}
            else note=text.replaceFirst("(?iu)^(?:запиши )?итоги? показа[:,. ]*","");
            for(String known:a.getSharedPreferences("objects",0).getAll().keySet())
                if(Showing.clean(known).equals(Showing.clean(object))){object=known;break;}
            String promise="";
            Matcher commitment=Pattern.compile("(?isu)(?:(сегодня|завтра|послезавтра)\\s+)?(?:я\\s+)?обещал[аи]?\\s+(.+)$").matcher(note);
            if(commitment.find())promise=(commitment.group(1)==null?"":commitment.group(1)+" ")+commitment.group(2).strip();
            draft().edit().clear().putString("id",UUID.randomUUID().toString()).putLong("created",System.currentTimeMillis())
                .putString("person",person).putString("object",object).putString("text",note).putString("promise",promise).commit();
            a.prepareShowing();edit();return true;
        }
        if(command.matches("(?:покажи |открой )?итоги показов")){browse();return true;}
        if(command.matches("(?:покажи |открой )?мои клиенты")){choosePerson("");return true;}
        Matcher person=Pattern.compile("(?iu)^(?:(?:напомни[, ]+)?что важно для|(?:открой|покажи) клиента|история клиента)\\s+(.+)$").matcher(text.replaceAll("[.!?]+$",""));
        if(person.matches()){choosePerson(person.group(1));return true;}
        return false;
    }
    private EditText input(LinearLayout panel,String title,String key,boolean multiline){
        TextView label=new TextView(a);label.setText(title);label.setTextColor(Studio.MUTED);panel.addView(label);
        EditText value=new EditText(a);value.setText(draft().getString(key,""));value.setSingleLine(!multiline);
        value.setContentDescription(title);value.setTextColor(Studio.TEXT);panel.addView(value);
        value.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){draft().edit().putString(key,s.toString()).commit();}
            public void afterTextChanged(Editable s){}
        });return value;
    }
    void edit(){
        if(!pending())return;
        String editingId=draft().getString("id","");
        Studio style=new Studio(a);
        ScrollView scroll=new ScrollView(a);LinearLayout panel=new LinearLayout(a);panel.setOrientation(LinearLayout.VERTICAL);
        int pad=(int)(20*a.getResources().getDisplayMetrics().density);panel.setPadding(pad,0,pad,0);scroll.addView(panel);
        EditText person=input(panel,"Клиент","person",false);
        Button pickPerson=new Button(a);pickPerson.setText("Выбрать клиента");panel.addView(pickPerson);
        pickPerson.setAllCaps(false);pickPerson.setTextColor(Studio.LILAC);pickPerson.setBackground(style.surface(Studio.PANEL,12,Studio.EDGE));
        pickPerson.setOnClickListener(v->new AlertDialog.Builder(a).setTitle("Клиенты")
            .setItems(people().toArray(new String[0]),(d,i)->person.setText(people().get(i))).setNegativeButton("Назад",null).show());
        EditText object=input(panel,"Объект или адрес","object",false);
        Button pickObject=new Button(a);pickObject.setText("Выбрать объект");panel.addView(pickObject);
        pickObject.setAllCaps(false);pickObject.setTextColor(Studio.LILAC);pickObject.setBackground(style.surface(Studio.PANEL,12,Studio.EDGE));
        pickObject.setOnClickListener(v->a.book.choose(object::setText));
        EditText note=input(panel,"Итог показа","text",true);
        EditText promise=input(panel,"Что обещали сделать и когда","promise",true);
        TextView hint=new TextView(a);hint.setText("Проверьте поля. Для обещания после сохранения уточним время напоминания.");panel.addView(hint);
        AlertDialog dialog=new AlertDialog.Builder(a).setTitle("Итог показа").setView(scroll).setPositiveButton("Сохранить",null)
            .setNegativeButton("Отменить",(d,w)->draft().edit().clear().commit()).setNeutralButton("Позже",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(!editingId.equals(draft().getString("id","")))return;
            if(person.getText().toString().isBlank()){person.setError("Укажите клиента");return;}
            if(object.getText().toString().isBlank()){object.setError("Укажите объект");return;}
            if(note.getText().toString().isBlank()){note.setError("Добавьте итог показа");return;}
            Entry entry=new Entry(draft().getString("id",""),person.getText().toString().strip(),object.getText().toString().strip(),
                note.getText().toString().strip(),promise.getText().toString().strip(),draft().getLong("created",0),false);
            try{
                JSONObject j=new JSONObject().put("id",entry.id()).put("person",entry.person()).put("object",entry.object())
                    .put("text",entry.text()).put("promise",entry.promise()).put("created",entry.created()).put("reminded",false);
                if(!records(a).edit().putString(entry.id(),j.toString()).commit()){hint.setText("Не удалось сохранить. Повторите.");return;}
            }catch(JSONException e){throw new IllegalStateException(e);}
            draft().edit().clear().commit();a.book.ensure(entry.object());dialog.dismiss();
            a.reply("Итог показа сохранён. "+entry.person()+" · "+entry.object()+".");
            if(!entry.promise().isEmpty())a.startShowingPromise(entry);else show(entry);
        }));dialog.show();dialog.getWindow().setBackgroundDrawable(style.shape(Studio.PANEL,24,Studio.EDGE));
    }
    void browse(){
        if(pending()){edit();return;}
        List<Entry> entries=all(a);
        if(entries.isEmpty()){a.reply("Итогов показов пока нет. Скажите «Итог показа» или «Показал Анне квартиру на Лесной 12…».");return;}
        new AlertDialog.Builder(a).setTitle("Итоги показов").setItems(entries.stream().map(e->e.person()+" · "+e.object()+" · "+Promises.when(e.created())).toArray(String[]::new),
            (d,i)->show(entries.get(i))).setNegativeButton("Закрыть",null).show();
    }
    void show(Entry entry){
        AlertDialog.Builder dialog=new AlertDialog.Builder(a).setTitle(entry.person()+" · "+entry.object())
            .setMessage(Promises.when(entry.created())+"\n\n"+entry.text()+(entry.promise().isEmpty()?"":"\n\nОбещание · "+entry.promise()))
            .setPositiveButton("Клиент",(d,w)->showPerson(entry.person())).setNegativeButton("Закрыть",null);
        if(!entry.promise().isEmpty()&&!entry.reminded())dialog.setNeutralButton("Напомнить",(d,w)->a.startShowingPromise(entry));
        else dialog.setNeutralButton("Объект",(d,w)->a.book.show(entry.object()));
        dialog.show();
    }
    void choosePerson(String query){
        List<String> names=people(),exact=names.stream().filter(n->Showing.clean(n).equals(Showing.clean(query))).toList();
        if(exact.size()==1){showPerson(exact.get(0));return;}
        List<String> matches=names.stream().filter(n->nameKey(n).equals(nameKey(query))).toList();
        List<String> options=matches.isEmpty()?names:matches;
        if(options.isEmpty()){a.reply("Клиентов пока нет. Сохраните итог показа с именем клиента.");return;}
        new AlertDialog.Builder(a).setTitle(query.isEmpty()?"Мои клиенты":"Выберите клиента")
            .setItems(options.toArray(new String[0]),(d,i)->showPerson(options.get(i))).setNegativeButton("Закрыть",null).show();
    }
    private void showPerson(String person){
        List<Entry> visits=all(a).stream().filter(e->e.person().equals(person)).toList();
        List<String> lines=new ArrayList<>();
        for(Entry entry:visits)lines.add(entry.object()+" · "+Promises.when(entry.created())+"\n"+entry.text());
        String message=String.join("\n\n",lines)+"\n\n"+Promises.review(a,person);
        new AlertDialog.Builder(a).setTitle(person).setMessage(message)
            .setPositiveButton("Озвучить",(d,w)->a.reply(message))
            .setNeutralButton("Объекты",(d,w)->{
                List<String> objects=visits.stream().map(Entry::object).distinct().toList();
                new AlertDialog.Builder(a).setTitle("Объекты · "+person).setItems(objects.toArray(new String[0]),
                    (x,i)->a.book.show(objects.get(i))).setNegativeButton("Закрыть",null).show();
            }).setNegativeButton("Закрыть",null).show();
    }
}
