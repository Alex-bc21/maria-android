package local.jarvis.search;

import java.util.*;
import java.util.regex.*;

record ResultAction(boolean share,int position,String type,boolean drive) {
    private static final Pattern REQUEST=Pattern.compile("^(поделись|поделиться|открой|открыть|покажи) (?:мне )?(\\d+|перв[а-яё]+|втор[а-яё]+|трет[а-яёь]+|четв[её]рт[а-яё]+|пят[а-яё]+)(?: (фото(?:графи[а-яё]+)?|сним[а-яё]+|договор[а-яё]*|документ[а-яё]*|файл[а-яё]*|результат[а-яё]*|pdf|пдф))?(?: (?:на|с|из|в) ((?:гугл |google )?диск[ае]?))?$");
    static ResultAction parse(String text){
        Matcher m=REQUEST.matcher(text);if(!m.matches())return null;
        String n=m.group(2);int pos;
        if(Character.isDigit(n.charAt(0)))pos=n.length()>3?999:Integer.parseInt(n);
        else pos=n.startsWith("перв")?1:n.startsWith("втор")?2:n.startsWith("трет")?3:n.startsWith("четв")?4:5;
        return new ResultAction(m.group(1).startsWith("подел"),pos,Objects.toString(m.group(3),""),m.group(4)!=null);
    }
    PhoneSearch.Hit select(List<PhoneSearch.Hit> rows,String query){
        int index=0;
        for(var h:rows){
            if(drive&&!DriveFiles.remote(h.original()))continue;
            if((type.startsWith("фото")||type.startsWith("сним"))&&!h.mime().startsWith("image/"))continue;
            if((type.equals("пдф")||type.equals("pdf"))&&!h.mime().equals("application/pdf"))continue;
            if(type.startsWith("документ")||type.startsWith("договор")){
                if(!(h.mime().startsWith("application/")||h.mime().startsWith("text/")))continue;
                String name=h.name().toLowerCase(Locale.ROOT);
                if(type.startsWith("договор")&&!name.matches(".*(?:договор|договір|dogovor).*")&&!query.toLowerCase(Locale.ROOT).matches(".*(?:договор|договір).*"))continue;
            }
            if(++index==position)return h;
        }
        return null;
    }
}
