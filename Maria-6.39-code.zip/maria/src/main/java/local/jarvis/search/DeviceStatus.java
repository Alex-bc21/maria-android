package local.jarvis.search;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.StatFs;
import java.util.Locale;
import java.util.regex.Pattern;

final class DeviceStatus {
    record Request(boolean disk,boolean ram,boolean battery){}
    private static final Pattern MEMORY=Pattern.compile("(?<![\\p{L}\\p{N}])(?:памят[ьи]|мест[ао]|хранилищ[аеу]?|накопител[ьея]|диск[еа]?|оперативк[аиу]|озу|ram)(?![\\p{L}\\p{N}])");
    private static final Pattern BATTERY=Pattern.compile("(?<![\\p{L}\\p{N}])(?:заряд(?:а|е|ом)?|заряжен[ао]?|батаре[яиюй]|аккумулятор[ае]?)(?![\\p{L}\\p{N}])");
    static Request parse(String input,boolean memoryFollowup){
        String q=input.toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("[,?.!]+"," ").replaceAll("\\s+"," ").strip();
        q=q.replaceFirst("^(?:(?:мари|джарвис|скажи(?: мне)?|пожалуйста|подскажи|проверь|посмотри|покажи|узнай|а|ну|так) )+","");
        if(q.isEmpty() || q.matches(".*(?<![\\p{L}\\p{N}])(?:найди|поищи|приложение|напомни|занимает|занимают|как очистить|наушник[аиов]*|ноутбук[ае]?|часах|внешнего|пауэрбанка)(?![\\p{L}\\p{N}]).*"))return null;
        if(memoryFollowup && q.matches("(?:сколько (?:там |же )?(?:его|её|ее)|сколько именно|а сколько свободно|сколько свободно)"))return new Request(true,true,false);
        boolean asks=q.matches("(?:сколько|насколько|како[йвея]|какая|какие|чему равен|объем|остаток|уровень|хватает ли|состояние|свободн[а-я]*|доступн[а-я]*|память|заряд|батарея|оперативка|озу|хранилище)(?: .*|$)") ||
                q.matches(".*(?<![\\p{L}\\p{N}])(?:сколько|сколько там|объем памяти|уровень заряда)(?![\\p{L}\\p{N}]).*");
        if(!asks)return null;
        boolean memory=MEMORY.matcher(q).find(),battery=BATTERY.matcher(q).find();
        boolean ram=q.matches(".*(?<![\\p{L}\\p{N}])(?:оперативн[а-я]*|оперативк[ауи]|озу|ram)(?![\\p{L}\\p{N}]).*");
        boolean disk=memory && (!ram || q.matches(".*(?<![\\p{L}\\p{N}])(?:внутренн[а-я]*|постоянн[а-я]*|накопител[ьея]|хранилищ[аеу]?|мест[ао]|диск[еа]?)(?![\\p{L}\\p{N}]).*"));
        if(!ram && memory && !q.matches(".*(?<![\\p{L}\\p{N}])(?:мест[ао]|свободн[а-я]*|накопител[ьея]|хранилищ[аеу]?|внутренн[а-я]*|диске)(?![\\p{L}\\p{N}]).*"))ram=true;
        return disk||ram||battery?new Request(disk,ram,battery):null;
    }
    private static String gib(long bytes){return String.format(Locale.forLanguageTag("ru"),"%.1f",bytes/1073741824.0);}
    static String read(Context ctx,Request req){
        java.util.ArrayList<String> parts=new java.util.ArrayList<>();
        if(req.disk()){
            StatFs fs=new StatFs(Environment.getDataDirectory().getAbsolutePath());
            parts.add("В хранилище телефона свободно "+gib(fs.getAvailableBytes())+" ГиБ из "+gib(fs.getTotalBytes())+" ГиБ.");
        }
        if(req.ram()){
            ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();
            ctx.getSystemService(ActivityManager.class).getMemoryInfo(mi);
            parts.add("Оперативной памяти доступно "+gib(mi.availMem)+" ГиБ из "+gib(mi.totalMem)+" ГиБ.");
        }
        if(req.battery()){
            Intent state=ctx.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int level=state==null?-1:state.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);
            int scale=state==null?0:state.getIntExtra(BatteryManager.EXTRA_SCALE,0);
            parts.add(level<0||scale<=0?"Android не сообщил уровень заряда.":"Заряд батареи "+Math.round(100f*level/scale)+"%.");
        }
        return String.join(" ",parts);
    }
}
