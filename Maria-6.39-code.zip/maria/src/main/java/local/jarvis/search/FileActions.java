package local.jarvis.search;

import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.widget.Toast;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

final class FileActions {
    static final int SAVE=16;
    private final SearchActivity activity;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private Uri pendingCopy;
    private boolean editCopy;

    FileActions(SearchActivity activity){this.activity=activity;}
    private void notice(String text){Toast.makeText(activity,text,Toast.LENGTH_LONG).show();}
    void menu(PhoneSearch.Hit hit){
        Map<String,Runnable> menu=new LinkedHashMap<>();
        boolean drive=DriveFiles.remote(hit.original());
        if(drive)menu.put("Открыть оригинал на Диске",()->openDrive(hit));
        menu.put("Выбрать для команды Марии",()->{
            if("content".equals(hit.uri().getScheme()))activity.selectForCommand(hit.uri(),hit.name());
            else prepare(hit,uri->activity.selectForCommand(uri,hit.name()));
        });
        menu.put("Поделиться файлом",()->external(hit,Intent.ACTION_SEND,true));
        menu.put("Открыть в другом приложении",()->external(hit,Intent.ACTION_VIEW,true));
        boolean writable="content".equals(hit.uri().getScheme()) && activity.checkUriPermission(hit.uri(),
                Process.myPid(),Process.myUid(),Intent.FLAG_GRANT_WRITE_URI_PERMISSION)==PackageManager.PERMISSION_GRANTED;
        if(editorAvailable(hit.mime())){
            if(writable)menu.put("Редактировать файл",()->launchFile(hit.uri(),hit.mime(),Intent.ACTION_EDIT,true));
            else menu.put("Редактировать копию…",()->save(hit,true));
        }
        menu.put("Сохранить копию…",()->save(hit,false));
        if(drive)menu.put("Скопировать ссылку на Диск",()->{
            activity.getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText(hit.name(),driveLink(hit).toString()));
            notice("Ссылка скопирована.");
        });
        if(FilePreview.supported(hit.mime()) || hit.mime().startsWith("application/vnd.google-apps."))
            menu.put("Посмотреть в Марии",()->activity.preview(hit));
        new AlertDialog.Builder(activity).setTitle(hit.name()).setItems(menu.keySet().toArray(new String[0]),
                (d,i)->new ArrayList<>(menu.values()).get(i).run()).setNegativeButton("Закрыть",null).show();
    }
    private boolean editorAvailable(String mime){
        return new Intent(Intent.ACTION_EDIT).setDataAndType(Uri.parse("content://local.jarvis.search.exports/file"),mime)
                .resolveActivity(activity.getPackageManager())!=null;
    }
    private Uri driveLink(PhoneSearch.Hit hit){
        Uri original=hit.original();
        Uri.Builder link=Uri.parse("https://drive.google.com/open").buildUpon().appendQueryParameter("id",original.getLastPathSegment());
        String key=original.getQueryParameter("resourcekey");
        if(key!=null)link.appendQueryParameter("resourcekey",key);
        return link.build();
    }
    void openDrive(PhoneSearch.Hit hit){
        Intent view=new Intent(Intent.ACTION_VIEW,driveLink(hit));
        try{activity.startActivity(new Intent(view).setPackage("com.google.android.apps.docs"));}
        catch(ActivityNotFoundException absent){
            try{activity.startActivity(view);}catch(ActivityNotFoundException e){notice("Не удалось открыть ссылку на Диск.");}
        }
    }
    void external(PhoneSearch.Hit hit,String action,boolean chooser){
        if("content".equals(hit.uri().getScheme())){launchFile(hit.uri(),hit.mime(),action,chooser);return;}
        prepare(hit,uri->launchFile(uri,uri.getQueryParameter("mime"),action,chooser));
    }
    private void launchFile(Uri uri,String mime,String action,boolean chooser){
        Intent intent=new Intent(action).setType(mime);
        if(Intent.ACTION_SEND.equals(action))intent.putExtra(Intent.EXTRA_STREAM,uri);
        else intent.setDataAndType(uri,mime);
        intent.setClipData(ClipData.newRawUri("Файл",uri));
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if(Intent.ACTION_EDIT.equals(action))intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try{
            if(!Intent.ACTION_SEND.equals(action) && intent.resolveActivity(activity.getPackageManager())==null){
                notice("Для этого формата на телефоне нет подходящего приложения.");return;
            }
            activity.startActivity(chooser?Intent.createChooser(intent,Intent.ACTION_SEND.equals(action)?"Поделиться файлом":"Выберите приложение"):intent);
        }catch(ActivityNotFoundException|SecurityException e){notice("Приложение не смогло открыть файл с этим доступом.");}
    }
    private void prepare(PhoneSearch.Hit hit,java.util.function.Consumer<Uri> ready){
        notice("Готовлю файл…");
        io.execute(()->{
            PhoneSearch.Hit source=hit;
            try{
                if(DriveFiles.remote(hit.uri()))source=DriveFiles.download(activity,hit);
                Uri uri=ShareFiles.copy(activity,source);
                activity.runOnUiThread(()->{if(!activity.isDestroyed()&&!activity.isFinishing())ready.accept(uri);});
            }catch(Exception e){activity.runOnUiThread(()->notice("Не удалось получить файл. Проверьте доступ и свободное место."));}
            finally{if(source!=hit)new File(source.uri().getPath()).delete();}
        });
    }
    private void save(PhoneSearch.Hit hit,boolean edit){
        prepare(hit,source->{
            pendingCopy=source;editCopy=edit;
            Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(source.getQueryParameter("mime")).putExtra(Intent.EXTRA_TITLE,source.getQueryParameter("name"));
            try{activity.startActivityForResult(create,SAVE);}
            catch(ActivityNotFoundException e){pendingCopy=null;notice("Не удалось открыть выбор папки.");}
        });
    }
    void saved(Uri dest){
        Uri source=pendingCopy;boolean edit=editCopy;pendingCopy=null;editCopy=false;
        if(dest==null || source==null)return;
        io.execute(()->{
            try{
                ContentResolver resolver=activity.getContentResolver();
                try(InputStream in=resolver.openInputStream(source);OutputStream out=resolver.openOutputStream(dest,"wt")){
                    if(in==null || out==null)throw new IOException();
                    byte[] chunk=new byte[65536];int n;
                    while((n=in.read(chunk))!=-1)out.write(chunk,0,n);
                }
                activity.runOnUiThread(()->{
                    notice("Копия сохранена.");
                    if(edit && !activity.isFinishing() && !activity.isDestroyed())launchFile(dest,source.getQueryParameter("mime"),Intent.ACTION_EDIT,true);
                });
            }catch(Exception failed){activity.runOnUiThread(()->notice("Запись не завершена. Проверьте место и доступ к папке."));}
        });
    }
    void saveState(Bundle state){state.putParcelable("pendingCopy",pendingCopy);state.putBoolean("editCopy",editCopy);}
    void restore(Bundle state){if(state!=null){pendingCopy=state.getParcelable("pendingCopy");editCopy=state.getBoolean("editCopy");}}
    void close(){io.shutdown();}
}
