package local.jarvis.search;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.widget.*;
import java.util.*;
import java.io.*;
import org.json.*;

final class ObjectsBook {
    private final SearchActivity a;
    private final SharedPreferences prefs;
    String current="";
    ObjectsBook(SearchActivity a){this.a=a;prefs=a.getSharedPreferences("objects",0);}
    void ensure(String name){if(!prefs.contains(name))prefs.edit().putString(name,"{}").apply();}
    private JSONObject read(String name){
        try{return new JSONObject(prefs.getString(name,"{}"));}catch(JSONException e){throw new IllegalStateException(e);}
    }
    void prompt(String title,java.util.function.Consumer<String> done){
        EditText input=new EditText(a);input.setSingleLine();input.setHint(title);
        new AlertDialog.Builder(a).setTitle(title).setView(input).setPositiveButton("Сохранить",(d,w)->{
            String text=input.getText().toString().strip();if(!text.isEmpty())done.accept(text);
        }).setNegativeButton("Отмена",null).show();
    }
    void choose(java.util.function.Consumer<String> done){
        List<String> names=new ArrayList<>(prefs.getAll().keySet());Collections.sort(names);
        new AlertDialog.Builder(a).setTitle("Мои объекты").setItems(names.toArray(new String[0]),(d,i)->{current=names.get(i);done.accept(current);})
            .setPositiveButton("Новый объект",(d,w)->prompt("Название или адрес",name->{
                current=name;if(!prefs.contains(name))prefs.edit().putString(name,"{}").apply();done.accept(name);
            })).setNegativeButton("Закрыть",null).show();
    }
    void add(String name,PhoneSearch.Hit h){
        JSONObject object=read(name);
        try{
            JSONArray files=object.optJSONArray("files");if(files==null)files=new JSONArray();
            for(int i=0;i<files.length();i++)if(files.getJSONObject(i).getString("uri").equals(h.uri().toString()))return;
            JSONObject f=new JSONObject().put("uri",h.uri().toString()).put("name",h.name()).put("mime",h.mime())
                .put("source",h.path()).put("date",h.date()).put("stamp",h.stamp());
            files.put(f);object.put("files",files);
        }catch(JSONException e){throw new IllegalStateException(e);}
        prefs.edit().putString(name,object.toString()).apply();
    }
    List<PhoneSearch.Hit> files(String name){
        JSONArray arr=read(name).optJSONArray("files");List<PhoneSearch.Hit> list=new ArrayList<>();
        if(arr!=null)for(int i=0;i<arr.length();i++)try{
            JSONObject f=arr.getJSONObject(i);list.add(new PhoneSearch.Hit(f.getString("name"),f.getString("source"),f.getString("mime"),Uri.parse(f.getString("uri")),f.optLong("date"),f.getString("stamp")));
        }catch(JSONException ignored){}
        return list;
    }
    void show(String name){
        current=name;List<PhoneSearch.Hit> docs=files(name);List<String> titles=new ArrayList<>();
        for(var file:docs)titles.add(file.name());
        JSONArray notes=read(name).optJSONArray("notes");if(notes!=null)for(int i=0;i<notes.length();i++)titles.add("Заметка · "+notes.optString(i));
        int visitStart=titles.size();var visits=ShowingNotes.forObject(a,name);
        for(var visit:visits)titles.add("Показ · "+visit.person()+" · "+Promises.when(visit.created()));
        int promiseStart=titles.size();var commitments=Promises.forObject(a,name);
        for(var item:commitments)titles.add(item.label());
        new AlertDialog.Builder(a).setTitle(name).setItems(titles.toArray(new String[0]),(d,i)->{
            if(i<docs.size())a.open(docs.get(i));
            else if(i>=promiseStart)a.promiseActions.select(commitments.get(i-promiseStart));
            else if(i>=visitStart)a.showingNotes.show(visits.get(i-visitStart));
            else new AlertDialog.Builder(a).setMessage(titles.get(i)).setPositiveButton("Назад",(x,w)->show(name)).show();
        }).setPositiveButton("Заметка",(d,w)->a.newNote(name)).setNeutralButton("Подборка",(d,w)->bundle(name)).setNegativeButton("Закрыть",null).show();
    }
    void note(String name,String text){
        JSONObject object=read(name);try{JSONArray notes=object.optJSONArray("notes");if(notes==null)notes=new JSONArray();notes.put(text);object.put("notes",notes);}
        catch(JSONException e){throw new IllegalStateException(e);}
        prefs.edit().putString(name,object.toString()).apply();
        new AlertDialog.Builder(a).setTitle("Заметка сохранена").setMessage(text).setPositiveButton("Напомнить",(d,w)->Reminder.choose(a,name,text))
            .setNegativeButton("К объекту",(d,w)->show(name)).show();
    }
    void bundle(String name){bundle(name,null);}
    void bundle(String name,Set<String> suggested){
        List<PhoneSearch.Hit> files=files(name);
        if(files.isEmpty()){Toast.makeText(a,"Добавьте файлы удержанием результата поиска",Toast.LENGTH_LONG).show();return;}
        boolean[] selected=new boolean[files.size()];for(int i=0;i<files.size();i++)selected[i]=suggested==null||suggested.contains(files.get(i).uri().toString());
        new AlertDialog.Builder(a).setTitle("Подборка · "+name).setMultiChoiceItems(files.stream().map(PhoneSearch.Hit::name).toArray(String[]::new),selected,(d,i,on)->selected[i]=on)
            .setPositiveButton("Поделиться",(d,w)->{
                List<PhoneSearch.Hit> chosen=new ArrayList<>();for(int i=0;i<files.size();i++)if(selected[i])chosen.add(files.get(i));
                if(!chosen.isEmpty())a.shareFiles(chosen);
            }).setNegativeButton("Назад",(d,w)->show(name)).show();
    }
}
