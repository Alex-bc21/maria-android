package local.jarvis.search;

import android.app.Activity;
import android.app.Dialog;
import android.view.*;
import android.text.TextUtils;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.util.Size;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

final class FilePreview {
    static boolean supported(String mime) {
        return mime.startsWith("image/") || mime.equals("application/pdf") || mime.startsWith("text/");
    }
    static void show(SearchActivity activity,PhoneSearch.Hit hit) throws IOException {
        Studio ui=new Studio(activity);
        Dialog dialog=new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout panel=ui.column();panel.setPadding(ui.dp(16),ui.dp(16),ui.dp(16),ui.dp(16));
        panel.setBackground(ui.shape(Studio.PANEL,24,Studio.EDGE));
        LinearLayout header=ui.row();panel.addView(header);
        TextView title=ui.text(hit.name(),17,Studio.TEXT,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        header.addView(title,new LinearLayout.LayoutParams(0,-2,1));ui.gap(header,8);
        Button actions=new Button(activity);actions.setAllCaps(false);actions.setText("Действия");header.addView(actions);
        actions.setOnClickListener(v->activity.files.menu(hit));
        header.addView(ui.iconButton("close","Закрыть просмотр",Studio.TEXT,dialog::dismiss),ui.lp(48,48));
        ui.gap(panel,12);dialog.setContentView(panel);
        if (hit.mime().startsWith("text/")) {
            try (InputStream in=activity.getContentResolver().openInputStream(hit.uri())) {
                if (in==null) throw new IOException();
                Reader reader=new InputStreamReader(in,StandardCharsets.UTF_8);
                char[] buffer=new char[2048]; StringBuilder text=new StringBuilder();
                int n;
                while (text.length()<65536 && (n=reader.read(buffer))!=-1) text.append(buffer,0,n);
                if (text.length()>=65536) text.append("\n…");
                ScrollView scroll=new ScrollView(activity);TextView document=ui.text(text.toString(),17,Studio.TEXT,false);
                document.setTextIsSelectable(true);document.setLineSpacing(ui.dp(4),1);
                scroll.addView(document);panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
                present(activity,dialog);
            }
            return;
        }
        ImageView image=new ImageView(activity);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setBackground(ui.shape(0xff14131c,12,0));image.setClipToOutline(true);
        panel.addView(image,new LinearLayout.LayoutParams(-1,0,1));
        image.setContentDescription(hit.name());
        if (hit.mime().startsWith("image/")) {
            Bitmap bitmap=ImageDecoder.decodeBitmap(ImageDecoder.createSource(activity.getContentResolver(),hit.uri()),(decoder,info,src)->{
                Size size=info.getSize();
                double scale=Math.min(1,2048.0/Math.max(size.getWidth(),size.getHeight()));
                decoder.setTargetSize(Math.max(1,(int)(size.getWidth()*scale)),Math.max(1,(int)(size.getHeight()*scale)));
            });
            image.setImageBitmap(bitmap);
            present(activity,dialog); return;
        }
        ParcelFileDescriptor fd=activity.getContentResolver().openFileDescriptor(hit.uri(),"r");
        if (fd==null) throw new IOException();
        PdfRenderer pdf;
        try { pdf=new PdfRenderer(fd); } catch (Exception e) { fd.close(); throw e; }
        if (pdf.getPageCount()<1) { pdf.close(); throw new IOException(); }
        ui.gap(panel,10);LinearLayout nav=ui.row();panel.addView(nav);
        ImageView prev=ui.iconButton("back","Предыдущая страница",Studio.TEXT,()->{});
        ImageView next=ui.iconButton("arrow","Следующая страница",Studio.TEXT,()->{});
        nav.addView(prev,ui.lp(48,48));TextView label=ui.text("",15,Studio.MUTED,true);label.setGravity(Gravity.CENTER);
        nav.addView(label,new LinearLayout.LayoutParams(0,-2,1));nav.addView(next,ui.lp(48,48));
        if(hit.reason().startsWith("Цитата")){
            TextView quote=ui.text(hit.reason(),15,Studio.TEXT,false);
            quote.setTextIsSelectable(true);
            ScrollView scroll=new ScrollView(activity);scroll.addView(quote);panel.addView(scroll,ui.lp(-1,94));
        }
        Button ask=new Button(activity);ask.setAllCaps(false);ask.setText(activity.cloudReady()?"Спросить у OpenAI":"Спросить о договоре");panel.addView(ask);
        ask.setOnClickListener(v->{dialog.dismiss();activity.askAbout(hit);});
        int[] page={Math.max(0,Math.min(hit.page(),pdf.getPageCount()-1))};
        Runnable render=()->{
            try (PdfRenderer.Page p=pdf.openPage(page[0])) {
                float scale=1500f/Math.max(p.getWidth(),p.getHeight());
                Bitmap b=Bitmap.createBitmap(Math.max(1,Math.round(p.getWidth()*scale)),Math.max(1,Math.round(p.getHeight()*scale)),Bitmap.Config.ARGB_8888);
                b.eraseColor(Color.WHITE); p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                image.setImageBitmap(b);
                label.setText("Страница "+(page[0]+1)+" из "+pdf.getPageCount());
                prev.setEnabled(page[0]>0); next.setEnabled(page[0]+1<pdf.getPageCount());
                prev.setAlpha(prev.isEnabled()?1f:.35f);next.setAlpha(next.isEnabled()?1f:.35f);
            }
        };
        try { render.run(); } catch (RuntimeException e) { pdf.close(); throw e; }
        dialog.setOnDismissListener(d->pdf.close());
        prev.setOnClickListener(v->{page[0]--;render.run();});
        next.setOnClickListener(v->{page[0]++;render.run();});
        present(activity,dialog);
    }
    private static void present(Activity activity,Dialog dialog){
        Window win=dialog.getWindow();
        win.setBackgroundDrawableResource(android.R.color.transparent);
        win.setDimAmount(.72f);
        dialog.show();
        View root=activity.findViewById(android.R.id.content);
        int margin=Math.round(10*activity.getResources().getDisplayMetrics().density);
        win.setLayout(root.getWidth()-2*margin,Math.round(root.getHeight()*.84f));
    }
}
