package local.jarvis.search;

import android.content.Context;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import org.json.*;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.cert.CertificateFactory;
import java.util.*;
import javax.net.ssl.*;

final class CloudContract {
    record Answer(String text,List<PhoneSearch.Hit> quotes) {}
    static final class Issue extends IOException {
        Issue(String message){super(message);}
    }
    static String read(InputStream source,int limit) throws IOException {
        try(InputStream in=source;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buffer=new byte[4096];int n;
            while((n=in.read(buffer))!=-1){
                if(out.size()+n>limit)throw new IOException("Size limit");
                out.write(buffer,0,n);
            }
            return out.toString("UTF-8");
        }
    }
    record Profile(URL url,String token,SSLSocketFactory sockets) {
        static Profile load(String json) throws Exception {
            JSONObject data=new JSONObject(json);
            URL url=new URL(data.getString("url"));
            String token=data.getString("token");
            if(!url.getProtocol().equals("https")||url.getHost().isEmpty()||url.getUserInfo()!=null||
                    url.getQuery()!=null||url.getRef()!=null||!url.getPath().equals("/contract")||
                    !token.matches("[A-Za-z0-9_-]{32,128}"))throw new IOException("Invalid profile");
            KeyStore store=KeyStore.getInstance(KeyStore.getDefaultType());store.load(null);
            byte[] pem=data.getString("certificate").getBytes(StandardCharsets.US_ASCII);
            store.setCertificateEntry("jarvis",CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(pem)));
            TrustManagerFactory trust=TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trust.init(store);SSLContext tls=SSLContext.getInstance("TLS");tls.init(null,trust.getTrustManagers(),null);
            return new Profile(url,token,tls.getSocketFactory());
        }
    }
    private static String spaces(String text){return text.replaceAll("[\\s\\p{Z}]+"," ").trim();}
    static Answer ask(Context context,PhoneSearch.Hit document,String question,String lastTurn,Profile profile) throws Exception {
        return ask(context,document,question,lastTurn,profile,"");
    }
    static Answer ask(Context context,PhoneSearch.Hit document,String question,String lastTurn,Profile profile,String sealedKey) throws Exception {
        if(question.length()>8000)throw new Issue("Сократите вопрос до 8000 знаков.");
        JSONArray pages=new JSONArray();Set<Integer> scanned=new HashSet<>();int size=0;int unreadable=0;
        try(ContentIndex index=new ContentIndex(context,new ContentRequest(false,""),0);
            ParcelFileDescriptor fd=context.getContentResolver().openFileDescriptor(document.uri(),"r");
            PdfRenderer pdf=new PdfRenderer(fd)){
            for(int i=0;i<pdf.getPageCount();i++){
                if(Thread.currentThread().isInterrupted())throw new InterruptedException();
                String raw=index.pageText(document,pdf,i);
                if(raw.startsWith("[OCR]\n")){scanned.add(i);raw=raw.substring(6);}
                String page=spaces(raw);size+=page.length();
                if(size>250000)throw new Issue("Этот договор превышает лимит в 250 000 знаков. Откройте нужный раздел отдельным PDF.");
                if(page.isEmpty())unreadable++;
                pages.put(new JSONObject().put("page",i+1).put("text",page));
            }
        }
        if(size==0)throw new Issue("В PDF не удалось прочитать текст. Проверьте качество скана.");
        if(Thread.currentThread().isInterrupted())throw new InterruptedException();
        JSONObject payload=new JSONObject().put("pages",pages).put("question",question).put("previous_turn",lastTurn);
        boolean direct=!sealedKey.isEmpty();
        URL destination=direct?new URL("https://api.openai.com/v1/responses"):profile.url();
        String credential;
        if(direct){
            try{credential=DeviceCredential.open(android.util.Base64.decode(sealedKey,android.util.Base64.NO_WRAP));}
            catch(Exception e){throw new Issue("Не удалось открыть ключ на телефоне. Разблокируйте телефон или настройте прямое подключение заново.");}
            int template=context.getResources().getIdentifier("contract_request","raw",context.getPackageName());
            payload=new JSONObject(read(context.getResources().openRawResource(template),16384)).put("input",payload.toString());
        }else{credential=profile.token();}
        HttpsURLConnection conn=(HttpsURLConnection)destination.openConnection();
        if(!direct)conn.setSSLSocketFactory(profile.sockets());
        conn.setInstanceFollowRedirects(false);
        conn.setRequestMethod("POST");conn.setConnectTimeout(12000);conn.setReadTimeout(130000);
        conn.setDoOutput(true);conn.setRequestProperty("Authorization","Bearer "+credential);
        conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
        byte[] bytes=payload.toString().getBytes(StandardCharsets.UTF_8);conn.setFixedLengthStreamingMode(bytes.length);
        JSONObject response;
        try{
            try(OutputStream out=conn.getOutputStream()){out.write(bytes);}
            int status=conn.getResponseCode();
            if(status!=200)throw new Issue(switch(status){
                case 403 -> direct?"OpenAI отклонил доступ с этого телефона или для этого проекта.":"Сервер не принял подключение. Выберите актуальный файл подключения Марии.";
                case 401 -> "OpenAI не принял ключ или не разрешил запрос для этого проекта. Проверьте доступ ключа к модели.";
                case 429 -> "OpenAI сообщил об ограничении запросов или доступного баланса. Повторите позже или проверьте лимиты проекта.";
                default -> "Сервер не смог получить ответ OpenAI. Проверьте ключ, соединение и доступ к модели.";});
            response=new JSONObject(read(conn.getInputStream(),150000));
        }finally{conn.disconnect();}
        if(direct)response=new JSONObject(outputText(response));
        JSONArray findings=response.getJSONArray("findings");
        if(findings.length()>8)throw invalidEvidence();
        List<PhoneSearch.Hit> quotes=new ArrayList<>();StringBuilder result=new StringBuilder();
        for(int i=0;i<findings.length();i++){
            JSONObject finding=findings.getJSONObject(i);String statement=finding.getString("statement").strip();
            JSONArray sources=finding.getJSONArray("sources");Set<Integer> numbers=new LinkedHashSet<>();
            if(statement.isEmpty()||sources.length()==0||sources.length()>10)throw invalidEvidence();
            for(int j=0;j<sources.length();j++){
                JSONObject source=sources.getJSONObject(j);int number=source.getInt("page");String quote=spaces(source.getString("quote"));
                if(number<1||number>pages.length()||quote.isEmpty()||quote.length()>1200||!pages.getJSONObject(number-1).getString("text").contains(quote))throw invalidEvidence();
                numbers.add(number);
                String label="Цитата"+(scanned.contains(number-1)?" со скана":"")+" · страница "+number+"\n«"+quote+"»";
                if(quotes.stream().noneMatch(h->h.reason().equals(label)))quotes.add(document.matched(1,number-1,label));
            }
            if(result.length()>0)result.append("\n\n");
            result.append(statement).append(" (стр. ").append(android.text.TextUtils.join(", ",numbers)).append(")");
        }
        if(findings.length()==0)result.append("В прочитанном тексте договора недостаточно сведений для ответа на этот вопрос.");
        if(unreadable>0)result.append("\nСтраниц без читаемого текста: ").append(unreadable).append(".");
        if(result.length()>3800)throw new Issue("Ответ слишком длинный для озвучивания. Уточните вопрос по одному условию.");
        return new Answer(result.toString(),quotes);
    }
    static String outputText(JSONObject response) throws Exception {
        if(!"completed".equals(response.optString("status")))throw new Issue("OpenAI не завершил ответ. Попробуйте ещё раз.");
        StringBuilder text=new StringBuilder();
        JSONArray output=response.getJSONArray("output");
        for(int i=0;i<output.length();i++){
            JSONObject item=output.getJSONObject(i);
            if(!"message".equals(item.optString("type")))continue;
            JSONArray parts=item.getJSONArray("content");
            for(int j=0;j<parts.length();j++){
                JSONObject part=parts.getJSONObject(j);
                if("output_text".equals(part.optString("type")))text.append(part.getString("text"));
            }
        }
        if(text.length()==0)throw new Issue("OpenAI вернул пустой ответ.");
        return text.toString();
    }
    private static Issue invalidEvidence(){return new Issue("Не удалось подтвердить цитату на указанной странице. Уточните вопрос или найдите пункт на телефоне.");}
}
