package local.jarvis.search;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.provider.CalendarContract;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

/** Live daily overview. Refreshes when the user returns from an action. */
final class Today extends Dialog {
    static final int CALENDAR=27;
    record Snapshot(long now,List<Showing.Meeting> meetings,List<Promises.Item> overdue,List<Promises.Item> due,
                    List<ShowingNotes.Entry> unscheduled,String draft,String promiseDraft,boolean calendarAllowed,String calendarError){}
    private final SearchActivity a;
    private final Studio ui;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Runnable tick=()->refresh();
    private LinearLayout content;
    private TextView heading,read;
    private Snapshot snapshot;
    private boolean speaking,closed,autoRead;
    private int generation;
    private Future<?> loading;
    private final ArrayDeque<String> spoken=new ArrayDeque<>();

    Today(SearchActivity a){
        super(a);this.a=a;ui=new Studio(a);requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout page=ui.column();page.setBackgroundColor(Studio.BG);
        page.setPadding(ui.dp(18),ui.dp(12),ui.dp(18),ui.dp(12));
        LinearLayout header=ui.row();page.addView(header);
        heading=ui.text("Сегодня",30,Studio.TEXT,true);header.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        header.addView(ui.iconButton("close","Закрыть сегодня",Studio.MUTED,this::dismiss),ui.lp(48,48));
        ui.gap(page,12);
        ScrollView scroll=new ScrollView(a);page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        content=ui.column();scroll.addView(content);
        ui.gap(page,10);
        read=ui.text("Озвучить сводку",17,Studio.BG,true);read.setGravity(Gravity.CENTER);read.setBackground(ui.surface(Studio.LILAC,16,0));
        read.setEnabled(false);
        ui.action(read,"Озвучить сводку",()->{if(speaking)stopSpeech();else speak();});page.addView(read,ui.lp(-1,54));
        setContentView(page);
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        page.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                var bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(ui.dp(18)+bars.left,ui.dp(12)+bars.top,ui.dp(18)+bars.right,ui.dp(12)+bars.bottom);
            }return insets;
        });
        setOnDismissListener(d->{generation++;if(loading!=null)loading.cancel(true);main.removeCallbacks(tick);stopSpeech();});
    }
    static boolean command(String text){
        return Showing.clean(text).replaceFirst("^(?:джарвис|jarvis) ","").matches(
            "сегодня|(?:покажи |открой )?(?:мой день|мои дела на сегодня)|что у меня сегодня|что мне сегодня нужно сделать|что мне нужно сделать сегодня");
    }
    void open(boolean aloud){
        autoRead=aloud;show();getWindow().setLayout(-1,-1);refresh();
    }
    @Override public void onWindowFocusChanged(boolean focused){
        super.onWindowFocusChanged(focused);
        if(focused&&content!=null&&isShowing())refresh();
    }
    static Snapshot load(Context context,long now){
        long tomorrow=Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault()).toLocalDate().plusDays(1)
            .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
        List<Promises.Item> overdue=new ArrayList<>(),due=new ArrayList<>();
        for(var item:Promises.all(context)){
            if(!Promises.active(item))continue;
            if(item.due()<now)overdue.add(item);else if(item.due()<tomorrow)due.add(item);
        }
        overdue.sort(Comparator.comparingLong(Promises.Item::due));due.sort(Comparator.comparingLong(Promises.Item::due));
        boolean allowed=context.checkSelfPermission(Manifest.permission.READ_CALENDAR)==PackageManager.PERMISSION_GRANTED;
        List<Showing.Meeting> meetings=List.of();String error="";
        if(allowed)try{meetings=Showing.today(context,now);}catch(RuntimeException e){error="Не удалось прочитать календарь. Повторите позже.";}
        var note=context.getSharedPreferences("showing_note_draft",0);
        String draft="";
        if(note.contains("id")){
            draft=String.join(" · ",java.util.stream.Stream.of(note.getString("person",""),note.getString("object","")).filter(s->!s.isBlank()).toList());
            if(draft.isBlank())draft="Новый итог показа";
        }
        var promise=context.getSharedPreferences("promise_draft",0);
        String promiseDraft=promise.getString("note","");
        String source=promise.getString("showing","");
        List<ShowingNotes.Entry> unscheduled=ShowingNotes.all(context).stream()
            .filter(e->!e.promise().isBlank()&&!e.reminded()&&!e.id().equals(source)).toList();
        return new Snapshot(now,meetings,overdue,due,unscheduled,draft,promiseDraft,allowed,error);
    }
    void refresh(){
        if(closed||!isShowing())return;
        main.removeCallbacks(tick);int token=++generation;
        if(loading!=null)loading.cancel(true);
        loading=worker.submit(()->{
            Snapshot data=load(a,System.currentTimeMillis());
            a.runOnUiThread(()->{
                if(closed||!isShowing()||token!=generation)return;
                snapshot=data;render();main.postDelayed(tick,60000);
                if(autoRead){autoRead=false;speak();}
            });
        });
    }
    private void section(String title){
        ui.gap(content,16);content.addView(ui.text(title,20,Studio.TEXT,true));ui.gap(content,10);
    }
    private void row(String title,String detail,int color,Runnable action){
        LinearLayout box=ui.column();box.setPadding(ui.dp(14),ui.dp(12),ui.dp(14),ui.dp(12));
        box.setBackground(ui.surface(Studio.PANEL,18,Studio.EDGE));box.addView(ui.text(title,17,color,true));
        if(!detail.isBlank()){ui.gap(box,6);box.addView(ui.text(detail,15,Studio.MUTED,false));}
        if(action!=null)ui.action(box,title,()->{stopSpeech();action.run();});
        content.addView(box,ui.lp(-1,-2));ui.gap(content,8);
    }
    private String meetingTime(Showing.Meeting meeting){
        if(meeting.allDay())return "Весь день";
        String state=meeting.end()<=snapshot.now()?" · завершена":meeting.begin()<=snapshot.now()?" · сейчас":"";
        return Promises.when(meeting.begin())+state;
    }
    private void render(){
        read.setEnabled(true);
        heading.setText("Сегодня · "+Instant.ofEpochMilli(snapshot.now()).atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("d MMM",Locale.forLanguageTag("ru"))));
        content.removeAllViews();
        section("Встречи");
        if(!snapshot.calendarAllowed()){
            row("Подключить календарь","Разрешите чтение встреч. Обещания и заметки уже доступны.",Studio.LILAC,
                ()->a.requestPermissions(new String[]{Manifest.permission.READ_CALENDAR},CALENDAR));
        }else if(!snapshot.calendarError().isEmpty()){
            row("Обновить календарь",snapshot.calendarError(),Studio.PEACH,this::refresh);
        }else if(snapshot.meetings().isEmpty())row("Встреч на сегодня нет","Проверены все видимые календари телефона.",Studio.MUTED,null);
        else for(var meeting:snapshot.meetings())row(meeting.title(),meetingTime(meeting)+(meeting.address().isBlank()?"":"\n"+meeting.address()),Studio.LILAC,()->meeting(meeting));
        if(!snapshot.overdue().isEmpty()){
            section("Просрочено");
            for(var item:snapshot.overdue())promise(item);
        }
        section("Обещания на сегодня");
        if(snapshot.due().isEmpty())row("На сегодня больше нет обещаний","",Studio.MUTED,null);
        else for(var item:snapshot.due())promise(item);
        if(!snapshot.draft().isEmpty()||!snapshot.promiseDraft().isEmpty()||!snapshot.unscheduled().isEmpty()){
            section("Нужно закончить");
            if(!snapshot.draft().isEmpty())row("Завершить итог показа",snapshot.draft(),Studio.MINT,()->{dismiss();a.showingNotes.edit();});
            if(!snapshot.promiseDraft().isEmpty())row("Уточнить напоминание",snapshot.promiseDraft(),Studio.MINT,()->{dismiss();a.resumePromise();});
            for(var entry:snapshot.unscheduled())row("Назначить напоминание · "+entry.person(),
                entry.object()+"\n"+entry.promise(),Studio.MINT,()->{dismiss();a.startShowingPromise(entry);});
        }
    }
    private void promise(Promises.Item item){
        row(item.note(),item.object()+"\n"+Promises.when(item.due()),item.due()<snapshot.now()?Studio.PEACH:Studio.MINT,()->{
            new AlertDialog.Builder(a).setTitle(item.note()).setMessage(item.object()+"\n"+item.label())
                .setPositiveButton("Изменить задачу",(d,w)->a.promiseActions.select(item))
                .setNeutralButton("Объект",(d,w)->a.book.show(item.object())).setNegativeButton("Назад",null).show();
        });
    }
    private void meeting(Showing.Meeting meeting){
        new AlertDialog.Builder(a).setTitle(meeting.title()).setMessage(meetingTime(meeting)+"\n"+meeting.address())
            .setPositiveButton("Календарь",(d,w)->{
                try{a.startActivity(new Intent(Intent.ACTION_VIEW,ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI,meeting.id()))
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,meeting.begin()).putExtra(CalendarContract.EXTRA_EVENT_END_TIME,meeting.end()));}
                catch(ActivityNotFoundException e){a.reply("Приложение календаря недоступно.");}
            }).setNeutralButton("Объект",(d,w)->{
                String text=" "+Showing.clean(meeting.title()+" "+meeting.address())+" ";
                List<String> matches=a.getSharedPreferences("objects",0).getAll().keySet().stream()
                    .filter(n->text.contains(" "+Showing.clean(n)+" ")).toList();
                if(matches.size()==1)a.book.show(matches.get(0));else a.book.choose(a.book::show);
            }).setNegativeButton("Назад",null).show();
    }
    private void speak(){
        if(snapshot==null)return;
        stopSpeech();
        List<String> lines=new ArrayList<>();
        lines.add("Сегодня. "+(snapshot.calendarAllowed()?(snapshot.calendarError().isEmpty()?"Встреч: "+snapshot.meetings().size()+".":snapshot.calendarError()):"Доступ к календарю не выдан."));
        for(var meeting:snapshot.meetings())lines.add(meeting.title()+". "+meetingTime(meeting)+". "+meeting.address()+".");
        lines.add("Просроченных обещаний: "+snapshot.overdue().size()+".");
        for(var item:snapshot.overdue())lines.add(item.object()+". "+item.note()+". Срок "+Promises.when(item.due())+".");
        lines.add("Предстоящих обещаний на сегодня: "+snapshot.due().size()+".");
        for(var item:snapshot.due())lines.add(item.object()+". "+item.note()+". "+Promises.when(item.due())+".");
        if(!snapshot.draft().isEmpty())lines.add("Остался черновик итога показа. "+snapshot.draft()+".");
        if(!snapshot.promiseDraft().isEmpty())lines.add("Нужно уточнить напоминание. "+snapshot.promiseDraft()+".");
        for(var entry:snapshot.unscheduled())lines.add("Нужно назначить напоминание. "+entry.person()+". "+entry.object()+". "+entry.promise());
        for(String line:lines)for(int start=0;start<line.length();start+=3000)spoken.add(line.substring(start,Math.min(start+3000,line.length())));
        speaking=true;read.setText("Остановить озвучивание");read.setContentDescription("Остановить озвучивание");next();
    }
    private void next(){
        if(!isShowing()||!speaking)return;
        if(spoken.isEmpty()){speaking=false;read.setText("Озвучить сводку");read.setContentDescription("Озвучить сводку");return;}
        a.sayToday(spoken.removeFirst(),this::next);
    }
    private void stopSpeech(){
        if(speaking)a.stopTodayVoice();
        speaking=false;spoken.clear();read.setText("Озвучить сводку");read.setContentDescription("Озвучить сводку");
    }
    void close(){closed=true;dismiss();worker.shutdownNow();main.removeCallbacks(tick);}
    void pauseSpeech(){stopSpeech();}
}
