package local.jarvis.search;

import java.util.Locale;
import java.util.regex.*;

record ContentRequest(boolean photo,String terms,boolean lettering,boolean video,boolean includeTextFiles,boolean scan) {
    ContentRequest(boolean photo,String terms,boolean lettering){this(photo,terms,lettering,false,false,false);}
    ContentRequest(boolean photo,String terms){this(photo,terms,false);}
    boolean visual(){return photo && !lettering;}
    private static final Pattern LETTERS=Pattern.compile("^(?:скрин(?:шот)?(?:ы)?|фото(?:графия)?|снимок)[, ]+(?:где написано|на котором написано|со словами|с надписью|с текстом)\\s+(.+)$");
    private static final Pattern CONTENT=Pattern.compile(
        "^(фото(?:графи[яиюй])?|сним(?:ок|ки)|картин(?:ка|ку|ки)|видео|ролик|pdf|пдф|пэдээф|скан|договор|контракт|документ(?:ы)?|файл(?:ы)?)"+
        "(?:[ -]+(?:файл|документ|pdf|пдф))?\\s*[,.:—-]?\\s+(?:на котор(?:ом|ой|ых)|в котор(?:ом|ой|ых)|где|про|о|об|со словами|с текстом|с фразой|по содержимому|с изображением|с)\\s+(.+)$");
    static ContentRequest parse(String text) {
        Matcher letters=LETTERS.matcher(text.toLowerCase(Locale.ROOT).strip());
        if(letters.matches())return new ContentRequest(true,letters.group(1).replaceAll("^[«\"]+|[»\".!?]+$","").trim(),true);
        Matcher m=CONTENT.matcher(text.toLowerCase(Locale.ROOT).strip());
        if(!m.matches()) return null;
        String terms=m.group(2).replaceFirst("^(?:(?:есть|видно|видна|виден|видны|изображ[её]н(?:а|ы|о)?|присутствует|содержится|написано|встречается)\\s+)+","")
                .replaceFirst("^(?:слова|слово|текст|фраза)\\s+","").replaceAll("^[«\"“]+|[»\"”.!?]+$","").strip();
        if(terms.isEmpty() || terms.matches("^(?:названием|именем)\\b.*")) return null;
        String type=m.group(1);
        boolean video=type.matches("видео|ролик");
        return new ContentRequest(video || type.matches("фото.*|сним.*|картин.*"),terms,false,video,type.matches("файл.*|документ.*"),type.equals("скан"));
    }
}
