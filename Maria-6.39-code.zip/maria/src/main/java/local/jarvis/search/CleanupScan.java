package local.jarvis.search;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import java.io.*;
import java.nio.file.Files;
import java.security.*;
import java.util.*;

final class CleanupScan {
    static final long MIN_MEDIA=256*1024, WEEK=7L*86400000;
    record Temp(File path,long bytes,long modified){}
    record Media(Uri uri,String path,String name,long bytes,long modified,boolean favorite){
        String location(){return path+name;}
    }
    record Copy(Media item,Media keep,String hash){}
    final List<Temp> temp=new ArrayList<>();
    final List<Copy> copies=new ArrayList<>();
    int checked,unreadable;
    private static boolean plain(File f) throws IOException {
        return f.getCanonicalFile().equals(f.getAbsoluteFile()) && f.isFile() && !Files.isSymbolicLink(f.toPath());
    }
    static List<Temp> temporary(File cache,long now) throws IOException {
        ArrayList<Temp> found=new ArrayList<>();
        for(File dir:new File[]{cache,new File(cache,"outbox")}){
            if(!dir.getCanonicalFile().equals(dir.getAbsoluteFile()))continue;
            File[] files=dir.listFiles();if(files==null)continue;
            for(File f:files){
                String pattern=dir.equals(cache)?"drive-preview-[A-Za-z0-9_-]+\\.tmp":"[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}";
                if(f.getName().matches(pattern) && plain(f) && f.lastModified()>0 && f.lastModified()<=now-WEEK)
                    found.add(new Temp(f,f.length(),f.lastModified()));
            }
        }
        return found;
    }
    static boolean remove(Temp approved) throws IOException {
        File f=approved.path();
        return plain(f) && f.lastModified()==approved.modified() && f.length()==approved.bytes()
            && f.lastModified()<=System.currentTimeMillis()-WEEK && f.delete();
    }
    private static void interrupted() throws InterruptedIOException {
        if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();
    }
    private static String digest(ContentResolver resolver,Media media) throws IOException {
        MessageDigest hash;
        try{hash=MessageDigest.getInstance("SHA-256");}catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}
        long count=0;byte[] block=new byte[131072];
        try(InputStream in=resolver.openInputStream(media.uri())){
            if(in==null)throw new IOException();
            int n;while((n=in.read(block))!=-1){interrupted();count+=n;hash.update(block,0,n);}
        }
        if(count!=media.bytes())throw new IOException();
        return android.util.Base64.encodeToString(hash.digest(),android.util.Base64.NO_WRAP);
    }
    private static final String[] COLUMNS={"_id","relative_path","_display_name","_size","date_modified","is_favorite"};
    private static Media media(Uri uri,Cursor c){
        return new Media(uri,Objects.toString(c.getString(1),""),Objects.toString(c.getString(2),""),c.getLong(3),c.getLong(4),c.getInt(5)!=0);
    }
    static CleanupScan run(Context ctx) throws IOException {
        CleanupScan scan=new CleanupScan();
        scan.temp.addAll(temporary(ctx.getCacheDir(),System.currentTimeMillis()));
        if(Build.VERSION.SDK_INT<30)return scan;
        ContentResolver resolver=ctx.getContentResolver();
        Map<Long,List<Media>> sizes=new HashMap<>();
        for(String volume:MediaStore.getExternalVolumeNames(ctx)){
            for(Uri collection:new Uri[]{MediaStore.Images.Media.getContentUri(volume),MediaStore.Video.Media.getContentUri(volume)}){
                try(Cursor c=resolver.query(collection,COLUMNS,"_size >= ? AND is_trashed=0 AND is_pending=0",new String[]{Long.toString(MIN_MEDIA)},null)){
                    if(c==null){scan.unreadable++;continue;}
                    while(c.moveToNext()){
                        interrupted();
                        Media file=media(ContentUris.withAppendedId(collection,c.getLong(0)),c);
                        sizes.computeIfAbsent(file.bytes(),k->new ArrayList<>()).add(file);scan.checked++;
                    }
                }catch(SecurityException denied){scan.unreadable++;}
            }
        }
        Comparator<Media> prefer=Comparator.comparing((Media m)->!m.favorite())
            .thenComparing(m->!m.path().startsWith("DCIM/")).thenComparingLong(Media::modified).thenComparing(m->m.uri().toString());
        for(List<Media> group:sizes.values()){
            if(group.size()<2)continue;
            group.sort(prefer);
            Map<String,Media> originals=new HashMap<>();
            for(Media m:group){
                interrupted();
                try{
                    String hash=digest(resolver,m);Media keep=originals.putIfAbsent(hash,m);
                    if(keep!=null && !m.favorite())scan.copies.add(new Copy(m,keep,hash));
                }catch(InterruptedIOException cancelled){throw cancelled;}
                catch(IOException|SecurityException unavailable){scan.unreadable++;}
            }
        }
        scan.copies.sort(Comparator.comparingLong((Copy c)->c.item().modified()).reversed().thenComparing(c->c.item().location()));
        return scan;
    }
    private static boolean unchanged(ContentResolver r,Media m){
        try(Cursor c=r.query(m.uri(),COLUMNS,"is_trashed=0 AND is_pending=0",null,null)){
            return c!=null && c.moveToFirst() && media(m.uri(),c).equals(m);
        }
    }
    static List<Uri> recheck(ContentResolver r,List<Copy> selected) throws IOException {
        List<Uri> ok=new ArrayList<>();Map<Uri,String> verified=new HashMap<>();
        for(Copy pair:selected){
            interrupted();
            try{
                Media keep=pair.keep(),item=pair.item();
                if(item.favorite() || !unchanged(r,keep) || !unchanged(r,item))continue;
                String retained=verified.get(keep.uri());
                if(retained==null){retained=digest(r,keep);verified.put(keep.uri(),retained);}
                if(pair.hash().equals(retained) && retained.equals(digest(r,item)) && unchanged(r,keep) && unchanged(r,item))ok.add(item.uri());
            }catch(InterruptedIOException cancelled){throw cancelled;}
            catch(IOException|SecurityException unavailable){/* An unavailable file or keeper is skipped. */}
        }
        return ok;
    }
}
