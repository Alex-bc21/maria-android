package local.jarvis.search;

import android.app.*;
import android.app.job.*;
import android.content.*;
import android.os.*;
import android.widget.Toast;
import java.util.*;
import java.util.concurrent.*;

public final class Reminder extends JobService {
    static boolean schedule(Context c,String title,String note,long due,boolean object){
        return schedule(c,title,note,due,object,false);
    }
    static boolean schedule(Context c,String title,String note,long due,boolean object,boolean search){
        JobScheduler scheduler=c.getSystemService(JobScheduler.class);
        int id;do{id=1000+new Random().nextInt(1000000000);}while(scheduler.getPendingJob(id)!=null);
        return schedule(c,title,note,due,object,search,id);
    }
    static boolean schedule(Context c,String title,String note,long due,boolean object,boolean search,int id){
        JobScheduler scheduler=c.getSystemService(JobScheduler.class);
        PersistableBundle data=new PersistableBundle();data.putString("title",title);data.putString("note",note);
        data.putLong("due",due);data.putBoolean("object",object);data.putBoolean("search",search);
        long delay=due-System.currentTimeMillis();if(delay<=0&&id<1_100_000_000||!c.getSystemService(NotificationManager.class).areNotificationsEnabled())return false;
        delay=Math.max(0,delay);
        var channel=c.getSystemService(NotificationManager.class).getNotificationChannel("objects");
        if(channel!=null && channel.getImportance()==NotificationManager.IMPORTANCE_NONE)return false;
        JobInfo job=new JobInfo.Builder(id,new ComponentName(c,Reminder.class)).setPersisted(true)
                .setMinimumLatency(delay).setOverrideDeadline(delay+60000).setExtras(data).build();
        return scheduler.schedule(job)==JobScheduler.RESULT_SUCCESS;
    }
    static void list(SearchActivity a){list(a,null);}
    static void list(SearchActivity a,java.time.LocalDate date){
        JobScheduler jobs=a.getSystemService(JobScheduler.class);
        List<JobInfo> items=new ArrayList<>(jobs.getAllPendingJobs());
        items.removeIf(j->!j.getService().equals(new ComponentName(a,Reminder.class)));
        if(date!=null)items.removeIf(j->!java.time.Instant.ofEpochMilli(j.getExtras().getLong("due")).atZone(java.time.ZoneId.systemDefault()).toLocalDate().equals(date));
        items.sort(Comparator.comparingLong(j->j.getExtras().getLong("due")));
        if(items.isEmpty()){a.reply(date==null?"У Марии нет запланированных напоминаний.":"У Марии нет напоминаний на "+date+".");return;}
        String[] labels=items.stream().map(j->{long due=j.getExtras().getLong("due");
            return (due>0?java.text.DateFormat.getDateTimeInstance(3,3).format(new Date(due))+" · ":"")+(j.getExtras().getBoolean("search")?"Найти: ":"")+j.getExtras().getString("note");
        }).toArray(String[]::new);
        if(date!=null)a.reply("В напоминаниях Марии на "+date+": "+String.join("; ",labels)+".");
        new AlertDialog.Builder(a).setTitle("Напоминания Марии"+(date==null?"":" · "+date)).setItems(labels,(d,i)->new AlertDialog.Builder(a)
                .setMessage(labels[i]).setPositiveButton("Отменить задачу",(x,w)->{int id=items.get(i).getId();jobs.cancel(id);Promises.mark(a,id,Promises.CANCEL);})
                .setNegativeButton("Назад",(x,w)->list(a,date)).show()).setNegativeButton("Закрыть",null).show();
    }
    static void choose(SearchActivity a,String title,String note){
        Calendar day=Calendar.getInstance();day.add(Calendar.DATE,1);
        String lower=note.toLowerCase(Locale.ROOT);
        String[] days={"воскресен","понедель","вторник","сред","четвер","пятниц","суббот"};
        for(int i=0;i<days.length;i++)if(lower.contains(days[i])){
            while(day.get(Calendar.DAY_OF_WEEK)!=i+1)day.add(Calendar.DATE,1);break;
        }
        if(lower.contains("сегодня"))day.setTimeInMillis(System.currentTimeMillis());
        DatePickerDialog date=new DatePickerDialog(a,(v,y,m,d)->{
            day.set(y,m,d);
            new TimePickerDialog(a,(t,h,min)->{
                day.set(Calendar.HOUR_OF_DAY,h);day.set(Calendar.MINUTE,min);day.set(Calendar.SECOND,0);
                long delay=day.getTimeInMillis()-System.currentTimeMillis();
                if(delay<=0){Toast.makeText(a,"Выберите будущее время",Toast.LENGTH_LONG).show();return;}
                a.withNotifications(()->{
                    boolean ok=schedule(a,title,note,day.getTimeInMillis(),true);
                    Toast.makeText(a,ok?"Напоминание запланировано":"Не удалось запланировать",Toast.LENGTH_LONG).show();
                });
            },10,0,true).show();
        },day.get(Calendar.YEAR),day.get(Calendar.MONTH),day.get(Calendar.DAY_OF_MONTH));date.show();
    }
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Map<Integer,Future<?>> running=new HashMap<>();
    private final Handler main=new Handler(Looper.getMainLooper());
    public boolean onStartJob(JobParameters p){
        if(!p.getExtras().getBoolean("search")){
            synchronized(Promises.class){
                if(p.getJobId()>=1_100_000_000){
                    var item=Promises.get(this,p.getJobId());
                    if(item==null||!Promises.active(item)||item.due()!=p.getExtras().getLong("due")||
                            item.state().equals(Promises.SENT))return false;
                }
                boolean posted=notifyResult(p,p.getExtras().getString("note"));
                if(p.getJobId()>=1_100_000_000)Promises.mark(this,p.getJobId(),posted?Promises.SENT:Promises.MISSED);
            }
            return false;
        }
        String query=p.getExtras().getString("note");
        running.put(p.getJobId(),worker.submit(()->{
            String report;
            try{
                boolean gallery=checkSelfPermission(Build.VERSION.SDK_INT>=33?android.Manifest.permission.READ_MEDIA_IMAGES:android.Manifest.permission.READ_EXTERNAL_STORAGE)==android.content.pm.PackageManager.PERMISSION_GRANTED
                        ||Build.VERSION.SDK_INT>=34&&checkSelfPermission(android.Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)==android.content.pm.PackageManager.PERMISSION_GRANTED;
                var result=new PhoneSearch(this,query,null,null,null).run(gallery);
                report="Найдено: "+result.count()+(result.hits().isEmpty()?"":" · "+result.hits().get(0).name());
                if(!result.notice().isEmpty())report+=". "+result.notice();
                if(result.skipped()>0)report+=". Недоступно источников: "+result.skipped();
            }catch(InterruptedException stop){Thread.currentThread().interrupt();return;}
            catch(Exception failed){report="Не удалось закончить поиск. Откройте Марию и проверьте доступ к файлам.";}
            String message=report;
            main.post(()->{if(running.remove(p.getJobId())!=null){notifyResult(p,message);jobFinished(p,false);}});
        }));
        return true;
    }
    private boolean notifyResult(JobParameters p,String note){
        NotificationManager n=getSystemService(NotificationManager.class);
        n.createNotificationChannel(new NotificationChannel("objects","Напоминания об объектах",NotificationManager.IMPORTANCE_DEFAULT));
        if(!n.areNotificationsEnabled()||n.getNotificationChannel("objects").getImportance()==NotificationManager.IMPORTANCE_NONE)return false;
        String title=p.getExtras().getString("title");
        Intent open=new Intent(this,SearchActivity.class);
        if(p.getExtras().getBoolean("search"))open.setAction("local.jarvis.RESULTS").putExtra(SearchManager.QUERY,p.getExtras().getString("note"));
        else if(p.getExtras().getBoolean("object",true))open.setAction("local.jarvis.OBJECT").putExtra("object",title);
        else open.setAction("local.jarvis.REMINDERS");
        PendingIntent pi=PendingIntent.getActivity(this,p.getJobId(),open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        n.notify(p.getJobId(),new Notification.Builder(this,"objects").setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setVisibility(Notification.VISIBILITY_SECRET).setContentTitle(title).setContentText(note).setStyle(new Notification.BigTextStyle().bigText(note)).setContentIntent(pi).setAutoCancel(true).build());
        return true;
    }
    public boolean onStopJob(JobParameters p){Future<?> job=running.remove(p.getJobId());if(job!=null)job.cancel(true);return true;}
    @Override public void onDestroy(){running.clear();worker.shutdownNow();super.onDestroy();}
}
