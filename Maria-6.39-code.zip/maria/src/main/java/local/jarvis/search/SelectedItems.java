package local.jarvis.search;

import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Size;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import org.json.*;

final class SelectedItems {
    static final String PHOTOS="Google Фото", DRIVE="Google Диск";
    private static final String PREF="selected_media";
    static List<PhoneSearch.Hit> list(Context c) {
        List<PhoneSearch.Hit> out=new ArrayList<>();
        for(Object raw:c.getSharedPreferences(PREF,0).getAll().values()){
            try{
                JSONObject j=new JSONObject((String)raw);
                out.add(new PhoneSearch.Hit(j.getString("name"),j.getString("source"),j.getString("mime"),
                        Uri.parse(j.getString("uri")),j.getLong("date"),j.getString("stamp")));
            }catch(JSONException ignored){}
        }
        return out;
    }
    static String source(Context c,Uri uri) {
        android.content.pm.ProviderInfo provider=c.getPackageManager().resolveContentProvider(uri.getAuthority(),0);
        if("com.google.android.apps.docs.storage".equals(uri.getAuthority()) || provider!=null && "com.google.android.apps.docs".equals(provider.packageName)) return DRIVE;
        return "Выбранные файлы";
    }
    static PhoneSearch.Hit add(Context c,Uri uri,boolean photo) throws Exception {
        if(!"content".equals(uri.getScheme()))throw new IOException();
        ContentResolver resolver=c.getContentResolver();
        String mime=resolver.getType(uri),name=null;
        if(mime==null || photo && !mime.startsWith("image/"))throw new IOException();
        try(Cursor row=resolver.query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(row!=null && row.moveToFirst())name=row.getString(0);
        }
        if(name==null || name.isBlank())name=photo?"Фотография":"Документ";
        byte[] hash=MessageDigest.getInstance("SHA-256").digest(uri.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String id=android.util.Base64.encodeToString(hash,android.util.Base64.URL_SAFE|android.util.Base64.NO_WRAP|android.util.Base64.NO_PADDING);
        File dir=new File(c.getFilesDir(),"selected");
        if(!dir.isDirectory()&&!dir.mkdirs()&&!dir.isDirectory())throw new IOException();
        File tmp=File.createTempFile("import",".part",dir),target=new File(dir,id);
        long modified=0;
        try{
            try(InputStream in=resolver.openInputStream(uri);OutputStream out=new FileOutputStream(tmp)){
                if(in==null)throw new IOException();
                byte[] buf=new byte[65536];int n;
                while((n=in.read(buf))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();out.write(buf,0,n);}
            }
            if(photo)try(FileInputStream in=new FileInputStream(tmp)){
                android.media.ExifInterface exif=new android.media.ExifInterface(in);
                String d=exif.getAttribute(android.media.ExifInterface.TAG_DATETIME_ORIGINAL);
                if(d!=null)modified=new java.text.SimpleDateFormat("yyyy:MM:dd HH:mm:ss",Locale.US).parse(d).getTime();
            }catch(Exception ignored){}
            if(!tmp.renameTo(target))throw new IOException();
            JSONObject j=new JSONObject().put("name",name).put("source",photo?PHOTOS:source(c,uri)).put("mime",mime)
                .put("uri",Uri.fromFile(target)).put("date",modified).put("stamp",target.lastModified()+"/"+target.length());
            if(!c.getSharedPreferences(PREF,0).edit().putString(id,j.toString()).commit())throw new IOException();
            return new PhoneSearch.Hit(name,j.getString("source"),mime,Uri.fromFile(target),modified,j.getString("stamp"));
        }finally{tmp.delete();}
    }
    static Bitmap thumbnail(Context c,Uri uri,int size) throws IOException {
        ImageDecoder.Source original;
        if("file".equals(uri.getScheme()))original=ImageDecoder.createSource(new File(uri.getPath()));
        else{
            try{return c.getContentResolver().loadThumbnail(uri,new Size(size,size),null);}
            catch(IOException unavailable){original=ImageDecoder.createSource(c.getContentResolver(),uri);}
        }
        return ImageDecoder.decodeBitmap(original,(decoder,info,src)->{
            Size s=info.getSize();double scale=Math.min(1,(double)size/Math.max(s.getWidth(),s.getHeight()));
            decoder.setTargetSize(Math.max(1,(int)(s.getWidth()*scale)),Math.max(1,(int)(s.getHeight()*scale)));
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
        });
    }
}
