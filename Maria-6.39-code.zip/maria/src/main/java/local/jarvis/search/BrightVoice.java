package local.jarvis.search;

import android.content.Context;
import android.util.Base64;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONObject;

/** The selected Coral performance: bright Russian soprano with a voiced center around 308 Hz. */
final class BrightVoice {
    static final int RATE=24000;
    static final String PREFERENCE="bright_read_aloud";
    private volatile HttpsURLConnection active;

    void cancel(){
        HttpsURLConnection request=active;
        if(request!=null)new Thread(request::disconnect,"jarvis-voice-cancel").start();
    }
    interface Current { boolean valid(); }
    short[] request(String text,String sealed,CoralDelivery delivery,Current turn) throws Exception {
        String key=DeviceCredential.open(Base64.decode(sealed,Base64.NO_WRAP));
        HttpsURLConnection conn=(HttpsURLConnection)new URL("https://api.openai.com/v1/audio/speech").openConnection();
        active=conn;
        try{
            if(!turn.valid())throw new InterruptedIOException();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(4500);conn.setReadTimeout(18000);
            conn.setRequestMethod("POST");conn.setDoOutput(true);
            conn.setRequestProperty("Authorization","Bearer "+key);
            conn.setRequestProperty("Content-Type","application/json");
            byte[] body=new JSONObject().put("model","gpt-4o-mini-tts").put("voice","coral").put("instructions",delivery.instructions())
                .put("response_format","pcm").put("input",text).toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(body.length);
            try(OutputStream out=conn.getOutputStream()){out.write(body);}
            if(conn.getResponseCode()!=200)throw new IOException("Voice service HTTP "+conn.getResponseCode());
            return readPcm(conn.getInputStream());
        }finally{active=null;conn.disconnect();}
    }
    static short[] readPcm(InputStream stream) throws IOException {
        try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buffer=new byte[8192];int n;
            while((n=in.read(buffer))!=-1){
                if(out.size()+n>6000000)throw new IOException("Voice duration limit");
                out.write(buffer,0,n);
            }
            byte[] bytes=out.toByteArray();
            if(bytes.length<2 || (bytes.length&1)!=0)throw new IOException("Invalid PCM");
            short[] pcm=new short[bytes.length/2];
            for(int i=0;i<pcm.length;i++)pcm[i]=(short)((bytes[2*i]&255)|(bytes[2*i+1]<<8));
            return pcm;
        }
    }
    // Estimate the median fundamental from voiced frames for a pitch correction that preserves speaking rate.
    static float pitch(short[] pcm){
        int frames=Math.min(pcm.length,8*RATE)/960;
        float[] voiced=new float[frames];
        double[] difference=new double[113];
        int count=0;
        for(int f=0;f<frames;f++){
            int start=f*960;
            double energy=0;
            for(int j=0;j<240;j++){int value=pcm[start+j*2];energy+=(double)value*value;}
            if(energy<240*400.0*400)continue;
            double total=0;
            for(int lag=1;lag<difference.length;lag++){
                double sum=0;
                for(int j=0;j<240;j++){int delta=pcm[start+j*2]-pcm[start+2*(j+lag)];sum+=(double)delta*delta;}
                total+=sum;difference[lag]=total>0?sum*lag/total:1;
            }
            for(int lag=20;lag<difference.length-1;lag++){
                if(difference[lag]<.14 && difference[lag]<=difference[lag-1] && difference[lag]<difference[lag+1]){
                    voiced[count++]=12000f/lag;break;
                }
            }
        }
        if(count<3)return 1f;
        Arrays.sort(voiced,0,count);
        float center=voiced[count/2];
        // Keep the natural register when it is already high. Large shifts make articulation brittle.
        if(center>=280f && center<=330f)return 1f;
        float edge=center<280f?280f:330f;
        return Math.max(.94f,Math.min(1.18f,edge/center));
    }
}
