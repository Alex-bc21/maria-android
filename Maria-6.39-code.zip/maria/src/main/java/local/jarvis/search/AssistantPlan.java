package local.jarvis.search;

import java.util.Locale;
import org.json.*;

/** Only typed operations cross the boundary from language understanding to Android. */
record AssistantPlan(Tool tool,String argument) {
    enum Tool { BATTERY, STORAGE, RAM, SCREEN, SCREEN_NUMBER, SCREEN_ROUTE, DOCUMENT, PHOTO, VIDEO, FILE, FILE_TEXT, APP, MAP, RESULT, DRAFT, REMINDERS, REMIND, ALARM, LAST_ACTION, GOOGLE_ADD, GOOGLE_LIST, READ_SCREEN, NAVIGATE, TIMER, HISTORY, CLEANUP, CHAT, CLARIFY }
    static final String INSTRUCTIONS="""
        Classify the Russian user's intent for a phone assistant. Output exactly one line TOOL|argument. Never perform or explain an action.
        BATTERY = phone battery level; STORAGE = free disk space; RAM = free RAM. SCREEN = interpret, read or explain what is currently displayed, or give advice about something visible. DOCUMENT = question about an already opened document.
        PHOTO, VIDEO, FILE = locate personal media or a file; argument = search topic in Russian. APP = launch installed app, argument = original name or purpose. MAP = directions to a named place, argument = exact place from request. RESULT = open numbered result, argument = number starting at 1.
        CHAT = general knowledge, conversation, hypothetical question. CLARIFY = missing necessary details, unsupported action, or multiple different operations. Do not invent values. Use empty argument for tools without parameters.
        NAVIGATE = directly operate current screen, argument direction|visible label, direction down/up/empty. Only an explicitly requested action, never a discussion.
        Examples: «Телефон скоро сядет?» -> BATTERY| ; «Есть куда сохранить большой фильм?» -> STORAGE| ; «О чём эта открытая страница?» -> SCREEN| ; «Как устроен аккумулятор?» -> CHAT| ; «Хочу посмотреть кадры с лошадьми из моей галереи» -> PHOTO|лошади ; «Сотри все сообщения» -> CLARIFY|
        """;
    static AssistantPlan online(String request,String available,String sealedKey,boolean document,int results) throws Exception {
        JSONArray tools=new JSONArray();
        for(Tool t:Tool.values()){
            if(t==Tool.DOCUMENT && !document || t==Tool.RESULT && results==0)continue;
            tools.put(t.name());
        }
        JSONObject properties=new JSONObject().put("tool",new JSONObject().put("type","string").put("enum",tools))
                .put("argument",new JSONObject().put("type","string"));
        JSONObject schema=new JSONObject().put("type","object").put("properties",properties).put("additionalProperties",false)
                .put("required",new JSONArray().put("tool").put("argument"));
        JSONObject format=new JSONObject().put("type","json_schema").put("name","phone_action").put("schema",schema).put("strict",true);
        JSONObject data=new JSONObject().put("request",request).put("available_context",available).put("local_date",java.time.LocalDate.now().toString());
        String instructions="Выбери инструмент для русскоязычного помощника на Android по смыслу запроса. "
                +"BATTERY, STORAGE, RAM — фактические показатели телефона, без аргумента. SCREEN — вопрос о содержимом текущего экрана, выборе кнопки или изображении. "
                +"SCREEN_NUMBER — скопировать видимый номер. SCREEN_ROUTE — маршрут к видимому адресу. DOCUMENT — вопрос по открытому PDF. "
                +"PHOTO и VIDEO — личные фото и видео по сюжету, аргумент описывает искомое на русском. FILE — поиск по названию; FILE_TEXT — поиск по тексту внутри файла. Сохрани детали поиска. "
                +"APP — открыть приложение, MAP — открыть маршрут до места. Для них верни дословное название или назначение из запроса. RESULT — открыть номер из текущей выдачи, аргумент целое число от 1. "
                +"DRAFT — подготовить выбранный файл в мессенджере, argument = имя адресата дословно из запроса, затем « в » и WhatsApp, Telegram, Viber или Plus. Если имя или мессенджер неизвестны, CLARIFY: сначала уточни недостающего получателя или мессенджер. Сам файл при необходимости даст выбрать Android. "
                +"ALARM — разбудить, системный будильник в Часах: argument «завтра в HH:mm» или «в HH:mm». LAST_ACTION — вопрос об уже сделанном, argument alarm, google или remind. GOOGLE_ADD — создать именно Google Задачу, argument «завтра в HH:mm ; название»; GOOGLE_LIST — список Google Задач, argument today или tomorrow. READ_SCREEN — прочитать текст вслух, argument start или continue. REMINDERS — список напоминаний; REMIND — поставить задачу или напоминание в Google Календарь по умолчанию. GOOGLE_ADD только при прямом указании сервиса Google Tasks / Google Задачи. Для REMIND верни argument в формате «через N минут задача» или «завтра в HH:mm задача» или «yyyy-MM-dd в HH:mm задача» для конкретной даты, только с явно указанными временем и задачей. TIMER — установить таймер, argument целое число секунд от 1 до 86400, только при названной длительности. "
                +"NAVIGATE — пользователь хочет взаимодействовать с уже открытым экраном. В argument ровно два поля через вертикальную черту: down или up или пусто, затем дословная подпись кнопки из слов пользователя или пусто. Это одна прокрутка, одно нажатие либо прокрутка и затем нажатие. Например «покажи, что там ниже по странице» → down|, «хочу заглянуть во вкладку Отзывы» → |Отзывы. Если непонятно где нажать или действие выходит за эти возможности, CLARIFY. Вопрос как что-то сделать — не разрешение нажимать. Чтение поста — READ_SCREEN, передача файла — DRAFT. "
                +"HISTORY — журнал Марии; CLEANUP — только посмотреть отчёт о дубликатах и мусоре. "
                +"CHAT — общий вопрос: дай краткий ответ в argument по-русски. Ты не имеешь текущих данных без инструмента. Не обещай действия. "
                +"CLARIFY — при неопределённости или отсутствии инструмента задай конкретный короткий вопрос либо объясни ограничение в argument. "
                +"Нет инструмента, собирающего остатки и долги сразу по банковским приложениям: объясни это, предложи выбрать выписку; SCREEN только для одного открытого экрана. Для вопроса о подтверждении действия выбирай LAST_ACTION. Не выбирай действие, которое пользователь отрицает или только обсуждает. Не придумывай аргументы или успешное выполнение. Учитывай уточнение, но при смене темы исполняй новый запрос.";
        JSONObject body=new JSONObject().put("model","gpt-4.1-mini").put("store",false).put("max_output_tokens",400)
                .put("instructions",instructions).put("input",data.toString()).put("text",new JSONObject().put("format",format));
        JSONObject chosen=new JSONObject(OpenAIResponses.text(body,sealedKey));
        Tool tool=Tool.valueOf(chosen.getString("tool"));String arg=chosen.getString("argument").strip();
        if(arg.length()>(tool==Tool.CHAT?1500:260) || arg.matches("(?s).*[\\p{Cc}&&[^\\n\\t]].*"))return clarify();
        return new AssistantPlan(tool,arg);
    }

    static AssistantPlan parse(String line){
        if(line==null)return clarify();
        String[] fields=line.strip().split("\\|",-1);
        if(fields.length!=2 || fields[1].length()>200 || line.strip().contains("\n"))return clarify();
        try{
            var tool=Tool.valueOf(fields[0].strip().toUpperCase(Locale.ROOT));
            String arg=fields[1].strip();
            if(arg.matches(".*[\\p{Cc}<>].*"))return clarify();
            return new AssistantPlan(tool,arg);
        }catch(IllegalArgumentException unknown){return clarify();}
    }
    static AssistantPlan clarify(){return new AssistantPlan(Tool.CLARIFY,"");}
}
