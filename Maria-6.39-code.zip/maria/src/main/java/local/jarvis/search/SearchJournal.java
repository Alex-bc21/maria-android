package local.jarvis.search;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

final class SearchJournal extends SQLiteOpenHelper {
    private static SearchJournal instance;
    static synchronized SearchJournal get(Context context){
        if(instance==null)instance=new SearchJournal(context.getApplicationContext());
        return instance;
    }
    private final Context context;
    private SearchJournal(Context context){super(context,"search-journal.db",null,1);this.context=context;}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, turn INTEGER NOT NULL, at INTEGER NOT NULL, kind TEXT NOT NULL, detail TEXT NOT NULL)");
        db.execSQL("CREATE INDEX by_turn ON events(turn,id)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){}
    private boolean enabled(){return context.getSharedPreferences("settings",0).getBoolean("journal",true);}
    private ContentValues values(String kind,String detail){
        ContentValues v=new ContentValues();v.put("at",System.currentTimeMillis());v.put("kind",kind);
        v.put("detail",detail);return v;
    }
    synchronized long begin(String kind,String query){
        if(!enabled()||query.isBlank())return 0;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            ContentValues v=values(kind,query);v.put("turn",0);
            long id=db.insertOrThrow("events",null,v);
            db.execSQL("UPDATE events SET turn=id WHERE id=?",new Object[]{id});
            db.execSQL("DELETE FROM events WHERE turn <= (SELECT id FROM events WHERE turn=id ORDER BY id DESC LIMIT 1 OFFSET 500)");
            db.setTransactionSuccessful();return id;
        }finally{db.endTransaction();}
    }
    synchronized void recognized(long turn,String text){
        if(enabled())getWritableDatabase().execSQL("UPDATE events SET kind=?,detail=? WHERE id=? AND turn=id",new Object[]{"Голос",text,turn});
    }
    synchronized void add(long turn,String kind,String detail){
        if(turn==0 || !enabled() || detail.isBlank())return;
        getWritableDatabase().execSQL("INSERT INTO events(turn,at,kind,detail) SELECT ?,?,?,? WHERE EXISTS(SELECT 1 FROM events WHERE id=?)",
            new Object[]{turn,System.currentTimeMillis(),kind,detail,turn});
    }
    Cursor read(long after){
        return getReadableDatabase().rawQuery("SELECT id, turn, datetime(at/1000,'unixepoch','localtime') AS time, kind, detail FROM events WHERE id>? ORDER BY id",new String[]{Long.toString(after)});
    }
    static boolean requested(String text){
        String q=text.toLowerCase(java.util.Locale.ROOT).strip().replaceAll("[,.!?]+"," ").strip().replaceAll("\\s+"," ");
        return q.matches("(?:(?:джарвис|а|ну|пожалуйста) )*(?:(?:открой|покажи|показать|открыть|где|где найти|где посмотреть|как посмотреть|ты ведешь|ты ведёшь|есть ли) )?(?:(?:мне|мои|твои|твой|мой|у тебя|наш|наши|наша) )*(?:лог[и]?|логи приложения|журнал(?: запросов| поиска)?|истори[юя](?: запросов| поиска| команд))");
    }
    String lastSources(){
        java.util.LinkedHashSet<String> lines=new java.util.LinkedHashSet<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT kind,detail FROM events WHERE turn=(SELECT MAX(turn) FROM events WHERE kind IN ('Источник','Google Фото')) AND kind IN ('Источник','Google Фото') ORDER BY id",null)){
            while(c.moveToNext()){
                String detail=c.getString(1);
                if(c.getString(0).equals("Google Фото"))lines.add("Google Фото · "+detail);
                else if(!detail.endsWith(" · поиск продолжается"))lines.add(detail.replace(" · начат поиск",""));
            }
        }
        return lines.isEmpty()?"В истории пока нет сведений об источниках поиска.":"Последний поиск, по журналу:\n"+String.join("\n",lines);
    }
    void show(Activity activity){
        ArrayList<String> rows=new ArrayList<>();ArrayList<Long> ids=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,strftime('%d.%m %H:%M',at/1000,'unixepoch','localtime'),detail FROM events WHERE id=turn ORDER BY id DESC",null)){
            while(c.moveToNext()){ids.add(c.getLong(0));rows.add(c.getString(1)+"  "+c.getString(2));}
        }
        AlertDialog.Builder panel=new AlertDialog.Builder(activity).setTitle("История запросов");
        if(rows.isEmpty())panel.setMessage("Здесь появятся команды, ответы и ход поиска.");
        else panel.setItems(rows.toArray(new String[0]),(d,i)->{
            StringBuilder body=new StringBuilder();
            boolean search=false,finished=false;
            try(Cursor c=getReadableDatabase().rawQuery("SELECT strftime('%H:%M:%S',at/1000,'unixepoch','localtime'),kind,detail FROM events WHERE turn=? ORDER BY id",new String[]{ids.get(i).toString()})){
                while(c.moveToNext()){
                    String kind=c.getString(1), detail=c.getString(2);
                    if(kind.equals("Маршрут") && (detail.startsWith("Поиск ") || detail.startsWith("Имя, папка и дата")))search=true;
                    if(kind.equals("Результат") || kind.equals("Ошибка поиска") || kind.equals("Статус") && detail.equals("Поиск прерван"))finished=true;
                    body.append(c.getString(0)).append(" · ").append(kind).append("\n").append(detail).append("\n\n");
                }
            }
            if(search && !finished)body.append("Итог локального поиска пока не записан.");
            new AlertDialog.Builder(activity).setTitle("Ход запроса").setMessage(body.toString().trim()).setPositiveButton("Закрыть",null).show();
        });
        panel.setPositiveButton("Закрыть",null).setNeutralButton(enabled()?"Приостановить запись":"Включить запись",(d,w)->
            context.getSharedPreferences("settings",0).edit().putBoolean("journal",!enabled()).apply());
        if(!rows.isEmpty())panel.setNegativeButton("Очистить",(d,w)->new AlertDialog.Builder(activity).setMessage("Удалить историю запросов с телефона?")
            .setPositiveButton("Удалить",(x,y)->getWritableDatabase().delete("events",null,null)).setNegativeButton("Отмена",null).show());
        panel.show();
    }
}