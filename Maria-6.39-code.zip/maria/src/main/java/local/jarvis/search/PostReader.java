package local.jarvis.search;


import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;
import java.util.regex.Pattern;

/** One user-requested read of the foreground publication. The cursor lives only in memory. */
final class PostReader {
    private static final Pattern END=Pattern.compile("(?iu)^(?:все комментарии|комментарии|коментарі|comments|следующая публикация|следующий пост|следующая статья|следующая новость|читайте также|похожие (?:статьи|публикации)|рекомендованные публикации|related articles|next (?:post|article)|read next|залишити коментар)(?:\\s*[(·:]?\\s*\\d+\\)?)?$");
    private static final Pattern MORE=Pattern.compile("(?iu)^(?:показать (?:полностью|весь текст)|развернуть (?:текст|описание)|читать полностью|показати повністю|see more|show more|ещ[её])$");
    final long turn;
    final String pkg;
    final StringBuilder body=new StringBuilder();
    int pages,scrolls;
    private int window=-1, listRow=-1, unchanged;
    private String previous="",scrollClass="",scrollId="";
    private boolean expanded,hadCollection;
    String notice="";
    PostReader(String pkg,long turn){this.pkg=pkg;this.turn=turn;}
    static List<AccessibilityNodeInfo> visible(AccessibilityNodeInfo root){
        var out=new ArrayList<AccessibilityNodeInfo>();
        var stack=new ArrayDeque<AccessibilityNodeInfo>();stack.push(root);
        while(!stack.isEmpty()&&out.size()<2200){
            var n=stack.pop();
            if(n.isPassword()||n.isEditable()||!n.isVisibleToUser())continue;
            out.add(n);
            for(int i=n.getChildCount()-1;i>=0;i--){var c=n.getChild(i);if(c!=null)stack.push(c);}
        }
        return out;
    }
    private static String label(AccessibilityNodeInfo n){
        String t=Objects.toString(n.getText(),"").strip();
        if(t.isEmpty() && n.getChildCount()==0)t=Objects.toString(n.getContentDescription(),"").strip();
        return t.replace('\u00a0',' ');
    }
    private static boolean prose(String t){return t.length()>=18 && t.matches("(?s).*\\p{L}{2}.*\\s.*");}
    private static boolean control(AccessibilityNodeInfo n){
        String c=Objects.toString(n.getClassName(),"");
        return c.endsWith("Button") || c.endsWith("EditText") || c.endsWith("CheckBox") || c.endsWith("Switch");
    }
    private static AccessibilityNodeInfo scroller(AccessibilityNodeInfo n){
        for(;n!=null;n=n.getParent())if(n.isScrollable()&&!String.valueOf(n.getClassName()).contains("Horizontal"))return n;
        return null;
    }
    private static AccessibilityNodeInfo item(AccessibilityNodeInfo n,AccessibilityNodeInfo limit){
        for(;n!=null&&!n.equals(limit);n=n.getParent()){
            if(n.getCollectionItemInfo()!=null)return n;
            var parent=n.getParent();
            if(parent!=null && parent.equals(limit) && String.valueOf(parent.getClassName()).matches(".*(?:RecyclerView|ListView|ViewPager2?)"))return n;
        }
        return null;
    }
    private boolean stop(String why){notice=why;return true;}
    boolean step(AccessibilityNodeInfo root){
        if(window!=-1 && window!=root.getWindowId())return stop("Окно с публикацией изменилось.");
        window=root.getWindowId();
        var all=visible(root);
        AccessibilityNodeInfo anchor=null;
        for(var n:all){
            if(control(n)||!prose(label(n)))continue;
            if(anchor==null)anchor=n;
            if(scroller(n)!=null){anchor=n;break;}
        }
        if(anchor==null){
            for(var n:all)if(!control(n)&&!n.isClickable()&&label(n).matches("(?s).*\\p{L}{2}.*")&&scroller(n)!=null){anchor=n;break;}
        }
        if(anchor==null)return stop("Приложение не открыло текст для чтения с прокруткой.");
        var scroll=scroller(anchor);
        var scope=scroll==null?root:scroll;
        var row=item(anchor,scroll);
        if(row!=null){
            int index=row.getCollectionItemInfo()==null?-1:row.getCollectionItemInfo().getRowIndex();
            if(pages>0 && (!hadCollection || index!=listRow))return stop("");
            hadCollection=true;listRow=index;scope=row;
        }else if(hadCollection)return stop("");
        String cls=scroll==null?"":String.valueOf(scroll.getClassName()),id=scroll==null?"":Objects.toString(scroll.getViewIdResourceName(),"");
        if(pages>0 && (!cls.equals(scrollClass)||!id.equals(scrollId)))return stop("Область чтения на экране изменилась.");
        scrollClass=cls;scrollId=id;
        var lines=new ArrayList<String>();boolean end=false,collapsed=false;AccessibilityNodeInfo expand=null;
        for(var n:visible(scope)){
            String t=label(n);if(t.isBlank())continue;
            if(END.matcher(t).matches()){end=true;break;}
            if(MORE.matcher(t).matches()){
                collapsed=true;
                if(!expanded && !lines.isEmpty() && (row!=null || t.contains("полностью") || t.contains("текст")) && n.isClickable())expand=n;
                continue;
            }
            if(t.matches("(?isu).*(?:…|\\.{3})\\s*(?:ещ[её]|ще|more)\\s*$")){
                collapsed=true;
                if(!expanded && n.isClickable() && Objects.toString(n.getViewIdResourceName(),"").matches("(?i).*(?:caption|description|post_text).*"))expand=n;
            }
            if(control(n)||n.isClickable()&&!prose(t)&&!n.isHeading())continue;
            for(String line:t.split("\\R")){
                String clean=line.strip().replaceAll("\\s+"," ");
                if(END.matcher(clean).matches()){end=true;break;}
                if(!clean.isEmpty() && clean.matches("(?s).*\\p{L}.*"))lines.add(clean);
            }
            if(end)break;
        }
        if(expand!=null && expand.performAction(AccessibilityNodeInfo.ACTION_CLICK)){expanded=true;return false;}
        String page=String.join("\n",lines);
        if(page.equals(previous) && !previous.isEmpty()){
            if(++unchanged<3 && !end)return false;
            return stop(end?"":"Дальше приложение не открыло нового текста.");
        }
        if(page.isEmpty())return stop(end?"":"Не удалось прочитать следующую часть экрана.");
        if(hadCollection && pages>0 && listRow<0 && overlap(previous,page)==0)return stop("Границу следующей записи определить не удалось.");
        unchanged=0;int skip=overlap(previous,page);
        String extra=page.substring(skip).strip();
        if(!extra.isEmpty()){if(body.length()>0)body.append('\n');body.append(extra);}
        previous=page;pages++;
        if(collapsed)return stop("Приложение показывает сокращённую версию. Разверните полный текст и снова вызовите Марию.");
        if(end||scroll==null)return true;
        if(body.length()>=100000||pages>=120)return stop("Достигнут предел одного чтения.");
        if(!scroll.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD))return true;
        scrolls++;return false;
    }
    static int overlap(String old,String page){
        if(old.isEmpty())return 0;
        for(int i=Math.min(old.length(),page.length());i>0;i--){
            int start=old.length()-i;
            if(start>0 && !Character.isWhitespace(old.charAt(start-1)))continue;
            if(i<page.length() && !Character.isWhitespace(page.charAt(i)))continue;
            if(old.regionMatches(start,page,0,i))return i;
        }
        return 0;
    }
    static String beforeComments(String raw){
        var lines=new ArrayList<String>();
        for(String line:raw.split("\\R")){
            if(END.matcher(line.strip()).matches())break;
            if(!line.isBlank())lines.add(line.strip());
        }
        return String.join("\n",lines);
    }
}

