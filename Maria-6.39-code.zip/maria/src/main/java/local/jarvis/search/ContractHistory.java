package local.jarvis.search;

import android.content.Context;
import android.net.Uri;
import org.json.*;
import java.util.*;

/** One locally saved answer, including its source document and verified quotes. */
final class ContractHistory {
    record Saved(PhoneSearch.Hit document,String question,String answer,List<PhoneSearch.Hit> quotes) {}
    static void save(Context context,PhoneSearch.Hit document,String question,CloudContract.Answer answer){
        try{
            JSONArray quotes=new JSONArray();
            for(var hit:answer.quotes())quotes.put(new JSONObject().put("page",hit.page()).put("text",hit.reason()));
            JSONObject record=new JSONObject().put("name",document.name()).put("uri",document.uri().toString())
                .put("original",document.original().toString()).put("stamp",document.stamp())
                .put("question",question).put("answer",answer.text()).put("quotes",quotes);
            context.getSharedPreferences("contract_history",0).edit().putString("last",record.toString()).apply();
        }catch(JSONException error){throw new IllegalStateException(error);}
    }
    static Saved load(Context context){
        try{
            JSONObject record=new JSONObject(context.getSharedPreferences("contract_history",0).getString("last",""));
            var document=new PhoneSearch.Hit(record.getString("name"),"","application/pdf",Uri.parse(record.getString("uri")),
                0,record.getString("stamp"),0,-1,"",Uri.parse(record.getString("original")));
            JSONArray quotes=record.getJSONArray("quotes");List<PhoneSearch.Hit> hits=new ArrayList<>();
            for(int i=0;i<quotes.length();i++){
                JSONObject quote=quotes.getJSONObject(i);hits.add(document.matched(1,quote.getInt("page"),quote.getString("text")));
            }
            return new Saved(document,record.getString("question"),record.getString("answer"),hits);
        }catch(JSONException error){return null;}
    }
}
