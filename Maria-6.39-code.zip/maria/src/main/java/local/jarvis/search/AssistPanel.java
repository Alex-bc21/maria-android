package local.jarvis.search;

import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.*;
import android.widget.*;

/** A private, floating activity dedicated to the system assistant invocation. */
public final class AssistPanel extends SearchActivity {
    private boolean expanded;
    private TextView contextChip;
    private ImageView resize;
    private Studio style;

    @Override protected void onRestoreInstanceState(android.os.Bundle state){
        super.onRestoreInstanceState(state);
        size(state.getBoolean("panelExpanded"));
    }
    @Override public void onSaveInstanceState(android.os.Bundle state){
        state.putBoolean("panelExpanded",expanded);
        super.onSaveInstanceState(state);
    }

    void decorate(Studio ui,LinearLayout page,LinearLayout header,Runnable actions){
        style=ui;
        Window window=getWindow();
        window.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        window.setDimAmount(.20f);
        setFinishOnTouchOutside(true);
        page.setPadding(ui.dp(14),ui.dp(7),ui.dp(14),ui.dp(14));
        GradientDrawable card=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff272234,0xff141b29,0xff101720});
        card.setCornerRadius(ui.dp(26));card.setStroke(ui.dp(1),0xff57536b);page.setBackground(card);page.setClipToOutline(true);
        resize=ui.iconButton("up","Развернуть панель",Studio.LILAC,()->size(!expanded));
        header.addView(resize,ui.lp(44,44));
        header.addView(ui.iconButton("close","Закрыть панель",Studio.MUTED,this::finish),ui.lp(44,44));
        FrameLayout grip=new FrameLayout(this);page.addView(grip,0,ui.lp(-1,16));
        View line=new View(this);line.setBackground(ui.shape(0xff827b95,2,0));
        grip.addView(line,new FrameLayout.LayoutParams(ui.dp(36),ui.dp(4),Gravity.CENTER));
        grip.setOnTouchListener(new View.OnTouchListener(){
            float start;
            public boolean onTouch(View v,android.view.MotionEvent e){
                if(e.getActionMasked()==MotionEvent.ACTION_DOWN){start=e.getRawY();return true;}
                if(e.getActionMasked()==MotionEvent.ACTION_UP){
                    float delta=e.getRawY()-start;
                    if(delta < -ui.dp(28))size(true);
                    else if(delta>ui.dp(28)){if(expanded)size(false);else finish();}
                    else v.performClick();
                }
                return true;
            }
        });
        contextChip=ui.text("Действия с экраном",14,Studio.MINT,true);
        contextChip.setGravity(Gravity.CENTER_VERTICAL);contextChip.setSingleLine(true);
        contextChip.setEllipsize(android.text.TextUtils.TruncateAt.END);contextChip.setPadding(ui.dp(12),0,ui.dp(12),0);
        contextChip.setBackground(ui.surface(0xff243338,16,0xff394e50));
        LinearLayout.LayoutParams chip=ui.lp(-2,40);chip.bottomMargin=ui.dp(6);
        page.addView(contextChip,page.getChildCount()-1,chip);
        ui.action(contextChip,"Действия с экраном",actions);
        size(false);
    }
    void source(String fileName){
        if(contextChip!=null)contextChip.setText(fileName==null?"Действия с экраном":"Файл · "+fileName);
    }
    void size(boolean large){
        if(style==null)return;
        expanded=large;Window w=getWindow();
        int width,height;
        if(Build.VERSION.SDK_INT>=30){
            var metrics=getWindowManager().getCurrentWindowMetrics();
            var bars=metrics.getWindowInsets().getInsetsIgnoringVisibility(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
            width=metrics.getBounds().width()-bars.left-bars.right;height=metrics.getBounds().height()-bars.top-bars.bottom;
        }else{
            var metrics=getResources().getDisplayMetrics();width=metrics.widthPixels;height=metrics.heightPixels;
        }
        WindowManager.LayoutParams lp=w.getAttributes();
        lp.width=Math.min(style.dp(640),width-style.dp(16));lp.y=style.dp(6);
        int compactHeight=Math.round(274*Math.max(1f,getResources().getConfiguration().fontScale));
        lp.height=Math.max(1,large?height-style.dp(16):Math.min(style.dp(compactHeight),height-style.dp(16)));
        w.setAttributes(lp);
        resize.setRotation(large?180:0);resize.setContentDescription(large?"Свернуть панель":"Развернуть панель");
    }
}
