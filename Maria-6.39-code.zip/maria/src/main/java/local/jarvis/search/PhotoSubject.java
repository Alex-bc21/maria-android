package local.jarvis.search;

import java.util.regex.Pattern;

final class PhotoSubject {
    private static final Pattern HORSE=Pattern.compile("(?iu)(?<![\\p{L}\\p{N}])(?:конь|кони|коней|конях|конями|коня|коню|коне|конем|кон[её]м|коням|лошад(?:ь|и|ей|ям|ях|ью|ьми|ями)|лошадк(?:а|и|у|ой|ами|ах))(?![\\p{L}\\p{N}])");
    static String clean(String text){
        return text.strip().replaceFirst("(?iu)^(?:(?:у меня|где|на которых|с изображением) +)+","")
                .replaceFirst("(?iu) +у меня$","").strip();
    }
    static String google(String text){
        String q=clean(text);
        return onlyHorse(q)?"лошади":q;
    }
    static boolean onlyHorse(String text){
        return HORSE.matcher(clean(text).replaceFirst("(?iu)^с +","")).matches();
    }
    static String english(android.content.Context c,String text,long token)throws java.io.IOException{
        if(onlyHorse(text))return "horses";
        String result=LocalAnswer.englishDescription(c,clean(text),token);
        if(HORSE.matcher(text).find() && !Pattern.compile("(?i)(?<![\\p{L}\\p{N}])(?:horses?|pon(?:y|ies)|mares?|stallions?|foals?|equestrian)(?![\\p{L}\\p{N}])").matcher(result).find()){
            String rest=HORSE.matcher(clean(text)).replaceFirst(" ").strip();
            return rest.isEmpty()?"horses":"horses, "+LocalAnswer.englishDescription(c,rest,token);
        }
        return result;
    }
}
