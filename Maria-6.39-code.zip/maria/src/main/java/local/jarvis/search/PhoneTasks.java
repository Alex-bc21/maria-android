package local.jarvis.search;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.provider.AlarmClock;
import android.provider.Settings;
import java.time.*;
import java.util.*;
import java.util.regex.*;

final class PhoneTasks {
    private static final Pattern OPEN=Pattern.compile("^(?:открой|запусти) (?:приложение )?(.+?)(?:(?:,? и |, )(найди|поищи|нажми)(?: (?:там|кнопку))? (.+?)(?:,? и нажми (?:кнопку )?(.+))?)?$");
    private static final Pattern AFTER=Pattern.compile("^через (?:(\\d{1,4}|[а-яё]+) )?(секунд[уы]?|секунд|минут[уы]?|минут|час(?:а|ов)?)\\s*[, ]+(.+)$");
    private static final Pattern AT=Pattern.compile("^(?:(сегодня|завтра|послезавтра|[0-9]{4}-[0-9]{2}-[0-9]{2}) )?в (\\d{1,2})(?:[:.](\\d{2}))?(?: (утра|дня|вечера|ночи))?[, ]+(.+)$");
    private static final List<List<String>> NUMBERS=List.of(List.of(),List.of("одну","один","одна"),List.of("две","два"),List.of("три"),List.of("четыре"),List.of("пять"),List.of("шесть"),List.of("семь"),List.of("восемь"),List.of("девять"),List.of("десять"),List.of("одиннадцать"),List.of("двенадцать"));
    private static int number(String word){
        if(word==null)return 1;
        if(word.matches("\\d{1,4}"))return Integer.parseInt(word);
        for(int i=1;i<NUMBERS.size();i++)if(NUMBERS.get(i).contains(word))return i;
        return 0;
    }
    private static long seconds(Matcher m){
        int n=number(m.group(1));String unit=m.group(2);
        return (long)n*(unit.startsWith("час")?3600:unit.startsWith("минут")?60:1);
    }
    static boolean googleTasks(String q){
        return Pattern.compile("(?iu)(?:google|гугл)\\s*(?:tasks|задач)|(?:в|из)\\s+задач(?:и|ах)?\\s+(?:google|гугл)(?!\\s*календар)").matcher(q).find();
    }
    static boolean local(String q){return q.matches("(?isu).*(?:локально|локальн\\p{L}* (?:напоминан|задач)|в (?:самой )?марии).*");}
    private static final Pattern REQUEST=Pattern.compile("(?iu)^(?:пожалуйста[, ]+)?(?:напомни|(?:поставь|создай|добавь|запланируй) (?:мне )?(?:задачу|напоминание))(?:\\s+мне)?[, :]+(.+)$");
    private static final Pattern SUFFIX=Pattern.compile("(?iu)^(.+?)[, ]+(?:на )?((?:(?:сегодня|завтра|послезавтра) )?в \\d{1,2}(?:[:.]\\d{2})?(?: (?:утра|дня|вечера|ночи))?|через (?:[а-яё0-9]+ )?(?:минут[уы]?|час(?:а|ов)?|секунд[уы]?))$");
    static boolean scheduleRequest(SearchActivity a,String raw){
        var match=REQUEST.matcher(raw.strip().replaceFirst("[.!?]+$",""));
        if(!match.matches())return false;
        String text=match.group(1).replaceAll("(?iu)(?:^|\\s+)(?:в (?:google |гугл )?календар[ье]|в марии|локально)(?=$|[ ,])"," ").strip().replaceFirst("^[, ]+","");
        var tail=SUFFIX.matcher(text);
        if(tail.matches()){
            String name=tail.group(1).strip();
            if(name.matches("(?isu).*(?:понедельник|вторник|сред[ау]|четверг|пятниц|суббот|воскресень|числа|январ|феврал|марта|апрел|мая|июн|июл|август|сентябр|октябр|ноябр|декабр|\\d[./-]\\d).*")){
                a.understand(raw);return true;
            }
            text=tail.group(2).toLowerCase(Locale.ROOT)+" "+name;
        }
        if(AT.matcher(text).matches()||AFTER.matcher(text).matches())reminder(a,text,local(raw.toLowerCase(Locale.ROOT)));
        else a.understand(raw);
        return true;
    }
    static void reminder(SearchActivity a,String request,boolean local){
        Matcher after=AFTER.matcher(request),at=AT.matcher(request);
        long due=0;String note="";
        if(after.matches() && seconds(after)>0){due=System.currentTimeMillis()+1000*seconds(after);note=after.group(3);}
        else if(at.matches()){
            int hour=Integer.parseInt(at.group(2)),minute=at.group(3)==null?0:Integer.parseInt(at.group(3));
            if(hour<24&&minute<60){
                  if(at.group(1)!=null && at.group(1).matches("[0-9]{4}-.*")){
                      try{due=LocalDate.parse(at.group(1)).atTime(hour,minute).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();}
                      catch(DateTimeException invalid){due=0;}
                  }else due=ActionReceipt.due(request.substring(0,at.start(5)));
                  note=at.group(5);
            }
        }
        if(due<=System.currentTimeMillis()){a.reply("Назовите будущее время и задачу. Например, «Напомни через пять минут проверить договор».");return;}
        if(!local){a.calendarNotes.add(note,due);return;}
        final long when=due;final String message=note;
        a.withNotifications(()->{
            for(var job:a.getSystemService(android.app.job.JobScheduler.class).getAllPendingJobs()){
                var data=job.getExtras();
                if(job.getService().getClassName().equals(Reminder.class.getName()) && data.getLong("due")==when &&
                        message.equalsIgnoreCase(data.getString("note",""))){a.reply("Это напоминание уже есть в Марии на "+ActionReceipt.stamp(when)+".");return;}
            }
            if(Reminder.schedule(a,"Напоминание Марии",message,when,false)){
                ActionReceipt.remember(a,"remind",message,when,"Локальное напоминание Марии «"+message+"» запланировано на");
                a.reply(ActionReceipt.report(a,"remind"));
            }else a.reply("Не удалось поставить напоминание. Проверьте уведомления Марии и выбранное время.");
        });
    }
    static boolean requestsGoogleDevices(String raw){
        String q=raw.toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("[,.!?]+"," ").strip().replaceAll("\\s+"," ");
        q=q.replaceFirst("^(?:(?:джарвис|jarvis|пожалуйста|ну|а|мне) )+","");
        if(!q.matches("(?:посмотри|посмотреть|проверь|покажи|открой|скажи|какие|на каких|где|список)(?: .*|$)"))return false;
        if(q.matches(".* (?:файл|документ|фото|видео|договор|текст)\\p{L}*(?: .*|$)"))return false;
        return q.matches(".* (?:google|гугл\\p{L}*)(?: .*|$)") && q.matches(".*(?:аккаунт|учетн).*")
            && q.matches(".*(?:устройств|телефон|компьютер|сеанс|сесси).*");
    }
    static boolean handle(SearchActivity a,String phrase){
        if(phrase.startsWith("через ")){
            Matcher later=AFTER.matcher(phrase);
            if(!later.matches() || !later.group(3).matches("(?:найди|поищи) .+"))return false;
            String query=later.group(3).replaceFirst("^\\S+ ","").trim();
            if(seconds(later)<=0||ContentRequest.parse(query)!=null){
                a.reply("Для фонового поиска назовите время и имя файла. Например, «Через пять минут найди файл договор».");return true;
            }
            long due=System.currentTimeMillis()+seconds(later)*1000;
            a.withNotifications(()->a.reply(Reminder.schedule(a,"Поиск Марии",query,due,false,true)
                    ?"Поставил фоновый поиск. Пришлю уведомление с результатом.":"Не удалось запланировать поиск. Проверьте уведомления Марии."));
            return true;
        }
        if(phrase.startsWith("напомни ")){reminder(a,phrase.substring(8).replaceFirst("^мне ",""),local(phrase));return true;}
        if(phrase.matches("(?:покажи |открой )?(?:мои )?(?:напоминания|задачи)")){CalendarNotes.open(a,null);return true;}
        if(phrase.matches("(?:включи|запусти|поставь) таймер.*")){
            Matcher m=AFTER.matcher("через "+phrase.replaceFirst("^.*?таймер(?: на)?\\s*","")+" таймер");
            if(!m.matches()||seconds(m)<=0||seconds(m)>86400)a.reply("Например, «Поставь таймер на пять минут».");
            else timer(a,(int)seconds(m));
            return true;
        }
        String setting=switch(phrase){
            case "подключи наушники","как подключить наушники","подключи наушники по bluetooth","подключи bluetooth наушники" -> Settings.ACTION_BLUETOOTH_SETTINGS;
            case "поменяй язык телефона","как изменить язык телефона","открой языки телефона" -> Settings.ACTION_LOCALE_SETTINGS;
            case "сколько места на телефоне","сколько свободного места","покажи память телефона" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS;
            case "покажи расход батареи","покажи расход заряда" -> Intent.ACTION_POWER_USAGE_SUMMARY;
            default -> null;
        };
        if(setting!=null){launch(a,new Intent(setting));return true;}
        if(phrase.matches("(?:открой|покажи) настройки (?:цифрового помощника|ассистента)")){
            launch(a,new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS));
            return true;
        }
        if (phrase.matches("как в приложении (?:google|гугл) настроить ассистента") || phrase.matches("(?:открой|покажи|как открыть|как настроить|настрой) (?:настройки )?(?:гугл |google )?ассистента(?: google| гугл)?")) {
            Intent google = new Intent("com.google.android.googlequicksearchbox.action.ASSISTANT_SETTINGS")
                    .setPackage("com.google.android.googlequicksearchbox");
            try { a.startActivity(google); }
            catch (ActivityNotFoundException | SecurityException missing) {
                android.widget.Toast.makeText(a,"Открываю системный выбор цифрового помощника",android.widget.Toast.LENGTH_LONG).show();
                launch(a,new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS));
            }
            return true;
        }
        boolean explicitApp = phrase.matches("^(?:найди|поищи|покажи|открой|запусти) (?:мне )?приложение .+");
        if (explicitApp) phrase = phrase.replaceFirst("^\\S+ (?:мне )?приложение ", "открой приложение ");
        Matcher open=OPEN.matcher(phrase);if(!open.matches())return false;
        String name=open.group(1),verb=open.group(2),value=open.group(3),next=open.group(4);
        return openApp(a,name,verb,value,next,explicitApp);
    }
    static boolean openApp(SearchActivity a,String name,String verb,String value,String next,boolean explicitApp){
        if(verb==null && name.matches("(?:настройки )?(?:wi-fi|wifi|вайфай|вай-фай|bluetooth|блютуз)")){
            launch(a,new Intent(name.contains("блютуз")||name.contains("bluetooth")?Settings.ACTION_BLUETOOTH_SETTINGS:Settings.ACTION_WIFI_SETTINGS));return true;
        }
        String alias=switch(name){
            case "гугл","google"->"com.google.android.googlequicksearchbox";
            case "ютуб","ютьюб","youtube"->"com.google.android.youtube";
            case "диск","гугл диск","google диск","google drive"->"com.google.android.apps.docs";
            case "гугл фото","google фото","google photos"->"com.google.android.apps.photos";
            case "настройки"->"com.android.settings";
            default->"";
        };
        PackageManager pm=a.getPackageManager();
        Map<String,ComponentName> apps=new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        Set<String> capable=purposeApps(pm,name);
        boolean recorder=name.matches(".*(?:запис[ьиь]? звонков|записыва[а-яё]* звонки|call recorder).*");
        boolean cube=name.matches(".*(?<![а-яёa-z0-9])(?:cube|куб)(?![а-яёa-z0-9]).*");
        boolean appLookup=explicitApp || alias.length()>0;
        int best=0;
        for(var r:pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0)){
            String pkg=r.activityInfo.packageName;
            String label=r.loadLabel(pm).toString();
            String key=label+" · "+pkg;
            ComponentName component=new ComponentName(pkg,r.activityInfo.name);
            int score=0;
            String lower=label.toLowerCase(Locale.ROOT);
            if(pkg.equals(alias)||label.equalsIgnoreCase(name))score=100;
            else if(appLookup && (cube || recorder) && pkg.equals("com.catalinagroup.callrecorder") && !name.matches(".*(?:helper|помощник).*"))score=90;
            else if(explicitApp && name.length()>=3 && lower.contains(name))score=80;
            else if(explicitApp && Arrays.stream(name.split("[^a-z0-9]+")).anyMatch(w->w.length()>=3 && Arrays.asList(lower.split("[^a-z0-9]+")).contains(w)))score=60;
            else if(capable.contains(pkg) || calculator(name,label) || recorder && lower.matches(".*(?:call recorder|запись звонков).*"))score=40;
            if(score>best){best=score;apps.clear();}
            if(score>0 && score==best)apps.put(key,component);
        }
        if(appLookup || !apps.isEmpty()){
            a.lastAppQuery=name;
            a.record("Источник","Установленные приложения текущего профиля Android · «"+name+"» · совпадений "+apps.size());
        }
        if(apps.isEmpty()){
            if(verb==null && alias.isEmpty() && !explicitApp)return false;
            a.reply("Не нашла установленное приложение «"+name+"».");return true;
        }
        java.util.function.Consumer<ComponentName> run=component->{
            String pkg=component.getPackageName();
            Intent launcher=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(component);
            if(verb==null){
                try{a.startActivity(launcher);a.record("Запуск приложения",pkg);}
                catch(ActivityNotFoundException|SecurityException unavailable){a.reply("Android не смог открыть выбранное приложение.");}
                return;
            }
            boolean find=!verb.equals("нажми");
            if(find){
                String action=pkg.equals("com.google.android.apps.photos")||pkg.equals("com.google.android.apps.docs")
                        ?"com.google.android.gms.actions.SEARCH_ACTION":Intent.ACTION_SEARCH;
                Intent search=new Intent(action).setPackage(pkg).putExtra(SearchManager.QUERY,value);
                if(search.resolveActivity(pm)!=null && (next==null||ScreenTask.ready())){
                    if(next==null)launch(a,search);
                    else a.authorizeScreen(pkg,"Найти «"+value+"», затем нажать «"+next+"»",()->{
                        if(ScreenTask.start(pkg,next,false,null))launch(a,search);
                    });
                    return;
                }
            }
            if(!ScreenTask.ready()){
                new AlertDialog.Builder(a).setTitle("Действия на экране").setMessage(ScreenTask.accessStatus(a))
                    .setPositiveButton("Открыть настройки",(d,w)->launch(a,new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).setNegativeButton("Отмена",null).show();return;
            }
            String description=(find?"Найти «":"Нажать «")+value+"»"+(next==null?"":", затем нажать «"+next+"»");
            a.authorizeScreen(pkg,description,()->{
                if(ScreenTask.start(pkg,value,find,next))launch(a,launcher);
                else a.reply("Служба управления экраном недоступна.");
            });
        };
        if(apps.size()==1)run.accept(apps.values().iterator().next());
        else new AlertDialog.Builder(a).setTitle("Какое приложение открыть?").setItems(apps.keySet().toArray(new String[0]),
                (d,i)->run.accept(new ArrayList<>(apps.values()).get(i))).show();
        return true;
    }
    static void timer(SearchActivity a,int seconds){
        launch(a,new Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH,seconds)
                .putExtra(AlarmClock.EXTRA_SKIP_UI,true).putExtra(AlarmClock.EXTRA_MESSAGE,"Мария"));
    }
    private static boolean calculator(String query,String label){
        return query.matches(".*(?:калькулятор|посчитать|вычислени).*") && label.toLowerCase(Locale.ROOT).matches("calculator|калькулятор");
    }
    private static Set<String> purposeApps(PackageManager pm,String query){
        String category;
        if(query.matches(".*(?:карты|маршрут|навигац).*")) category=Intent.CATEGORY_APP_MAPS;
        else if(query.matches(".*(?:браузер|сайт|интернет).*")) category=Intent.CATEGORY_APP_BROWSER;
        else if(query.matches(".*(?:почт|email).*")) category=Intent.CATEGORY_APP_EMAIL;
        else if(query.matches(".*(?:календар|расписани).*")) category=Intent.CATEGORY_APP_CALENDAR;
        else if(query.matches(".*(?:галере|фотографи|просмотра фото).*")) category=Intent.CATEGORY_APP_GALLERY;
        else if(query.matches(".*(?:музык|плеер).*")) category=Intent.CATEGORY_APP_MUSIC;
        else return Set.of();
        Set<String> packages=new HashSet<>();
        for(var result:pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(category),0))
            packages.add(result.activityInfo.packageName);
        return packages;
    }
    private static void launch(SearchActivity a,Intent intent){
        try{a.startActivity(intent);}catch(ActivityNotFoundException|SecurityException unavailable){a.reply("Android не смог выполнить эту команду в приложении.");}
    }
}
