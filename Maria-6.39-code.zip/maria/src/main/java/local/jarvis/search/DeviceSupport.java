package local.jarvis.search;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import java.io.IOException;
import java.util.Arrays;

/** Device capabilities, never manufacturer or model names. */
final class DeviceSupport {
    static boolean nativeModels() {
        return BuildConfig.LOCAL_MODELS && Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a");
    }
    static boolean memoryAvailable(Context context, long minimumBytes) {
        ActivityManager manager=context.getSystemService(ActivityManager.class);
        if(manager==null || manager.isLowRamDevice())return false;
        ActivityManager.MemoryInfo info=new ActivityManager.MemoryInfo();manager.getMemoryInfo(info);
        return !info.lowMemory && info.availMem-info.threshold>=minimumBytes;
    }
    static void requireModels(Context context) throws IOException {
        if(!nativeModels())throw new IOException("Поиск по изображению и распознавание надписей доступны в полной ARM64-версии. В этой версии используйте поиск по названиям файлов и текстовые команды.");
        if(!memoryAvailable(context,384L*1024*1024))throw new IOException("Недостаточно свободной памяти для обработки изображения. Закройте другие приложения и повторите.");
    }
    static String description() {
        return "Android 10 и новее. Марка телефона не ограничена.\n\n"+
            (nativeModels()?"Полная ARM64-версия: локальные голос, OCR и поиск по изображению; нужен запас свободной памяти.":"Универсальная облегчённая версия: команды, файлы, чтение доступного текста на экране и системный голос. Локальные нейросети и OCR в неё не включены.")+
            "\n\nДля голоса нужны установленный сервис распознавания и русский голос Android. Без них команды можно печатать, ответы — читать. Google Диск и Google Фото необязательны.\n\nСистемные действия зависят от разрешений и оболочки Android. Если переключатель не распознан однозначно, измените настройку вручную.";
    }
}
