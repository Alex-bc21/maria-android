package local.jarvis.search;

import android.accounts.*;
import android.content.*;
import android.net.Uri;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

final class DriveFiles {
    static final String SCOPE="oauth2:https://www.googleapis.com/auth/drive.readonly";
    private static final String BASE="https://www.googleapis.com/drive/v3/files";
    private static final android.util.LruCache<String,String> posters=new android.util.LruCache<>(512);
    static android.graphics.Bitmap thumbnail(Context c,Uri uri) throws Exception {
        String owner=account(c);
        String key=owner+"|"+uri;
        String link=posters.get(key);
        if(link==null)link=refreshPoster(c,owner,uri,key);
        if(link.isEmpty())return null;
        try{return readPoster(c,owner,link);}
        catch(DriveFailure.Http expired){
            if(expired.status!=403 && expired.status!=404 && expired.status!=410)throw expired;
            String refreshed=refreshPoster(c,owner,uri,key);
            return refreshed.isEmpty() || refreshed.equals(link)?null:readPoster(c,owner,refreshed);
        }
    }
    private static String refreshPoster(Context c,String owner,Uri uri,String key)throws Exception{
        Uri metadata=Uri.parse(BASE).buildUpon().appendPath(uri.getLastPathSegment())
                .appendQueryParameter("fields","thumbnailLink").appendQueryParameter("supportsAllDrives","true").build();
        String link=readPage(c,owner,metadata.toString()).optString("thumbnailLink");
        posters.put(key,link);
        return link;
    }
    private static android.graphics.Bitmap readPoster(Context c,String owner,String link)throws Exception{
        URL url=new URL(link);
        String host=url.getHost();
        if(!"https".equals(url.getProtocol()) || !(host.matches("lh[0-9]+[.]googleusercontent[.]com") || host.equals("drive.google.com")))return null;
        HttpURLConnection h=get(c,owner,link);
        try(InputStream in=h.getInputStream()){return android.graphics.BitmapFactory.decodeStream(in);}
        finally{h.disconnect();}
    }
    static String account(Context c){return c.getSharedPreferences("drive",0).getString("account","");}
    static void account(Context c,String name){c.getSharedPreferences("drive",0).edit().putString("account",name).apply();}
    static boolean remote(Uri u){return "jarvis-drive".equals(u.getScheme());}
    private static HttpURLConnection get(Context c,String url) throws Exception {
        return get(c,account(c),url);
    }
    static void verify(Context c,String name) throws Exception {
        HttpURLConnection request=get(c,name,"https://www.googleapis.com/drive/v3/about?fields=kind");
        request.disconnect();
    }
    private static HttpURLConnection get(Context c,String name,String url) throws Exception {
        AccountManager manager=AccountManager.get(c);
        if(name.isEmpty())throw new IOException();
        for(int i=0;i<2;i++){
            String token=manager.getAuthToken(new Account(name,"com.google"),SCOPE,null,false,null,null)
                    .getResult(20,java.util.concurrent.TimeUnit.SECONDS).getString(AccountManager.KEY_AUTHTOKEN);
            if(token==null)throw new android.accounts.AuthenticatorException("Token unavailable");
            HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();
            h.setConnectTimeout(7000);h.setReadTimeout(12000);h.setRequestProperty("Authorization","Bearer "+token);
            h.setInstanceFollowRedirects(false);
            try {
                int status=h.getResponseCode();
                if(status==200)return h;
                if(status!=401)throw new DriveFailure.Http(status);
                manager.invalidateAuthToken("com.google",token);
            } catch(Exception e){h.disconnect();throw e;}
            h.disconnect();
        }
        throw new DriveFailure.Http(401);
    }
    private static String literal(String text){return "'"+text.replace("\\","\\\\").replace("'","\\'")+"'";}
    static void search(Context c,PhoneSearch.Query query,ContentRequest contents,int limit,java.util.function.Consumer<String> trace,java.util.function.Consumer<PhoneSearch.Hit> receive) throws Exception {
        String owner=account(c);
        String where="trashed = false and mimeType != 'application/vnd.google-apps.folder'";
        if(query.documents)where+=" and "+PhoneSearch.driveDocumentFilter();
        if(query.scans)where+=" and (mimeType = 'application/pdf' or mimeType contains 'image/')";
        if(query.pdf)where+=" and mimeType = 'application/pdf'";
        if(query.textDocuments)where+=" and (mimeType = 'application/pdf' or mimeType contains 'text/')";
        if(query.videos)where+=" and mimeType contains 'video/'";
        if(query.images)where+=" and mimeType contains 'image/'";
        String terms=contents==null?String.join(" ",query.words):contents.terms();
        if(contents==null && query.contractSearch()){
            where+=" and (name contains 'договор' or fullText contains 'договор' or name contains 'договір' or fullText contains 'договір')";
        }else if(!terms.isEmpty()){
            List<String> parts=contents!=null && !contents.visual()?List.of(terms):Arrays.stream(terms.split("\\s+"))
                    .filter(t->!Set.of("и","на","с","в","у","со","из","где","там","был","была").contains(t)).distinct().collect(java.util.stream.Collectors.toList());
            for(String part:parts){
                boolean phrase=contents!=null && !contents.visual() && part.contains(" ");
                String indexed=phrase?"\""+part.replace("\"","")+"\"":part;
                where+=" and (name contains "+literal(part)+" or fullText contains "+literal(indexed)+")";
            }
        }
        if(!query.images && query.from>0)where+=" and modifiedTime >= "+literal(java.time.Instant.ofEpochMilli(query.from).toString());
        if(!query.images && query.until<Long.MAX_VALUE)where+=" and modifiedTime < "+literal(java.time.Instant.ofEpochMilli(query.until).toString());
        Uri.Builder base=Uri.parse(BASE).buildUpon().appendQueryParameter("q",where).appendQueryParameter("spaces","drive")
            .appendQueryParameter("fields","nextPageToken,files(id,name,mimeType,modifiedTime,size,resourceKey,thumbnailLink"+(query.images?",imageMediaMetadata(time)":"")+")")
            .appendQueryParameter("orderBy","modifiedTime desc").appendQueryParameter("pageSize",String.valueOf(query.images && query.from>0?1000:Math.min(1000,limit)))
            .appendQueryParameter("supportsAllDrives","true").appendQueryParameter("includeItemsFromAllDrives","true");
        int returned=0;
        String page="";
        do{
            if(Thread.currentThread().isInterrupted())throw new InterruptedException();
            Uri.Builder uri=base.build().buildUpon();if(!page.isEmpty())uri.appendQueryParameter("pageToken",page);
            String url=uri.build().toString();
            JSONObject json=DriveFailure.readPage(()->readPage(c,owner,url),trace);
            JSONArray files=json.getJSONArray("files");
            for(int i=0;i<files.length();i++){
                JSONObject f=files.getJSONObject(i);String id=f.getString("id"),time=f.getString("modifiedTime");
                long date=java.time.Instant.parse(time).toEpochMilli();
                JSONObject metadata=f.optJSONObject("imageMediaMetadata");
                if(metadata!=null)date=captureDate(metadata.optString("time"),date);
                if(date<query.from || date>=query.until)continue;
                Uri.Builder item=new Uri.Builder().scheme("jarvis-drive").authority("file").appendPath(id);
                if(!f.optString("resourceKey").isEmpty())item.appendQueryParameter("resourcekey",f.getString("resourceKey"));
                Uri key=item.build();
                String link=f.optString("thumbnailLink");
                posters.put(owner+"|"+key,link);
                receive.accept(new PhoneSearch.Hit(f.getString("name"),SelectedItems.DRIVE,f.getString("mimeType"),key,
                    date,time+"/"+f.optString("size")));
                if(++returned>=limit)return;
            }
            page=json.optString("nextPageToken","");
        }while(!page.isEmpty());
    }
    static long captureDate(String value,long fallback){
        if(value.isEmpty())return fallback;
        try{return java.time.Instant.parse(value).toEpochMilli();}catch(java.time.format.DateTimeParseException ignored){}
        try{return java.time.LocalDateTime.parse(value,java.time.format.DateTimeFormatter.ofPattern("uuuu:MM:dd HH:mm:ss",Locale.ROOT))
                .atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();}
        catch(java.time.format.DateTimeParseException unknown){return fallback;}
    }
    private static JSONObject readPage(Context c,String owner,String url) throws Exception {
        HttpURLConnection h=get(c,owner,url);
        try(BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream(),StandardCharsets.UTF_8))){
            StringBuilder body=new StringBuilder();String line;while((line=r.readLine())!=null)body.append(line);
            return new JSONObject(body.toString());
        }finally{h.disconnect();}
    }
    static PhoneSearch.Hit download(Context c,PhoneSearch.Hit hit) throws Exception {
        return download(c,hit,Long.MAX_VALUE);
    }
    static PhoneSearch.Hit download(Context c,PhoneSearch.Hit hit,long byteLimit) throws Exception {
        String mime=hit.mime();
        boolean export=mime.startsWith("application/vnd.google-apps.");
        if(export)mime="application/pdf";
        Uri.Builder uri=Uri.parse(BASE).buildUpon().appendPath(hit.uri().getLastPathSegment());
        if(export)uri.appendPath("export").appendQueryParameter("mimeType",mime);
        else uri.appendQueryParameter("alt","media").appendQueryParameter("supportsAllDrives","true");
        HttpURLConnection h=get(c,uri.build().toString());
        if(h.getContentLengthLong()>byteLimit){h.disconnect();throw new IOException("Preview size limit");}
        File[] stale=c.getCacheDir().listFiles((dir,name)->name.startsWith("drive-preview-"));
        if(stale!=null)for(File previous:stale)if(System.currentTimeMillis()-previous.lastModified()>86400000L)previous.delete();
        File file=File.createTempFile("drive-preview-",".tmp",c.getCacheDir());
        try(InputStream in=h.getInputStream();OutputStream out=new FileOutputStream(file)){
            byte[] buf=new byte[65536];int n;long received=0;
            while((n=in.read(buf))!=-1){
                if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();
                if((received+=n)>byteLimit)throw new IOException("Preview size limit");
                out.write(buf,0,n);
            }
        }catch(Exception e){file.delete();throw e;}finally{h.disconnect();}
        String name=export && !hit.name().toLowerCase(Locale.ROOT).endsWith(".pdf")?hit.name()+".pdf":hit.name();
        return new PhoneSearch.Hit(name,hit.path(),mime,Uri.fromFile(file),hit.date(),hit.stamp(),hit.score(),hit.page(),hit.reason(),hit.original());
    }
}
