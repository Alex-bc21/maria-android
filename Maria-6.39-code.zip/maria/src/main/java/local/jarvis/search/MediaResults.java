package local.jarvis.search;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfRenderer;
import android.media.MediaMetadataRetriever;
import android.os.*;
import android.text.TextUtils;
import android.util.*;
import android.view.*;
import android.widget.*;
import java.text.DateFormat;
import java.util.*;
import java.util.concurrent.*;

final class MediaResults extends BaseAdapter {
    private final Studio ui;
    private final ExecutorService loader=Executors.newFixedThreadPool(2);
    private final Handler main=new Handler(Looper.getMainLooper());
    private final LruCache<String,Bitmap> cache=new LruCache<>(16*1024*1024){
        protected int sizeOf(String k,Bitmap b){return b.getAllocationByteCount();}
    };
    private List<PhoneSearch.Hit> items=Collections.emptyList();
    private boolean gallery,closed;
    private final java.util.function.Consumer<PhoneSearch.Hit> actions;
    MediaResults(Studio ui,java.util.function.Consumer<PhoneSearch.Hit> actions){this.ui=ui;this.actions=actions;}
    void set(List<PhoneSearch.Hit> next){set(next,false);}
    void set(List<PhoneSearch.Hit> next,boolean tiles){items=next;gallery=tiles;notifyDataSetChanged();}
    public int getCount(){return items.size();}
    public PhoneSearch.Hit getItem(int i){return items.get(i);}
    public long getItemId(int i){return i;}
    public int getViewTypeCount(){return 2;}
    public int getItemViewType(int i){return gallery?1:0;}

    private static final class Holder {
        ImageView image,badge;
        TextView title,detail,more,format;
        volatile String key;
        Future<?> job;
    }
    private View card(Holder h){
        h.image=new ImageView(ui.ctx);
        h.image.setBackground(ui.shape(0xff283240,10,0));h.image.setClipToOutline(true);
        LinearLayout words=ui.column();
        h.title=ui.text("",gallery?14:16,Studio.TEXT,true);
        h.detail=ui.text("",12,gallery?Color.WHITE:Studio.MUTED,false);
        for(TextView label:new TextView[]{h.title,h.detail}){
            label.setMaxLines(gallery?1:2);label.setEllipsize(TextUtils.TruncateAt.END);words.addView(label);
        }
        h.more=ui.text("⋮",24,Studio.TEXT,true);h.more.setGravity(Gravity.CENTER);
        h.more.setBackground(ui.surface(0xbb151c28,15,0));
        if(!gallery){
            LinearLayout row=ui.row();row.setPadding(ui.dp(8),ui.dp(6),ui.dp(4),ui.dp(6));
            row.setBackground(ui.surface(Studio.PANEL,14,Studio.EDGE));row.addView(h.image,ui.lp(72,84));ui.gap(row,10);
            row.addView(words,new LinearLayout.LayoutParams(0,-2,1));row.addView(h.more,ui.lp(48,48));return row;
        }
        FrameLayout tile=new FrameLayout(ui.ctx){
            @Override protected void onMeasure(int width,int height){
                super.onMeasure(width,MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(width),MeasureSpec.EXACTLY));
            }
        };
        tile.setBackground(ui.shape(Studio.PANEL,16,0));tile.setClipToOutline(true);
        tile.addView(h.image,new FrameLayout.LayoutParams(-1,-1));
        h.format=ui.text("",25,Studio.TEXT,true);h.format.setGravity(Gravity.CENTER);
        tile.addView(h.format,new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER));
        words.setPadding(ui.dp(9),ui.dp(19),ui.dp(9),ui.dp(8));
        words.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00000000,0xd90a0e16,0xf20a0e16}));
        tile.addView(words,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
        h.badge=ui.icon("video",Color.WHITE);h.badge.setPadding(ui.dp(5),ui.dp(5),ui.dp(5),ui.dp(5));
        h.badge.setBackground(ui.shape(0xc0151c28,9,0));
        FrameLayout.LayoutParams tag=new FrameLayout.LayoutParams(ui.dp(29),ui.dp(29),Gravity.TOP|Gravity.START);
        tag.setMargins(ui.dp(7),ui.dp(7),0,0);tile.addView(h.badge,tag);
        tile.addView(h.more,new FrameLayout.LayoutParams(ui.dp(48),ui.dp(48),Gravity.TOP|Gravity.END));
        return tile;
    }

    public View getView(int position,View recycled,ViewGroup parent){
        Holder h;
        if(recycled==null){h=new Holder();recycled=card(h);recycled.setTag(h);}
        else h=(Holder)recycled.getTag();
        PhoneSearch.Hit hit=getItem(position);
        boolean video=hit.mime().startsWith("video/"),photo=hit.mime().startsWith("image/"),pdf=hit.mime().equals("application/pdf");
        boolean document=!photo && !video;
        String kind=video?"video":photo?"photo":"doc";
        String owner=DriveFiles.remote(hit.uri())?DriveFiles.account(ui.ctx):"";
        String key=owner+"|"+hit.uri()+"#"+hit.stamp()+"#"+hit.frameMillis()+"#"+hit.keyFrame()+"#"+hit.page()+"#"+gallery;
        ui.action(h.more,"Действия с файлом "+hit.name(),()->actions.accept(hit));h.more.setFocusable(false);
        h.title.setMaxLines(gallery && !document?1:2);h.title.setText(hit.name());
        String date=hit.date()>0?DateFormat.getDateInstance().format(new Date(hit.date())):"";
        boolean added="file".equals(hit.uri().getScheme()) || DriveFiles.remote(hit.uri());
        String origin=added?hit.path():"com.google.android.apps.docs.storage".equals(hit.uri().getAuthority())?"Google Диск":"Телефон";
        if(DriveFiles.remote(hit.uri()))origin="Google Диск · онлайн";
        String detail=hit.reason().isEmpty()?String.join(" · ",date,added?origin:hit.path()).replaceAll("^ · | · $",""):hit.reason();
        if(gallery && (DriveFiles.remote(hit.uri()) || SelectedItems.DRIVE.equals(hit.path()) || SelectedItems.PHOTOS.equals(hit.path())))
            h.detail.setText(hit.reason().isEmpty()?detail:hit.path()+" · "+hit.reason());
        else h.detail.setText(gallery || hit.reason().isEmpty()?detail:origin+" · "+detail);
        if(h.badge!=null){
            h.badge.setVisibility(photo?View.GONE:View.VISIBLE);h.badge.setImageDrawable(ui.glyph(kind,Color.WHITE));
        }
        if(key.equals(h.key))return recycled;
        if(h.job!=null)h.job.cancel(false);h.key=key;
        h.image.setContentDescription(null);h.image.setScaleType(ImageView.ScaleType.CENTER);
        h.image.setImageDrawable(gallery && document?null:ui.glyph(kind,Studio.LILAC));
        if(h.format!=null){
            String label=format(hit);
            h.format.setText(label);h.format.setVisibility(document?View.VISIBLE:View.GONE);
            int color=switch(label){case "PDF"->0xff62384a;case "XLS","XLSX","CSV"->0xff245049;
                case "DOC","DOCX","TXT"->0xff334664;case "PPT","PPTX"->0xff664431;default->0xff424056;};
            h.image.setBackground(ui.shape(document?color:0xff283240,10,0));
            if(document)h.image.setContentDescription("Формат "+label+" · "+hit.name());
        }
        if(document && !pdf && !DriveFiles.remote(hit.uri()) && !"content".equals(hit.uri().getScheme()))return recycled;
        String description="Предпросмотр "+hit.name();
        int size=gallery?Math.min(640,ui.dp(220)):ui.dp(90);
        Bitmap saved=cache.get(key);
        if(saved!=null)display(h,saved,description,document);
        else h.job=loader.submit(()->{
            if(!key.equals(h.key))return;
            try {
                Bitmap b=thumbnail(hit,size,video,pdf);
                if(b==null)return;
                main.post(()->{
                    if(closed)return;
                    cache.put(key,b);
                    if(key.equals(h.key))display(h,b,description,document);
                });
            }catch(Exception ignored){ /* Keep the type icon for unavailable previews. */ }
        });
        return recycled;
    }
    private Bitmap thumbnail(PhoneSearch.Hit hit,int size,boolean video,boolean pdf) throws Exception {
        if(DriveFiles.remote(hit.uri())){
            Bitmap cover=DriveFiles.thumbnail(ui.ctx,hit.uri());
            if(cover!=null)return cover;
            if(!pdf && !Set.of("application/vnd.google-apps.document","application/vnd.google-apps.spreadsheet",
                    "application/vnd.google-apps.presentation","application/vnd.google-apps.drawing").contains(hit.mime()))return null;
            long limit=8L*1024*1024;
            String stamp=hit.stamp();
            try{if(Long.parseLong(stamp.substring(stamp.lastIndexOf('/')+1))>limit)return null;}
            catch(NumberFormatException unknownSize){ /* Enforce the limit on the stream as well. */ }
            PhoneSearch.Hit local=DriveFiles.download(ui.ctx,hit,limit);
            try{return thumbnail(local,size,false,true);}
            finally{new java.io.File(local.uri().getPath()).delete();}
        }
        if(pdf){
            try(ParcelFileDescriptor fd=ui.ctx.getContentResolver().openFileDescriptor(hit.uri(),"r");
                PdfRenderer renderer=new PdfRenderer(fd);
                PdfRenderer.Page page=renderer.openPage(Math.max(0,Math.min(hit.page(),renderer.getPageCount()-1)))){
                float scale=(float)size/Math.max(page.getWidth(),page.getHeight());
                Bitmap out=Bitmap.createBitmap(Math.max(1,Math.round(scale*page.getWidth())),Math.max(1,Math.round(scale*page.getHeight())),Bitmap.Config.ARGB_8888);
                out.eraseColor(Color.WHITE);page.render(out,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);return out;
            }
        }
        if(video){
            if(hit.frameMillis()<0 && "content".equals(hit.uri().getScheme())){
                try{return ui.ctx.getContentResolver().loadThumbnail(hit.uri(),new Size(size,size),null);}
                catch(Exception unavailable){ /* Extract from the video when the provider has no poster. */ }
            }
            try(MediaMetadataRetriever reader=new MediaMetadataRetriever()){
                reader.setDataSource(ui.ctx,hit.uri());
                return reader.getScaledFrameAtTime(hit.frameMillis()<0?-1:hit.frameMillis()*1000,hit.keyFrame()?MediaMetadataRetriever.OPTION_CLOSEST_SYNC:MediaMetadataRetriever.OPTION_CLOSEST,size,size);
            }
        }
        if(!hit.mime().startsWith("image/"))return ui.ctx.getContentResolver().loadThumbnail(hit.uri(),new Size(size,size),null);
        return SelectedItems.thumbnail(ui.ctx,hit.uri(),size);
    }
    private String format(PhoneSearch.Hit hit){
        String nativeType=switch(hit.mime()){
            case "application/vnd.google-apps.document"->"DOC";case "application/vnd.google-apps.spreadsheet"->"XLS";
            case "application/vnd.google-apps.presentation"->"PPT";case "application/pdf"->"PDF";
            default->"";
        };
        if(!nativeType.isEmpty())return nativeType;
        int dot=hit.name().lastIndexOf('.');
        String suffix=dot<0?"":hit.name().substring(dot+1);
        if(suffix.matches("[A-Za-z0-9]{1,8}"))return suffix.toUpperCase(Locale.ROOT);
        return hit.mime().startsWith("audio/")?"Аудио":hit.mime().startsWith("text/")?"Текст":"Файл";
    }
    private void display(Holder h,Bitmap b,String description,boolean document){
        if(h.format!=null)h.format.setVisibility(View.GONE);
        h.image.setScaleType(document?ImageView.ScaleType.FIT_CENTER:ImageView.ScaleType.CENTER_CROP);
        h.image.setImageBitmap(b);h.image.setContentDescription(description);
    }
    void close(){closed=true;loader.shutdownNow();main.removeCallbacksAndMessages(null);cache.evictAll();}
}