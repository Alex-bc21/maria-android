package local.jarvis.search;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.View;

final class AuraView extends View {
    enum Mode { READY, LISTEN, WORK, SPEAK }
    private static CharacterRig.Art artwork;
    private final CharacterRig rig;
    private final Rect visible=new Rect();
    private Mode mode=Mode.READY;
    private float opening,rounding,input;
    AuraView(Context context){
        super(context);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        if(artwork==null)artwork=new CharacterRig.Art(bitmap("avatar_body"),bitmap("avatar_lids"),bitmap("avatar_lips"));
        rig=new CharacterRig(artwork);
    }
    private Bitmap bitmap(String name){
        return BitmapFactory.decodeResource(getResources(),getResources().getIdentifier(name,"drawable",getContext().getPackageName()));
    }
    void mode(Mode next){if(mode!=next){mode=next;input=opening=rounding=0;invalidate();}}
    void level(float rms){input=Math.max(0,Math.min(1,(rms+2)/14));invalidate();}
    void mouth(float open,float round){opening=open;rounding=round;invalidate();}
    void greet(){rig.greet(SystemClock.uptimeMillis());invalidate();}
    void react(boolean happy){rig.react(happy,SystemClock.uptimeMillis());invalidate();}
    @Override protected void onDraw(Canvas canvas){
        boolean motion=ValueAnimator.areAnimatorsEnabled();
        rig.draw(canvas,getWidth(),getHeight(),SystemClock.uptimeMillis(),mode,opening,rounding,input,motion);
        if(motion && isShown() && hasWindowFocus() && getWindowVisibility()==VISIBLE && getLocalVisibleRect(visible)){
            if(mode==Mode.READY)postInvalidateDelayed(32);else postInvalidateOnAnimation();
        }
    }
    @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus)invalidate();}
}
