package local.jarvis.search;

import java.util.Locale;

record SpokenCommand(Kind kind, String text, boolean latest) {
    enum Kind { FIND, OPEN, PICK, ANSWER }
    // Date and media type can occur on either side of the verb in spoken Russian.
    static String datedVideo(String input){
        String words=input.toLowerCase(Locale.ROOT).replaceAll("[,?!.]+"," ").strip()
                .replaceFirst("^(?:джарвис|джервис|jarvis)\\s+","").strip();
        // A spoken contrast describes the same request: "скачивал, а не сам снимал".
        String positiveWords=words.replaceAll("(?<!\\S)не (?:сам(?:а)? )?(?:снимал[аи]?|снял[аи]?)(?!\\S)"," ").strip();
        boolean excludeCamera=!words.equals(positiveWords);
        words=positiveWords;
        boolean downloaded=false;
        String day=null;
        boolean video=false;
        for(String word:words.split("\\s+")){
            switch(word){
                case "видео","ролик","ролики","видеоролики" -> video=true;
                case "скачал","скачала","скачивал","скачивала","скачанные","скачанное",
                     "загрузил","загрузила","загружал","загружала","загруженные" -> downloaded=true;
                case "сегодня","вчера" -> {if(day!=null && !day.equals(word))return null;day=word;}
                case "а","ну","и","мне","найди","найти","покажи","покажите","поищи","пожалуйста",
                     "какие","какое","я","мои","моё","мое","у","меня","есть","за","все","всё",
                     "снимал","снимала","снял","сняла","снятые","записал","записала","которые","которое" -> {}
                default -> {return null;}
            }
        }
        if(!video || day==null || excludeCamera && !downloaded)return null;
        return (downloaded?"скачанные видео за ":"видео за ")+day;
    }
    static SpokenCommand parse(String input, boolean fromVoice) {
        String s=input.toLowerCase(Locale.ROOT).strip()
                .replaceFirst("^(?:джарвис|джервис|jarvis)[, .!]+","")
                .replaceFirst("^пожалуйста[, ]+","").replaceFirst("[?!.]+$","").strip();
        String dated=datedVideo(s);
        if(dated!=null)return new SpokenCommand(Kind.FIND,dated,false);
        if (s.matches("открой (?:первый|первое|первую|второй|второе|вторую|третий|третье|третью|его|её|ее)(?: (?:результат|файл|фото))?"))
            return new SpokenCommand(Kind.PICK,s.contains("втор")?"1":s.contains("трет")||s.contains("треть")?"2":"0",false);
        if (s.matches("^(?:открой|открыть|покажи|найди|найти|поищи|покажите|показывай)(?: .*)?$")) {
            boolean open=s.startsWith("откр");
            String term=s.replaceFirst("^\\S+\\s*","").replaceFirst("^(?:мне|пожалуйста)\\s+","");
            boolean latest=term.matches(".*\\b(?:последн(?:ий|ее|юю)|сам(?:ый|ое|ую) нов(?:ый|ое|ую))\\b.*");
            term=term.replaceAll("\\b(?:последн(?:ий|ее|юю)|сам(?:ый|ое|ую) нов(?:ый|ое|ую)|пожалуйста)\\b"," ").strip();
            return new SpokenCommand(open?Kind.OPEN:Kind.FIND,term,latest);
        }
        boolean fileWords=s.matches("^(?:видео|ролики|фото|фотографии|фотографию|картинки|pdf|пдф|файлы?|документы?)(?: .*)?$");
        boolean question=input.strip().endsWith("?") || s.matches("^(?:что|кто|чем|как|какая|какой|какие|где|почему|зачем|сколько|когда|объясни|расскажи|ответь|придумай|переведи|назови|составь)\\b.*");
        return new SpokenCommand(!fileWords && (fromVoice || question) ? Kind.ANSWER : Kind.FIND,s,false);
    }
}
