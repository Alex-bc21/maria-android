package local.jarvis.search;

import android.content.*;
import android.content.pm.PackageManager;
import java.util.regex.*;

enum Messenger {
    TELEGRAM("Telegram","org.telegram.messenger","telegram|телеграм(?:м)?[еа]?"),
    WHATSAPP("WhatsApp","com.whatsapp","whats\\s*app|ва[тц][сз]?\\s*[аэ]п(?:п)?[еа]?|вотсап[еа]?"),
    VIBER("Viber","com.viber.voip","viber|в[аи]й?бер[еа]?"),
    PLUS("Plus","org.telegram.plus","(?:telegram\\s+)?plus(?:\\s+messenger)?|(?:телеграм\\s+)?плюс[еа]?(?:\\s+мессенджер[еа]?)?");
    final String title,pkg;
    final Pattern alias;
    Messenger(String title,String pkg,String aliases){
        this.title=title;this.pkg=pkg;alias=Pattern.compile("(?iu)^(?:"+aliases+")$");
    }
    record Destination(String name,Messenger app){}
    static Destination parse(String target){
        String[] parts=target.strip().split("(?iu)\\s+(?:в|через)\\s+",2);
        Messenger app=TELEGRAM;
        if(parts.length==2){
            app=null;
            for(Messenger m:values())if(m.alias.matcher(parts[1].strip()).matches()){app=m;break;}
        }
        return new Destination(ScreenItem.recipient(parts[0].strip()),app);
    }
    void address(Context c,Intent intent){
        intent.setPackage(pkg);
        // Use the user's current Android profile when Samsung also offers a cloned app.
        ComponentName component=null;
        for(var row:c.getPackageManager().queryIntentActivities(intent,PackageManager.MATCH_DEFAULT_ONLY)){
            var info=row.activityInfo;
            if(info==null || !pkg.equals(info.packageName) || !info.exported)continue;
            ComponentName candidate=new ComponentName(info.packageName,info.name);
            if(component!=null && !component.equals(candidate))return;
            component=candidate;
        }
        if(component!=null)intent.setComponent(component);
    }
}
