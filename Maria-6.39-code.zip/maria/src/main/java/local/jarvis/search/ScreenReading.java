package local.jarvis.search;

import java.util.*;
/** Cursor into a single Android capture. Nothing is persisted or read from another app in the background. */
final class ScreenReading {
    private ScreenItem capture;
    private String body="";
    private int offset;
    void load(ScreenItem source,String raw){
        LinkedHashSet<String> lines=new LinkedHashSet<>();
        for(String s:raw.split("\\R")){
            String clean=s.strip().replaceAll("\\s+"," ");
            if(!clean.isEmpty())lines.add(clean);
        }
        body=String.join("\n",lines);capture=source;offset=0;
    }
    boolean matches(ScreenItem source){return source!=null&&source==capture;}
    void article(ScreenItem source,String text){capture=source;body=text;offset=0;}
    boolean more(){return offset<body.length();}
    String next(){
        int end=Math.min(offset+480,body.length());
        if(end<body.length()){
            int space=body.lastIndexOf(' ',end),line=body.lastIndexOf('\n',end),dot=body.lastIndexOf(". ",end);
            if(dot>offset+160)end=dot+1;else if(Math.max(space,line)>offset)end=Math.max(space,line);
        }
        String part=body.substring(offset,end).strip();offset=end;
        while(offset<body.length()&&Character.isWhitespace(body.charAt(offset)))offset++;
        return part;
    }
}
