package local.jarvis.search;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.SystemClock;
import android.provider.Settings;
import java.util.regex.Pattern;

/** Public Android settings destinations. Looking up a section never changes a setting. */
final class SettingsCommands {
    private static final Pattern ACCESS=Pattern.compile("(?iu)\\b(?:специа?л?ьн\\p{L}*\\s+возможност\\p{L}*|спец[ -]?возможност\\p{L}*|accessibility)\\b");
    private static final Pattern OPEN=Pattern.compile("(?iu)\\b(?:открой|покажи|перейди|зайди|открыть|попасть|где найти)\\b");
    private static final Pattern CORRECTION=Pattern.compile("(?iu)(?:(?:нет|ну|же|это|оно|раздел|пункт|находится|там|именно) +)*в настройках(?: (?:андроид|android|телефона))?");
    private static String topic;
    private static long at;
    private static String section(String q){
        if(ACCESS.matcher(q).find())return Settings.ACTION_ACCESSIBILITY_SETTINGS;
        if(q.matches(".*(?:блютуз|bluetooth).*"))return Settings.ACTION_BLUETOOTH_SETTINGS;
        if(q.matches(".*(?:wi-fi|wifi|вай[ -]?фай).*"))return Settings.ACTION_WIFI_SETTINGS;
        if(q.contains("яркост")||q.contains("диспле"))return Settings.ACTION_DISPLAY_SETTINGS;
        if(q.contains("язык"))return Settings.ACTION_LOCALE_SETTINGS;
        return null;
    }
    static boolean handle(SearchActivity a,String q){
        boolean correction=CORRECTION.matcher(q).matches();
        String current=correction && SystemClock.elapsedRealtime()-at<120000?topic:section(q);
        topic=null;
        if(q.matches(".*\\bне\\s+(?:надо |нужно )?(?:открывай|открыть|открой|показывай|переходи)\\b.*"))return false;
        boolean access=Settings.ACTION_ACCESSIBILITY_SETTINGS.equals(current);
        boolean status=(access || q.matches(".*(?:управлени\\p{L}* экраном|служб\\p{L}* (?:нажатий|действий)).*")) &&
                q.matches(".*(?:я (?:уже )?(?:дал|дала|выдал|разрешил|включил)|доступ (?:уже )?(?:дан|есть|выдан)|есть ли.*доступ|есть доступ|есть .*доступ|проверь.*доступ|служба.*подключена|служба.*включена).*");
        boolean open=OPEN.matcher(q).find() && (access || q.contains("настройк") && current!=null);
        if(!open && !status && !correction)return false;
        if(correction && current==null)current=Settings.ACTION_SETTINGS;
        if(status && current==null)current=Settings.ACTION_ACCESSIBILITY_SETTINGS;
        topic=current;at=SystemClock.elapsedRealtime();
        if(access||status){
            String state=ScreenTask.accessStatus(a);a.record("Специальные возможности",state);
            if(!open && !correction){a.reply(state);return true;}
        }
        try{a.startActivity(new Intent(current));a.record("Настройки Android","Открыт раздел · "+current);}
        catch(ActivityNotFoundException|SecurityException e){a.reply("Android не смог открыть этот раздел настроек.");}
        return true;
    }
}
