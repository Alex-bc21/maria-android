package local.jarvis.search;
import android.app.job.*;
import android.content.*;
import android.database.Cursor;
import android.provider.MediaStore;
import android.net.Uri;
import java.util.concurrent.*;

public final class ChargeIndex extends JobService {
    static final int ID=518;
    static void schedule(Context c){
        JobScheduler js=c.getSystemService(JobScheduler.class);
        if(!DeviceSupport.nativeModels()){js.cancel(ID);return;}
        if(js.getPendingJob(ID)==null)js.schedule(new JobInfo.Builder(ID,new ComponentName(c,ChargeIndex.class))
            .setRequiresCharging(true).setRequiresBatteryNotLow(true).setPersisted(true).setPeriodic(12*60*60*1000L).build());
    }
    private final ExecutorService worker=Executors.newSingleThreadExecutor();private Future<?> task;
    public boolean onStartJob(JobParameters params){
        if(!DeviceSupport.nativeModels() || !DeviceSupport.memoryAvailable(this,384L*1024*1024))return false;
        task=worker.submit(()->{
            boolean retry=false;
            try(ContentIndex vision=new ContentIndex(this,new ContentRequest(true,"photograph"),0);
                ContentIndex text=new ContentIndex(this,new ContentRequest(false,""),0)){
                for(var h:SelectedItems.list(this)){
                    if(Thread.currentThread().isInterrupted())return;
                    if(h.mime().startsWith("image/"))warm(vision,text,h);
                }
                Uri base=MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                try(Cursor cur=getContentResolver().query(base,new String[]{"_id","_display_name","mime_type","date_modified","_size","volume_name"},null,null,"date_modified DESC")){
                    while(cur!=null&&cur.moveToNext()){
                        if(Thread.currentThread().isInterrupted())return;
                        Uri uri=ContentUris.withAppendedId(MediaStore.Images.Media.getContentUri(cur.getString(5)),cur.getLong(0));
                        warm(vision,text,new PhoneSearch.Hit(cur.getString(1),"",cur.getString(2),uri,0,cur.getLong(3)+"/"+cur.getLong(4)));
                    }
                }
            }catch(Exception|LinkageError e){retry=true;}
            if(!Thread.currentThread().isInterrupted())jobFinished(params,retry);
        });return true;
    }
    private void warm(ContentIndex vision,ContentIndex text,PhoneSearch.Hit hit) throws InterruptedException{
        try{vision.match(hit);if(Thread.currentThread().isInterrupted())throw new InterruptedException();text.imageText(hit);}
        catch(InterruptedException e){throw e;}catch(Exception inaccessible){}
    }
    public boolean onStopJob(JobParameters params){if(task!=null)task.cancel(true);return true;}
    public void onDestroy(){worker.shutdownNow();super.onDestroy();}
}
