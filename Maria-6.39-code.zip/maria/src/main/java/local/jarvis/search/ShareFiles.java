package local.jarvis.search;
import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.*;
import java.util.*;
public final class ShareFiles extends ContentProvider {
    static final String AUTH="local.jarvis.search.exports";
    static Uri copy(Context c,PhoneSearch.Hit hit) throws Exception {
        File dir=new File(c.getCacheDir(),"outbox");dir.mkdirs();
        File[] old=dir.listFiles();if(old!=null)for(File f:old)if(System.currentTimeMillis()-f.lastModified()>86400000L)f.delete();
        String id=UUID.randomUUID().toString();File file=new File(dir,id);
        try(InputStream in=c.getContentResolver().openInputStream(hit.uri());OutputStream out=new FileOutputStream(file)){
            if(in==null)throw new IOException();byte[] buf=new byte[65536];int n;
            while((n=in.read(buf))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();out.write(buf,0,n);}
        }catch(Exception e){file.delete();throw e;}
        return new Uri.Builder().scheme("content").authority(AUTH).appendPath(id).appendQueryParameter("name",hit.name()).appendQueryParameter("mime",hit.mime()).build();
    }
    private File file(Uri uri){
        String id=uri.getLastPathSegment();
        if(id==null||!id.matches("[a-f0-9-]{36}"))throw new IllegalArgumentException();
        return new File(new File(getContext().getCacheDir(),"outbox"),id);
    }
    public boolean onCreate(){return true;}
    public String getType(Uri u){return u.getQueryParameter("mime");}
    public ParcelFileDescriptor openFile(Uri u,String mode) throws FileNotFoundException{
        if(!"r".equals(mode))throw new FileNotFoundException();return ParcelFileDescriptor.open(file(u),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    public Cursor query(Uri u,String[] projection,String s,String[] args,String order){
        if(projection==null)projection=new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE};
        MatrixCursor cursor=new MatrixCursor(projection);MatrixCursor.RowBuilder row=cursor.newRow();
        for(String col:projection)row.add(OpenableColumns.DISPLAY_NAME.equals(col)?u.getQueryParameter("name"):OpenableColumns.SIZE.equals(col)?file(u).length():null);
        return cursor;
    }
    public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
    public int delete(Uri u,String s,String[] v){throw new UnsupportedOperationException();}
    public int update(Uri u,ContentValues v,String s,String[] args){throw new UnsupportedOperationException();}
}
