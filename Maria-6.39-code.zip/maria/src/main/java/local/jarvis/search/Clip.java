package local.jarvis.search;

import android.content.Context;
import android.graphics.*;
import android.net.Uri;
import android.util.Size;
import ai.onnxruntime.*;
import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import org.json.JSONObject;

/** TinyCLIP's two encoders share a normalized embedding space. */
final class Clip implements AutoCloseable {
    private final Context ctx;
    private final OrtEnvironment env=OrtEnvironment.getEnvironment();
    private final OrtSession vision;
    final float[] query,detailQuery,workplace,neutralFurniture;
    private final float[] landscape,chatScreen;
    static File asset(Context ctx,String name) throws IOException {
        File target=new File(ctx.getFilesDir(),(name.startsWith("clip/")?"vision-v2/":"content-v1/")+name);
        if (target.isFile()) return target;
        File parent=target.getParentFile();
        if (!parent.isDirectory() && !parent.mkdirs() && !parent.isDirectory()) throw new IOException("model directory");
        File tmp=File.createTempFile("asset",".part",parent);
        try {
            try (InputStream in=ctx.getAssets().open(name); OutputStream out=new FileOutputStream(tmp)) {
                byte[] buf=new byte[65536]; int n;
                while ((n=in.read(buf))!=-1) out.write(buf,0,n);
            }
            if (!tmp.renameTo(target) && !target.isFile()) throw new IOException("model copy");
        } finally { tmp.delete(); }
        return target;
    }
    Clip(Context ctx,String words) throws Exception {this(ctx,words,"",null);}
    Clip(Context ctx,String words,String detail,VideoTour tour) throws Exception {
        this.ctx=ctx;
        try (OrtSession.SessionOptions opt=new OrtSession.SessionOptions()) {
            opt.setIntraOpNumThreads(3); opt.setInterOpNumThreads(1);
            try (OrtSession encoder=env.createSession(asset(ctx,"clip/text.onnx").getPath(),opt)) {
                query=encode(encoder,words);
                boolean horses=words.equals("horses");
                landscape=horses?encode(encoder,"a landscape"):null;
                chatScreen=horses?encode(encoder,"a screenshot of a text conversation"):null;
                detailQuery=detail.isEmpty()?null:encode(encoder,detail);
                workplace=tour==null?null:encode(encoder,"industrial workplace with commercial equipment or a restaurant kitchen");
                neutralFurniture=tour!=null && tour.needsRed()?encode(encoder,"room with wooden cabinets or beige armchairs"):null;
            }
            vision=env.createSession(asset(ctx,"clip/vision.onnx").getPath(),opt);
        }
    }
    private float[] encode(OrtSession encoder,String words) throws Exception {
        long[] ids=tokenize(words); long[] mask=new long[ids.length]; Arrays.fill(mask,1);
        try (OnnxTensor tokens=OnnxTensor.createTensor(env,LongBuffer.wrap(ids),new long[]{1,ids.length});
             OnnxTensor att=OnnxTensor.createTensor(env,LongBuffer.wrap(mask),new long[]{1,ids.length})) {
            Map<String,OnnxTensor> input=new HashMap<>(); input.put("input_ids",tokens);
            if (encoder.getInputNames().contains("attention_mask")) input.put("attention_mask",att);
            try (OrtSession.Result r=encoder.run(input)) { return ((float[][])r.get(0).getValue())[0]; }
        }
    }
    private long[] tokenize(String prompt) throws Exception {
        JSONObject vocab=new JSONObject(new String(java.nio.file.Files.readAllBytes(asset(ctx,"clip/vocab.json").toPath()),StandardCharsets.UTF_8));
        Map<String,Integer> rank=new HashMap<>();
        try (BufferedReader r=new BufferedReader(new InputStreamReader(ctx.getAssets().open("clip/merges.txt"),StandardCharsets.UTF_8))) {
            r.readLine(); String line; while ((line=r.readLine())!=null) rank.put(line,rank.size());
        }
        boolean[] used=new boolean[256]; String[] alphabet=new String[256]; int extra=256;
        for(int i=0;i<256;i++) {
            used[i]=i>=33 && i<=126 || i>=161 && i<=172 || i>=174;
            alphabet[i]=String.valueOf((char)(used[i]?i:extra++));
        }
        List<Long> tokens=new ArrayList<>(); tokens.add(49406L);
        Matcher m=Pattern.compile("'s|'t|'re|'ve|'m|'ll|'d|[\\p{L}]+|[\\p{N}]|[^\\s\\p{L}\\p{N}]+").matcher(("a photo of "+prompt).toLowerCase(Locale.ROOT));
        while (m.find() && tokens.size()<76) {
            List<String> parts=new ArrayList<>();
            for(byte b:m.group().getBytes(StandardCharsets.UTF_8)) parts.add(alphabet[b&255]);
            int end=parts.size()-1; parts.set(end,parts.get(end)+"</w>");
            while(parts.size()>1) {
                int best=Integer.MAX_VALUE; String a=null,b=null;
                for(int i=1;i<parts.size();i++) {
                    int score=rank.getOrDefault(parts.get(i-1)+" "+parts.get(i),Integer.MAX_VALUE);
                    if(score<best){best=score;a=parts.get(i-1);b=parts.get(i);}
                }
                if(a==null) break;
                List<String> next=new ArrayList<>();
                for(int i=0;i<parts.size();i++) {
                    if(i+1<parts.size() && parts.get(i).equals(a) && parts.get(i+1).equals(b)){next.add(a+b);i++;}
                    else next.add(parts.get(i));
                }
                parts=next;
            }
            for(String part:parts) if(tokens.size()<76) tokens.add((long)vocab.getInt(part));
        }
        tokens.add(49407L); long[] ids=new long[tokens.size()];
        for(int i=0;i<ids.length;i++) ids[i]=tokens.get(i);
        return ids;
    }
    byte[] image(Uri uri) throws Exception {
        Bitmap raw=SelectedItems.thumbnail(ctx,uri,320);
        try { return embedding(raw); } finally { raw.recycle(); }
    }
    byte[] embedding(Bitmap raw) throws Exception {
        Bitmap scaled=Bitmap.createBitmap(224,224,Bitmap.Config.ARGB_8888);
        try {
            int side=Math.min(raw.getWidth(),raw.getHeight()),x=(raw.getWidth()-side)/2,y=(raw.getHeight()-side)/2;
            new Canvas(scaled).drawBitmap(raw,new Rect(x,y,x+side,y+side),new Rect(0,0,224,224),new Paint(Paint.FILTER_BITMAP_FLAG));
            int area=224*224; int[] pixels=new int[area]; scaled.getPixels(pixels,0,224,0,0,224,224);
            float[] data=new float[area*3];
            float[] mean={0.48145466f,0.4578275f,0.40821073f},std={0.26862954f,0.26130258f,0.27577711f};
            for(int c=0;c<3;c++) for(int i=0;i<area;i++)
                data[c*area+i]=(((pixels[i]>>(16-c*8))&255)/255f-mean[c])/std[c];
            try (OnnxTensor t=OnnxTensor.createTensor(env,FloatBuffer.wrap(data),new long[]{1,3,224,224});
                 OrtSession.Result r=vision.run(Collections.singletonMap("pixel_values",t))) {
                float[] vector=((float[][])r.get(0).getValue())[0];
                ByteBuffer out=ByteBuffer.allocate(vector.length*4).order(ByteOrder.LITTLE_ENDIAN);
                out.asFloatBuffer().put(vector); return out.array();
            }
        } finally { scaled.recycle(); }
    }
    double score(byte[] blob) {
        double similarity=score(blob,query);
        if(landscape!=null){
            // A weak subject match also occurs on scenery and chat screenshots.
            if(similarity<0.25 || similarity<0.015+Math.max(score(blob,landscape),score(blob,chatScreen)))return -1;
        }
        return similarity;
    }
    double score(byte[] blob,float[] query) {
        FloatBuffer vector=ByteBuffer.wrap(blob).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer();
        if (vector.remaining()!=query.length) return -1;
        double dot=0;
        for(float x:query) dot+=x*vector.get();
        return dot;
    }
    public void close() throws OrtException { vision.close(); }
}
