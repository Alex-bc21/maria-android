package local.jarvis.search;

import android.accounts.AuthenticatorException;
import java.io.IOException;
import java.net.*;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

final class DriveFailure {
    static final class Http extends IOException {
        final int status;
        Http(int status){super("HTTP "+status);this.status=status;}
    }
    private static boolean transientFailure(Exception e){
        if(e instanceof Http h)return h.status==408 || h.status==429 || h.status>=500;
        return e instanceof UnknownHostException || e instanceof SocketException || e instanceof SocketTimeoutException;
    }
    static <T> T readPage(Callable<T> read,Consumer<String> trace) throws Exception {
        try{return read.call();}
        catch(Exception e){
            if(!transientFailure(e))throw e;
            trace.accept("Google Диск · повтор чтения страницы · "+code(e));
            Thread.sleep(600);
            return read.call();
        }
    }
    static String code(Exception e){return e instanceof Http h?"HTTP "+h.status:e.getClass().getSimpleName();}
    static String notice(Exception e){
        String prefix="Поиск на Google Диске не завершён. ";
        if(e instanceof Http h){
            if(h.status==401)return prefix+"Google запросил повторный вход.";
            if(h.status==403)return prefix+"Google отказал в доступе к запросу.";
            if(h.status==429)return prefix+"Google временно ограничил запросы. Попробуйте позже.";
            if(h.status>=500)return prefix+"Сервис Google временно недоступен.";
        }
        if(e instanceof UnknownHostException)return prefix+"Телефон не смог определить сетевой адрес Google Диска (DNS). Повторите поиск.";
        if(e instanceof SocketTimeoutException || e instanceof Http h && h.status==408)return prefix+"Истекло время ожидания ответа Диска. Повторите поиск.";
        if(e instanceof SocketException)return prefix+"Прервалось сетевое соединение с Диском. Повторите поиск.";
        if(e instanceof AuthenticatorException)return prefix+"Не удалось подтвердить доступ к аккаунту.";
        return prefix+"Не удалось получить данные. Подробности в истории запроса.";
    }
}
