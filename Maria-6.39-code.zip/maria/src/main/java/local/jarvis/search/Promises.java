package local.jarvis.search;

import android.app.NotificationManager;
import android.app.job.JobScheduler;
import android.content.*;
import org.json.*;
import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

/** Object-bound commitments and their stable Android scheduler IDs. */
final class Promises {
    record Item(int id,String object,String note,long due,String state) {
        String label(){return "Обещание · "+note+" · "+when(due)+" · "+state;}
    }
    static final String WAIT="Ожидает напоминания",QUEUED="Запланировано",SENT="Напоминание доставлено",
            DONE="Выполнено",CANCEL="Отменено",MISSED="Уведомления отключены";
    static String when(long due){return DateTimeFormatter.ofPattern("d MMMM 'в' HH:mm",Locale.forLanguageTag("ru"))
            .withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(due));}
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences("promises",0);}
    static List<Item> all(Context c){
        List<Item> items=new ArrayList<>();
        for(var entry:prefs(c).getAll().entrySet()){
            try{JSONObject j=new JSONObject((String)entry.getValue());
                items.add(new Item(Integer.parseInt(entry.getKey()),j.getString("object"),j.getString("note"),j.getLong("due"),j.getString("state")));
            }catch(JSONException|NumberFormatException ignored){}
        }
        return items;
    }
    static boolean active(Item item){return !item.state.equals(DONE)&&!item.state.equals(CANCEL);}
    static Item get(Context c,int id){return all(c).stream().filter(i->i.id==id).findFirst().orElse(null);}
    static List<Item> forObject(Context c,String name){
        List<Item> found=all(c);found.removeIf(i->!i.object.equals(name));found.sort(Comparator.comparingLong(Item::due));return found;
    }
    private static boolean write(Context c,Item i,String state){
        try{
            return prefs(c).edit().putString(String.valueOf(i.id),new JSONObject().put("object",i.object)
                    .put("due",i.due).put("note",i.note).put("state",state).toString()).commit();
        }catch(JSONException e){throw new IllegalStateException(e);}
    }
    static synchronized boolean save(Context c,String object,String note,long due){
        Item item=null;
        for(Item i:forObject(c,object)){
            if(i.due==due&&i.note.equalsIgnoreCase(note)&&!i.state.equals(CANCEL)){item=i;break;}
        }
        if(item==null){
            int id;
            do{id=1_100_000_000+new Random().nextInt(900_000_000);}while(prefs(c).contains(String.valueOf(id)));
            item=new Item(id,object,note,due,WAIT);
            if(!write(c,item,WAIT))return false;
        }
        if(item.state.equals(DONE)||item.state.equals(SENT))return true;
        if(register(c,item))return true;
        if(c.getSystemService(JobScheduler.class).getPendingJob(item.id)==null && item.state.equals(WAIT))
            prefs(c).edit().remove(String.valueOf(item.id)).commit();
        return false;
    }
    private static boolean register(Context c,Item i){
        var scheduler=c.getSystemService(JobScheduler.class);
        if(scheduler.getPendingJob(i.id)==null && !Reminder.schedule(c,i.object,i.note,i.due,true,false,i.id))return false;
        return write(c,i,QUEUED);
    }
    static synchronized boolean move(Context c,Item i,long due){
        Item current=get(c,i.id);if(current==null||!active(current))return false;
        if(due<=System.currentTimeMillis()||!Reminder.schedule(c,i.object,i.note,due,true,false,i.id))return false;
        if(write(c,new Item(i.id,i.object,i.note,due,QUEUED),QUEUED)){
            c.getSystemService(NotificationManager.class).cancel(i.id);return true;
        }
        c.getSystemService(JobScheduler.class).cancel(i.id);
        if(current.state.equals(QUEUED)||current.state.equals(WAIT))register(c,current);
        return false;
    }
    static synchronized void recover(Context c){
        for(Item i:all(c))if(i.state.equals(WAIT)||
                i.state.equals(QUEUED)&&c.getSystemService(JobScheduler.class).getPendingJob(i.id)==null)register(c,i);
    }
    static String review(Context c,String person){
        List<Item> active=all(c);active.removeIf(i->i.state.equals(DONE)||i.state.equals(CANCEL)||
                !(" "+Showing.clean(i.note)+" ").contains(person.isEmpty()?" ":" "+Showing.clean(person)+" "));
        active.sort(Comparator.comparingLong(Item::due));
        if(active.isEmpty())return "Открытых обещаний"+(person.isEmpty()?"":" по запросу «"+person+"»")+" нет.";
        List<String> lines=new ArrayList<>();for(Item i:active)lines.add(i.object+" · "+i.label());return String.join("\n",lines);
    }
    static synchronized boolean mark(Context c,int id,String state){
        for(Item i:all(c))if(i.id==id){
            if(state.equals(SENT)&&(i.state.equals(CANCEL)||i.state.equals(DONE)))return false;
            boolean saved=write(c,i,state);
            if(saved&&(state.equals(CANCEL)||state.equals(DONE))){
                c.getSystemService(JobScheduler.class).cancel(id);c.getSystemService(NotificationManager.class).cancel(id);
            }
            return saved;
        }
        return false;
    }
}
