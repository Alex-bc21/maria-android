package local.jarvis.search;

import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import java.util.*;
import java.util.regex.*;

final class ScreenItem {
    static final String ACTION="local.jarvis.search.SCREEN";
    static String displayName(Context c,Uri uri){
        if(uri!=null)try(var rows=c.getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(rows!=null && rows.moveToFirst() && rows.getString(0)!=null){
                String name=rows.getString(0).replaceAll("[\\p{Cc}\\p{Cf}]"," ").strip();
                if(!name.isEmpty())return name.substring(0,Math.min(180,name.length()));
            }
        }catch(RuntimeException unavailable){}
        return "Файл без названия";
    }
    private static ScreenItem waiting;
    private static String key;
    final long created=SystemClock.elapsedRealtime();
    String text="";
    String origin="", article, readingNotice="";
    long articleTurn;
    Bitmap picture;
    Uri uri;

    static String offer(ScreenItem item){
        waiting=item;
        String id=UUID.randomUUID().toString();key=id;
        new Handler(Looper.getMainLooper()).postDelayed(()->take(id),90000);
        return id;
    }
    static boolean pending(){return waiting!=null;}
    static ScreenItem take(String id){
        if(id==null || !id.equals(key))return null;
        ScreenItem result=waiting;waiting=null;key=null;return result;
    }
    static boolean safe(Context c,Uri u){
        if(u==null || !"content".equals(u.getScheme()) || u.getAuthority()==null || u.getAuthority().contains("@")
            || u.getAuthority().startsWith(c.getPackageName()) || u.getPath()==null || u.getPath().isEmpty())return false;
        return c.checkUriPermission(u,android.os.Process.myPid(),android.os.Process.myUid(),Intent.FLAG_GRANT_READ_URI_PERMISSION)==android.content.pm.PackageManager.PERMISSION_GRANTED
            || "media".equals(u.getAuthority()) && u.getPath().matches("/(?:external(?:_primary)?|internal)/(?:images|video|audio)/media/[0-9]+");
    }
    Bitmap image(Context c) throws Exception {
        Bitmap b=picture;
        if(b==null && uri!=null && Objects.toString(c.getContentResolver().getType(uri),"").startsWith("image/")){
            b=ImageDecoder.decodeBitmap(ImageDecoder.createSource(c.getContentResolver(),uri),(decoder,info,src)->{
                int side=Math.max(info.getSize().getWidth(),info.getSize().getHeight());
                decoder.setTargetSampleSize(Math.max(1,(side+2399)/2400));decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            });
        }
        return b;
    }
    String read(Context c) throws Exception {
        Bitmap b=image(c);
        if(b==null)return text;
        try(ContentIndex index=new ContentIndex(c,new ContentRequest(false,""),0)){
            Bitmap software=b.getConfig()==Bitmap.Config.HARDWARE?b.copy(Bitmap.Config.ARGB_8888,false):b;
            try{return text+"\n"+index.screenText(software);}finally{if(software!=b)software.recycle();}
        }finally{if(b!=picture)b.recycle();}
    }
    static boolean describes(String command){
        String q=command.toLowerCase(Locale.ROOT).replaceAll("[,.:!—?]+"," ").replaceAll("\\s+"," ").strip()
                .replaceFirst("^(?:мария|мари|джарвис) ","").replaceFirst("^пожалуйста ","").replaceFirst(" пожалуйста$","");
        String surface="(?:на (?:мо[её]м |этом )?(?:экране|скриншоте|скрине)|на дисплее)";
        return q.matches("(?:(?:расскажи|скажи|объясни|прочитай|опиши|посмотри|покажи)(?: мне)? )?что (?:ты )?(?:сейчас )?(?:(?:видишь|видно|написано|изображено|показано|открыто|происходит) )?(?:у меня )?"+surface+"(?: (?:видно|написано|изображено|показано|открыто|происходит))?")
                || q.matches("(?:опиши|прочитай|покажи|разбери)(?: мне)? (?:этот |мой |текущий )?(?:экран|скриншот|скрин|(?:текст|содержимое) "+surface+")");
    }
    static String excerpt(String raw){
        Set<String> seen=new LinkedHashSet<>();
        int length=0;
        for(String part:raw.split("\\R")){
            String line=part.strip().replaceAll("\\s+"," ");
            if(line.length()<2 || !line.matches(".*\\p{L}{2}.*"))continue;
            if(line.length()>140)line=line.substring(0,137)+"…";
            if(seen.add(line))length+=line.length();
            if(seen.size()>=5 || length>=250)break;
        }
        return seen.isEmpty()?"":"«"+String.join("», «",seen)+"»";
    }
    private static final Pattern NUMBER=Pattern.compile("(?<![\\p{L}\\d])\\+?\\d(?:[ ()\\u00a0\\-–]*\\d){6,14}(?!\\d)");
    private static final Pattern STREET=Pattern.compile("(?iu)(?:\\bул(?:ица)?\\.|\\bвул(?:иця)?\\.|\\b(?:улица|вулиця|проспект|бульвар|переулок|провулок|шоссе|шосе)\\b|\\bпр-т\\b)");
    static List<String> candidates(String text,boolean number){
        Map<String,String> out=new LinkedHashMap<>();
        for(String raw:text.split("\\R")){
            String line=raw.strip();if(line.isEmpty() || line.length()>350)continue;
            if(number){
                Matcher m=NUMBER.matcher(line);
                while(m.find()){String value=m.group().strip();out.putIfAbsent(value.replaceAll("\\D",""),value);}
            }else{
                Matcher label=Pattern.compile("(?iu)\\b(?:адрес(?:а)?|address)\\s*[:：]\\s*(.+)").matcher(line);
                if(label.find())line=label.group(1).strip();
                else if(!STREET.matcher(line).find() || !line.matches(".*\\d.*"))continue;
                line=line.split("(?iu)\\s+(?:тел(?:ефон)?[.:]|номер[:])",2)[0].strip();
                if(!line.isEmpty())out.putIfAbsent(line.toLowerCase(Locale.ROOT),line);
            }
        }
        return new ArrayList<>(out.values());
    }
    static String recipient(String value){
        String name=value.replaceFirst("(?iu)\\s+(?:через|в)\\s+(?:telegram|телеграм[ме]?)\\s*$","").strip();
        return switch(name.toLowerCase(Locale.ROOT)){
            case "анне","анну" -> "Анна";case "маме" -> "Мама";case "папе" -> "Папа";
            case "марии" -> "Мария";case "ольге" -> "Ольга";case "ивану" -> "Иван";
            default -> name;
        };
    }
}
