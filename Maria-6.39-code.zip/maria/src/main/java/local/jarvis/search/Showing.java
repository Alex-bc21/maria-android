package local.jarvis.search;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import java.util.*;

final class Showing {
    private static final long WINDOW=3*60*60_000L;
    static String clean(String s){return s.toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("[^\\p{L}\\d]+"," ").strip();}
    static String active(Context c){
        var p=c.getSharedPreferences("showing",0);long age=System.currentTimeMillis()-p.getLong("start",0);
        return age>=0&&age<=WINDOW?p.getString("name",""):"";
    }
    static void start(Context c,String name){
        c.getSharedPreferences("showing",0).edit().putString("name",name).putLong("start",System.currentTimeMillis()).apply();
    }
    static long calendarId(Context c){return c.getSharedPreferences("showing",0).getLong("calendar",-1);}
    static void chooseCalendar(SearchActivity a){
        Map<Long,String> choices=new LinkedHashMap<>();choices.put(-1L,"Все видимые календари");
        try(Cursor rows=a.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI,new String[]{"_id","calendar_displayName","account_name"},"visible=1",null,"calendar_displayName")){
            if(rows!=null)while(rows.moveToNext())choices.put(rows.getLong(0),rows.getString(1)+" · "+rows.getString(2));
        }catch(RuntimeException e){a.reply("Не удалось прочитать календари.");return;}
        List<Long> ids=new ArrayList<>(choices.keySet());
        new android.app.AlertDialog.Builder(a).setTitle("Календарь показов").setSingleChoiceItems(choices.values().toArray(new String[0]),ids.indexOf(calendarId(a)),(d,i)->{
            a.getSharedPreferences("showing",0).edit().putLong("calendar",ids.get(i)).apply();d.dismiss();a.reply("Выбрано: "+choices.get(ids.get(i))+".");
        }).setNegativeButton("Закрыть",null).show();
    }
    private static Cursor instances(Context c,long from,long to,String order){
        return instances(c,from,to,order,calendarId(c));
    }
    private static Cursor instances(Context c,long from,long to,String order,long id){
        Uri.Builder range=CalendarContract.Instances.CONTENT_URI.buildUpon();ContentUris.appendId(range,from);ContentUris.appendId(range,to);
        return c.getContentResolver().query(range.build(),new String[]{"title","eventLocation","begin","end","allDay","eventStatus","visible","selfAttendeeStatus","event_id"},
                id<0?null:"calendar_id=?",id<0?null:new String[]{Long.toString(id)},order);
    }
    record Meeting(long id,String title,String address,long begin,long end,boolean allDay){}
    static List<Meeting> today(Context c,long now){
        var zone=java.time.ZoneId.systemDefault();var date=java.time.Instant.ofEpochMilli(now).atZone(zone).toLocalDate();
        long start=date.atStartOfDay(zone).toInstant().toEpochMilli(),end=date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli();
        long utcStart=date.atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli(),utcEnd=utcStart+86400000L;
        List<Meeting> meetings=new ArrayList<>();
        try(Cursor r=instances(c,Math.min(start,utcStart),Math.max(end,utcEnd)-1,"begin ASC",-1)){
            if(r==null)throw new IllegalStateException("Calendar unavailable");
            while(r.moveToNext()){
                if(!included(r))continue;
                boolean allDay=r.getInt(4)!=0;long begin=r.getLong(2),finish=r.getLong(3);
                long left=allDay?utcStart:start,right=allDay?utcEnd:end;
                if(begin>=right||finish<=left)continue;
                meetings.add(new Meeting(r.getLong(8),Objects.toString(r.getString(0),"Встреча"),Objects.toString(r.getString(1),""),begin,finish,allDay));
            }
        }
        meetings.sort(Comparator.comparing(Meeting::allDay).reversed().thenComparingLong(Meeting::begin));return meetings;
    }
    private static boolean included(Cursor r){return r.getInt(6)!=0&&r.getInt(5)!=CalendarContract.Events.STATUS_CANCELED&&r.getInt(7)!=CalendarContract.Attendees.ATTENDEE_STATUS_DECLINED;}
    private static boolean isShowing(String title){return clean(title).matches(".*\\b(?:показ|просмотр|перегляд)\\b.*");}
    static void agenda(SearchActivity a,boolean route){
        long now=System.currentTimeMillis();
        long today=java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();
        long tomorrow=java.time.LocalDate.now().plusDays(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();
        new Thread(()->{
            List<String> entries=new ArrayList<>();Map<String,String> addresses=new LinkedHashMap<>();long first=-1;
            try(Cursor r=instances(a,route?now:today,route?now+7L*86400000:tomorrow-1,"begin ASC")){
                if(r!=null)while(r.moveToNext()){
                    if(!included(r))continue;String name=Objects.toString(r.getString(0),"Встреча"),address=Objects.toString(r.getString(1),"").strip();
                    if(route && (r.getLong(2)<now||r.getInt(4)!=0||!isShowing(name)))continue;
                    if(route && first!=-1 && first!=r.getLong(2))break;
                    first=r.getLong(2);
                    String label=(r.getInt(4)==0?Promises.when(first):"Весь день")+" · "+name+(address.isEmpty()?"":" · "+address);
                    entries.add(label);addresses.put(label,address);
                }
            }catch(RuntimeException e){a.runOnUiThread(()->{if(!a.isDestroyed())a.reply("Не удалось прочитать календарь.");});return;}
            a.runOnUiThread(()->{
                if(a.isFinishing()||a.isDestroyed())return;
                if(!route||entries.isEmpty()){a.reply(entries.isEmpty()?(route?"На ближайшие семь дней показов не найдено.":"На сегодня встреч нет."):String.join("\n",entries));return;}
                java.util.function.Consumer<String> open=key->{
                    String address=addresses.get(key);
                    if(address.isEmpty()){a.reply("У встречи «"+key+"» не указан адрес.");return;}
                    try{a.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("google.navigation:q="+Uri.encode(address))));}
                    catch(ActivityNotFoundException e){
                        try{a.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+Uri.encode(address))));}
                        catch(ActivityNotFoundException missing){a.reply("Адрес следующего показа: "+address);}
                    }
                };
                if(addresses.size()==1)open.accept(entries.get(0));
                else new android.app.AlertDialog.Builder(a).setTitle("К какому показу ехать?").setItems(entries.toArray(new String[0]),(d,i)->open.accept(entries.get(i))).show();
            });
        },"jarvis-agenda").start();
    }
    static List<String> recent(Context c){
        long now=System.currentTimeMillis();
        Set<String> names=c.getSharedPreferences("objects",0).getAll().keySet();
        Set<String> results=new LinkedHashSet<>();
        try(Cursor rows=instances(c,now-WINDOW,now+1,"end DESC")){
            if(rows==null)return List.of();
            while(rows.moveToNext()){
                String title=Objects.toString(rows.getString(0),""),location=Objects.toString(rows.getString(1),"").strip();
                if(rows.getLong(2)>now||rows.getLong(3)<now-WINDOW||rows.getInt(4)!=0||!included(rows)||!isShowing(title))continue;
                String where=" "+clean(location+" "+title)+" ";
                List<String> matching=new ArrayList<>();for(String name:names)if(where.contains(" "+clean(name)+" "))matching.add(name);
                if(!matching.isEmpty())results.addAll(matching);else if(!location.isBlank())results.add(location);
                else results.add(""); // An unidentified showing makes an automatic choice ambiguous.
            }
        }
        return new ArrayList<>(results);
    }
}
