package local.jarvis.search;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import java.util.*;

/** Public Android entry. Never forward an incoming intent, command, or task flags. */
public final class EntryActivity extends Activity {
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        Intent incoming=getIntent(), next=new Intent(this,SearchActivity.class);
        try{
            if(Intent.ACTION_MAIN.equals(incoming.getAction())){
                next.setAction(Intent.ACTION_MAIN);
            }else if(Intent.ACTION_SEND.equals(incoming.getAction()) || Intent.ACTION_SEND_MULTIPLE.equals(incoming.getAction())){
                next.setAction(incoming.getAction()).setType(incoming.getType());
                ArrayList<Uri> accepted=new ArrayList<>();
                if(Intent.ACTION_SEND.equals(incoming.getAction())){
                    Object item=incoming.getParcelableExtra(Intent.EXTRA_STREAM);
                    add(accepted,item);
                }else{
                    ArrayList<?> batch=incoming.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                    if(batch!=null && batch.size()<=100)for(Object item:batch)add(accepted,item);
                }
                if(!accepted.isEmpty()){
                    ClipData grants=ClipData.newRawUri("file",accepted.get(0));
                    for(int i=1;i<accepted.size();i++)grants.addItem(new ClipData.Item(accepted.get(i)));
                    next.setClipData(grants);next.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    if(Intent.ACTION_SEND.equals(next.getAction()))next.putExtra(Intent.EXTRA_STREAM,accepted.get(0));
                    else next.putParcelableArrayListExtra(Intent.EXTRA_STREAM,accepted);
                }
                String text=incoming.getStringExtra(Intent.EXTRA_TEXT);
                if(text!=null && text.length()<=32000)next.putExtra(Intent.EXTRA_TEXT,text);
                if(accepted.isEmpty()&&!next.hasExtra(Intent.EXTRA_TEXT))return;
            }else return;
            next.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(next);
        }catch(RuntimeException invalid){ /* Drop unreadable or malformed input. */ }
        finally{finish();}
    }
    private void add(ArrayList<Uri> accepted,Object item){
        if(!(item instanceof Uri uri)||!"content".equals(uri.getScheme())||uri.getAuthority()==null
                ||uri.getAuthority().equals(ShareFiles.AUTH)||uri.getAuthority().contains("@"))return;
        if(checkUriPermission(uri,android.os.Process.myPid(),android.os.Process.myUid(),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION)==android.content.pm.PackageManager.PERMISSION_GRANTED)accepted.add(uri);
    }
}


