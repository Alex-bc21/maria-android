package local.jarvis.search;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.*;

record MediaClue(String text,String period){
    static final int ASK_AT=12;
    private static final String[] MONTHS={"январь","февраль","март","апрель","май","июнь","июль","август","сентябрь","октябрь","ноябрь","декабрь"};
    private static final Pattern DATE=Pattern.compile("(?<![\\p{L}\\d])(?:(?:за|от|в) )?(?:(сегодня|вчера|позавчера|прошлую неделю|последнюю неделю|неделю)|(?:(\\d{1,2}) )?(январ[ьяе]|феврал[ьяе]|март[ае]?|апрел[ьяе]|ма[йея]|июн[ьяе]|июл[ьяе]|август[ае]?|сентябр[ьяе]|октябр[ьяе]|ноябр[ьяе]|декабр[ьяе])(?: (\\d{4}))?)(?![\\p{L}\\d])");
    static MediaClue parse(String raw){
        String words=raw.toLowerCase(Locale.ROOT).replaceAll("[,.!?]+"," ").replaceAll("\\s+"," ").strip();
        Matcher m=DATE.matcher(words);String period="";
        if(m.find()){
            if(m.group(1)!=null)period=m.group(1).endsWith("неделю")?"неделю":m.group(1);
            else{
                String name=m.group(3);
                int month=5;
                if(!name.matches("ма[йея]")){
                    month=1;while(month<12 && !name.startsWith(MONTHS[month-1].substring(0,3)))month++;
                }
                LocalDate now=LocalDate.now();int year=m.group(4)==null?now.getYear()-(month>now.getMonthValue()?1:0):Integer.parseInt(m.group(4));
                try{period=m.group(2)==null?MONTHS[month-1]+" "+year:LocalDate.of(year,month,Integer.parseInt(m.group(2))).toString();}
                catch(DateTimeException invalid){return new MediaClue(words,"");}
            }
            words=(words.substring(0,m.start())+" "+words.substring(m.end())).strip();
        }
        words=words.replaceFirst("^(?:(?:кажется|помню|что|примерно|это|вроде|там|на н[её]м|на ней|в кадре|где|был[аои]?|видно|виден|видна|снято|снимал[аи]?|снял[аи]?|я|с)\\s+)*","").strip();
        if(words.matches("(?:это |я )?(?:снят[оаы]?|снимал[аи]?|был[оаи]?|там|примерно|кажется)"))words="";
        return new MediaClue(words,period);
    }
    static boolean newCommand(String q){
        return q.matches("(?iu)^(?:(?:а|ну|джарвис|пожалуйста)[, ]+)*(?:найди|найти|поищи|ищи|покажи|открой|открыть|поделись|включи|выключи|запусти|напомни|запиши|скажи|проверь|какие|как|почему|сколько|где|что|кто|расскажи|объясни|переведи|поставь|запиши|закрой)(?:[ ,!?].*|$)");
    }
    String query(String previous,boolean video){
        if(text.isEmpty())return previous;
        ContentRequest prior=ContentRequest.parse(previous);
        String type=video?"видео":"фото";
        if(prior!=null && prior.lettering())return "фото со словами "+prior.terms()+" "+text;
        if(prior!=null)return type+", где "+prior.terms()+" и "+text;
        if(!video && text.matches("(?:надпись|написано|со словами|слова|с текстом) .+"))return "фото со словами "+text.substring(text.indexOf(' ')+1).replaceFirst("^(?:словами|текстом) ","");
        return type+", где "+text;
    }
    static String googlePeriod(String period){
        if(period.matches("\\d{4}-\\d\\d-\\d\\d"))return LocalDate.parse(period).format(DateTimeFormatter.ofPattern("d MMMM yyyy",Locale.forLanguageTag("ru")));
        return period;
    }
}
