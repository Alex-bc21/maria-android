package local.jarvis.search;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;
import java.util.regex.*;

/** Navigation requested for the app under the assistant. Labels and view trees stay on the phone. */
record ScreenNavigation(String direction,String label) {
    private static final Pattern SCROLL=Pattern.compile("(?:прокрути|пролистай|листни|прокрутить|пролистни|гортай|прокрути сторінку)(?: экран| страницу| список| сторінку)?(?: чуть| немного)? (вниз|вверх|ниже|выше|вгору|вниз)");
    private static final Pattern TAP=Pattern.compile("(?:нажми|тапни|кликни|коснись|ткни|натисни)(?: (?:на|по))?(?: (?:кнопку|кнопке|кнопки|вкладку|пункт|посилання))? (.{1,80})");
    private static String clean(String s){return s.toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("\\s+"," ").strip();}
    static ScreenNavigation simple(String request){
        String q=clean(request).replaceFirst("^(?:мария|мари)[ ,]+","").replaceFirst("^пожалуйста[, ]+","").replaceFirst("[.!]+$","");
        String[] parts=q.split(",? (?:и затем|а затем|затем|и потом|и) ",2);
        Matcher scroll=SCROLL.matcher(parts[0]);
        String dir="";
        if(scroll.matches())dir=scroll.group(1).matches("вверх|выше|вгору")?"up":"down";
        if(parts.length==2 && dir.isEmpty())return null;
        if(!dir.isEmpty() && parts.length==1)return new ScreenNavigation(dir,"");
        Matcher tap=TAP.matcher(parts[parts.length-1]);
        if(!tap.matches())return null;
        return validated(dir,tap.group(1),q);
    }
    static ScreenNavigation fromPlan(String argument,String request){
        String[] fields=argument.split("\\|",-1);
        if(fields.length!=2 || !Set.of("down","up","").contains(fields[0]))return null;
        return validated(fields[0],fields[1],request);
    }
    private static ScreenNavigation validated(String dir,String text,String request){
        String label=clean(text).replaceAll("^[«\"“]+|[»\"”]+$","").strip();
        if(label.isEmpty())return dir.isEmpty()?null:new ScreenNavigation(dir,"");
        if(label.length()>80 || !label.matches("[\\p{L}\\p{N}][\\p{L}\\p{N} .,’'():/!?+-]*") ||
            !clean(request).contains(label))return null;
        return new ScreenNavigation(dir,label);
    }
    String description(){return (direction.isEmpty()?"":"Прокрутить "+(direction.equals("down")?"вниз":"вверх"))+
        (direction.isEmpty()||label.isEmpty()?"":", затем ")+(label.isEmpty()?"":"Нажать «"+label+"»");}

    record Result(boolean ok,String notice){}
    private static final Pattern MANUAL=Pattern.compile("отправ|відправ|надісл|надіш|подтверд|підтверд|удал|видал|очист|разреш|дозвол|купить|купити|оплат|сплат|перевести|переказ|установить|увійти|войти|парол|send|submit|confirm|delete|remove|allow|grant|install|purchase|pay\\b|transfer|sign.?in|password",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);
    boolean manualLabel(){return MANUAL.matcher(label).find();}
    Result run(AccessibilityNodeInfo root,boolean scrolling){
        // Only an unambiguous visible control in the current source window may receive a tap.
        Set<AccessibilityNodeInfo> buttons=new HashSet<>();
        List<AccessibilityNodeInfo> panels=new ArrayList<>();
        ArrayDeque<AccessibilityNodeInfo> queue=new ArrayDeque<>();queue.add(root);
        int action=direction.equals("up")?AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD:AccessibilityNodeInfo.ACTION_SCROLL_FORWARD;
        for(int count=0;!queue.isEmpty();count++){
            if(count>=2400)return new Result(false,"Слишком много элементов. Уточните нужный раздел.");
            var n=queue.remove();
            if(!n.isVisibleToUser()||!n.isEnabled())continue;
            if(n.isPassword())return new Result(false,"На этом экране есть поле пароля. Управление оставляю вам.");
            if(scrolling && n.isScrollable() && (n.getActions()&action)!=0)panels.add(n);
            if(!scrolling && (label.equals(clean(Objects.toString(n.getText(),""))) ||
                    label.equals(clean(Objects.toString(n.getContentDescription(),""))))){
                var b=n;
                while(b!=null && !b.isClickable())b=b.getParent();
                if(b!=null && b.isVisibleToUser() && b.isEnabled())buttons.add(b);
            }
            for(int i=0;i<n.getChildCount();i++){var child=n.getChild(i);if(child!=null)queue.add(child);}
        }
        if(scrolling){
            // Prefer a vertical surface and use the largest visible viewport.
            AccessibilityNodeInfo best=null;long area=0;
            for(var p:panels){
                Rect rect=new Rect();p.getBoundsInScreen(rect);
                if(rect.isEmpty() || Objects.toString(p.getClassName(),"").contains("HorizontalScroll"))continue;
                long size=(long)rect.width()*rect.height();
                if(size>area){area=size;best=p;}
            }
            if(best==null || !best.performAction(action))return new Result(false,"Дальше в эту сторону прокрутить не удалось.");
            return new Result(true,direction.equals("up")?"Прокрутила вверх.":"Прокрутила вниз.");
        }
        if(buttons.size()!=1)return new Result(false,buttons.isEmpty()?"На экране нет доступной кнопки «"+label+"».":"На экране несколько кнопок «"+label+"». Выберите нужную вручную.");
        var button=buttons.iterator().next();
        if(manualLabel() || manualControl(button))return new Result(false,"Последнее нажатие оставляю вам.");
        return button.performAction(AccessibilityNodeInfo.ACTION_CLICK)?new Result(true,"Нажала «"+label+"»."):new Result(false,"Приложение отклонило нажатие.");
    }
    static boolean manualControl(AccessibilityNodeInfo button){
        ArrayDeque<AccessibilityNodeInfo> nodes=new ArrayDeque<>();nodes.add(button);
        for(int i=0;!nodes.isEmpty();i++){
            if(i>=100)return true;
            var n=nodes.remove();
            if(n.isPassword() || n.isCheckable() || MANUAL.matcher(Objects.toString(n.getText(),"")+" "+Objects.toString(n.getContentDescription(),"")+" "+Objects.toString(n.getViewIdResourceName(),"")).find())return true;
            for(int j=0;j<n.getChildCount();j++){var c=n.getChild(j);if(c!=null)nodes.add(c);}
        }
        return false;
    }
}
