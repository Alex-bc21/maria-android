package local.jarvis.search;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;

public final class JournalReader extends ContentProvider {
    public boolean onCreate(){return true;}
    public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){
        if(Binder.getCallingUid()!=2000 || !"/events".equals(uri.getPath()))throw new SecurityException();
        String after=uri.getQueryParameter("after");
        return SearchJournal.get(getContext()).read(after==null?0:Long.parseLong(after));
    }
    public String getType(Uri uri){return null;}
    public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
    public int update(Uri uri,ContentValues values,String selection,String[] args){throw new UnsupportedOperationException();}
    public int delete(Uri uri,String selection,String[] args){throw new UnsupportedOperationException();}
}