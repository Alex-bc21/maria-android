package local.jarvis.search;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

/** A single painted character, articulated in portrait coordinates (512 x 512). */
final class CharacterRig {
    static final class Art {
        final Bitmap body;
        final Bitmap[] leftLids=new Bitmap[13],rightLids=new Bitmap[13],lips;
        Art(Bitmap body,Bitmap eyelids,Bitmap mouth){
            this.body=body;lips=frames(mouth);
            int h=eyelids.getHeight()/leftLids.length;
            for(int i=0;i<leftLids.length;i++){
                leftLids[i]=Bitmap.createBitmap(eyelids,0,i*h,112,h);
                rightLids[i]=Bitmap.createBitmap(eyelids,112,i*h,eyelids.getWidth()-112,h);
            }
        }
        private static Bitmap[] frames(Bitmap strip){
            Bitmap[] frames=new Bitmap[13];
            int h=strip.getHeight()/frames.length;
            for(int i=0;i<frames.length;i++)frames[i]=Bitmap.createBitmap(strip,0,i*h,strip.getWidth(),h);
            return frames;
        }
    }
    private final Art art;
    private final Paint brush=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private final float[] mesh=new float[2*27*27];
    private float look,lookY,tilt,breath,hair,jaw,round,brow,beat,nod,lean,shoulder,gesture;
    private AuraView.Mode previous;
    private long entered,greetedAt=-6000;
    private long last=-1,reactionAt=-5000;
    private boolean happy;
    CharacterRig(Art art){this.art=art;}
    void greet(long now){greetedAt=now;}
    void react(boolean success,long now){happy=success;reactionAt=now;}
    private static float saturate(float x){return Math.max(0,Math.min(1,x));}
    private static float smooth(float x){x=saturate(x);return x*x*(3-2*x);}
    private static float near(float x,float y,float cx,float cy,float rx,float ry){
        float dx=(x-cx)/rx,dy=(y-cy)/ry;
        float v=Math.max(0,1-dx*dx-dy*dy);return v*v;
    }
    private static float wave(double phase){return (float)Math.sin(phase);}
    private static float blink(float t){
        if(t<0 || t>.23f)return 0;
        return t<.083f?smooth(t/.083f):1-smooth((t-.083f)/.147f);
    }
    void draw(Canvas c,int w,int h,long now,AuraView.Mode mode,float volume,float rounding,float mic,boolean motion){
        float dt=last<0?.016f:Math.min(.09f,Math.max(0,(now-last)*.001f));last=now;
        float fast=1-(float)Math.exp(-dt*25),slow=1-(float)Math.exp(-dt*5.5);
        float t=(now%180000)*.001f;
        boolean listen=mode==AuraView.Mode.LISTEN,think=mode==AuraView.Mode.WORK,speak=mode==AuraView.Mode.SPEAK;
        if(mode!=previous){previous=mode;entered=now;}
        float age=(now-entered)*.001f,hello=(now-greetedAt)*.001f;
        float reaction=motion?Math.max(0,1-(now-reactionAt)/1450f):0;
        float arrive=motion?(float)Math.exp(-age*2.4)*wave(age*8.2):0;
        // Ease into a small nod, then lift the chin and settle back to the speaking pose.
        float greeting=motion?smooth(hello/.30f)*(1-smooth((hello-.38f)/.50f)):0;
        float target=speak?volume:0;
        jaw+=(target-jaw)*(target>jaw?fast:1-(float)Math.exp(-dt*18));
        round+=((speak?rounding:0)-round)*fast;
        beat+=((speak?jaw:listen?mic:0)-beat)*slow;
        float blinkCycle=t%10.91f;
        float eyelid=motion?Math.max(Math.max(blink(blinkCycle-2.31f),blink(blinkCycle-6.8f)),blink(blinkCycle-7.13f)):0;
        float wink=happy?Math.max(0,1-Math.abs(reaction-.72f)/.22f):0;
        if(motion && hello>=0 && hello<2)wink=Math.max(wink,blink((hello-1.25f)*.70f));
        float glance=motion?wave(t*.92+wave(t*.48))*.36f:0;
        float desiredLook=think?.85f+.48f*wave(age*2.05):listen?-.5f:glance;
        float desiredTilt=(think?-.11f:listen?.125f:0)+(motion?.022f*wave(t*1.15):0)
                +reaction*(happy?-.125f:.085f)-.04f*greeting;
        if(speak && motion)desiredTilt+=.055f*wave(age*2.9)+.065f*arrive;
        float blend=motion?slow:1;
        look+=(desiredLook-look)*blend;
        lookY+=((think?-6f:listen?2.5f:0)-lookY)*blend;
        tilt+=(desiredTilt-tilt)*blend;
        brow+=((think?3:listen?6:0)+5*beat+6*reaction-brow)*blend;
        breath=motion?wave(t*1.72f):0;
        lean+=((listen?-9:think?7:0)-lean)*blend;
        shoulder+=((motion?4*wave(t*1.72+.55)+5*beat:0)-shoulder)*blend;
        hair+=(tilt*54+(motion?3.5f*wave(t*1.8f+.4f):0)-hair)*(motion?1-(float)Math.exp(-dt*3.8):1);
        gesture+=((speak?7f*beat:0)-gesture)*fast;
        float bob=happy?reaction*wave(reaction*9)*9:0;
        nod=motion?3*breath+(speak?-7*beat:listen?3*beat:0)+bob+8*greeting+(listen?9:5)*arrive:0;
        if(!motion){jaw=speak?.25f:0;round=0;hair=0;gesture=0;}
        float side=Math.min(w,h)*.96f;
        c.save();c.translate((w-side)/2,(h-side)/2);c.scale(side/512f,side/512f);
        layer(c,art.body,0,0,26,26);
        layer(c,art.leftLids[Math.round(12*saturate(Math.max(eyelid,wink)))],158,153,10,10);
        layer(c,art.rightLids[Math.round(12*saturate(eyelid))],270,153,10,10);
        layer(c,art.lips[Math.round(12*saturate(jaw))],226,272,14,8);
        c.restore();
    }
    private void layer(Canvas c,Bitmap texture,float left,float top,int cols,int rows){
        int k=0;
        for(int j=0;j<=rows;j++){
            float y=top+(float)texture.getHeight()*j/rows;
            float head=smooth((468-y)/114);
            float shoulders=near(256,y,256,432,400,82);
            for(int i=0;i<=cols;i++){
                float x=left+(float)texture.getWidth()*i/cols;
                float dx=-tilt*(y-387)*head+(look*3.4f+lean)*head;
                float dy=tilt*(x-256)*head+nod*head-breath*2.2f*shoulders-shoulder*(x-256)/220f*shoulders;
                dx+=hair*(near(x,y,108,282,92,125)+near(x,y,414,274,82,130));
                float iris=near(x,y,214,222,31,22)+near(x,y,319,211,32,22);
                dx+=look*5.8f*iris;dy+=lookY*iris;
                dy-=brow*(near(x,y,211,189,43,25)+.7f*near(x,y,318,173,43,25));
                float lips=near(x,y,281,303,59,45);
                dx-=(x-280)*round*.46f*lips;
                dy+=gesture*.4f*head+jaw*4*near(x,y,282,337,75,50);
                mesh[k++]=x+dx;mesh[k++]=y+dy;
            }
        }
        c.drawBitmapMesh(texture,cols,rows,mesh,0,null,0,brush);
    }
}
