package local.jarvis.search;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import java.time.*;
import java.util.*;
import java.util.regex.*;
import org.json.JSONArray;

final class PromiseDialog {
    static final int CALENDAR=22;
    private static final Pattern PROMISE=Pattern.compile("(?iu)^(?:(?:джарвис|jarvis)[, ]+)?(?:я )?обещал[аи]?\\s+(.+)$");
    private static final Pattern DAY=Pattern.compile("(?iu)\\b(послезавтра|завтра|сегодня)\\b");
    private static final Pattern CLOCK=Pattern.compile("(?iu)^(?:в |к |на )?(\\d{1,2})(?:[:. ](\\d{2}))?(?: час(?:а|ов)?)?(?: (утра|дня|вечера|ночи))?$");
    private final SearchActivity a;
    private final SharedPreferences draft;
    PromiseDialog(SearchActivity a){this.a=a;draft=a.getSharedPreferences("promise_draft",0);}
    boolean pending(){return draft.contains("note");}
    void clear(){draft.edit().clear().commit();}
    private static String normal(String raw){return raw.strip().replaceAll("[.!?,]+$","").strip();}
    private String obj(){return draft.getString("object","");}
    private String note(){return draft.getString("note","");}
    private static LocalDate day(String name){return day(name,LocalDate.now());}
    private static LocalDate day(String name,LocalDate reference){return reference.plusDays(name.equalsIgnoreCase("завтра")?1:name.equalsIgnoreCase("послезавтра")?2:0);}
    boolean handle(String raw,String noteObject){
        return handle(raw,noteObject,"",LocalDate.now());
    }
    void fromShowing(ShowingNotes.Entry entry){
        if(pending()){
            a.promiseReply("Сначала завершите текущее напоминание или скажите «отмена». Новое обещание сохранено в итогах показа.");
            return;
        }
        String promise=entry.promise().replaceFirst("(?iu)^(?:я )?обещал[аи]?\\s+","");
        String person=(" "+Showing.clean(promise)+" ").contains(" "+Showing.clean(entry.person())+" ")?"":entry.person()+" ";
        handle("Обещал "+person+promise,entry.object(),entry.id(),Instant.ofEpochMilli(entry.created()).atZone(ZoneId.systemDefault()).toLocalDate());
    }
    private boolean handle(String raw,String noteObject,String showingId,LocalDate reference){
        String s=normal(raw),lower=s.toLowerCase(Locale.ROOT);
        if(lower.matches("что я обещал(?:а)?(?: .+)?|(?:покажи )?мои обещания")){
            String person=lower.startsWith("что")?s.replaceFirst("(?iu)^что я обещала?\\s*",""):"";
            a.promiseReply(Promises.review(a,person));return true;
        }
        if(lower.matches("(?:начинаю|начни|начать) показ(?: объекта)? .+")){
            String name=s.replaceFirst("(?iu)^(?:начинаю|начни|начать) показ(?: объекта)? ","").strip();
            name=canonical(name);a.book.ensure(name);Showing.start(a,name);clear();a.promiseReply("Показ объекта «"+name+"». Обещания после показа привяжу к нему.");return true;
        }
        Matcher newPromise=PROMISE.matcher(s);
        if(newPromise.matches()){
            a.promiseActions.clear();
            String phrase=newPromise.group(1),object=noteObject.isEmpty()?Showing.active(a):noteObject;
            Matcher named=Pattern.compile("(?iu)\\s+по объекту\\s+(.+)$").matcher(phrase);
            if(named.find()){object=canonical(named.group(1));phrase=phrase.substring(0,named.start()).strip();}
            Matcher when=DAY.matcher(phrase);String date="";
            if(when.find()){date=day(when.group(),reference).toString();phrase=when.replaceFirst(" ").replaceAll("\\s+"," ").strip();}
            Matcher clock=Pattern.compile("(?iu)\\b(?:в|к) (?:\\d{1,2}(?:[:.]\\d{2})?|час|два|три|четыре|пять|шесть|семь|восемь|девять|десять|одиннадцать|двенадцать)(?: (?:утра|дня|вечера|ночи))?\\b").matcher(phrase);
            LocalTime given=null;
            if(clock.find()&&(given=time(clock.group()))!=null)phrase=clock.replaceFirst(" ").replaceAll("\\s+"," ").strip();
            if(phrase.isEmpty()){a.promiseReply("Что вы обещали сделать и кому? Повторите обещание целиком.");return true;}
            draft.edit().clear().putString("note",phrase).putString("date",date).putString("time",given==null?"":given.toString()).putString("object",object)
                    .putString("id",UUID.randomUUID().toString()).putString("showing",showingId).commit();
            if(!obj().isEmpty())ask();else if(a.checkSelfPermission(Manifest.permission.READ_CALENDAR)==PackageManager.PERMISSION_GRANTED)calendar();
            else {a.promiseReply("Могу определить объект по недавнему показу в календаре. Если пропустите доступ, назовите адрес.");a.requestPermissions(new String[]{Manifest.permission.READ_CALENDAR},CALENDAR);}
            return true;
        }
        if(!pending())return false;
        if(lower.matches("отмен[аи]|отмени обещание|не надо")){clear();a.promiseReply("Черновик обещания отменён.");return true;}
        if(obj().isEmpty()||lower.startsWith("по объекту ")||lower.startsWith("объект ")){
            if(s.isBlank()||time(lower)!=null||DAY.matcher(lower).matches()){ask();return true;}
            String name=s.replaceFirst("(?iu)^(?:объект|по объекту)\\s+","");
            List<String> options=new ArrayList<>();
            try{JSONArray saved=new JSONArray(draft.getString("options","[]"));for(int i=0;i<saved.length();i++)options.add(saved.getString(i));}
            catch(org.json.JSONException ignored){}
            int ordinal=switch(lower){case "первый","первое"->0;case "второй","второе"->1;case "третий","третье"->2;default->-1;};
            if(ordinal>=0){
                if(ordinal>=options.size()){ask();return true;}name=options.get(ordinal);
            }else{
                String term=Showing.clean(name);List<String> matches=new ArrayList<>();
                for(String candidate:options)if((" "+Showing.clean(candidate)+" ").contains(" "+term+" "))matches.add(candidate);
                if(matches.size()==1)name=matches.get(0);
                else if(matches.size()>1){a.promiseMessage("Подходят несколько адресов: "+String.join(", ",matches)+". Назовите улицу и номер дома.",true);return true;}
            }
            draft.edit().putString("object",canonical(name)).commit();ask();return true;
        }
        Matcher when=DAY.matcher(lower);String clock=lower;
        if(when.find()){
            draft.edit().putString("date",day(when.group()).toString()).commit();
            clock=when.replaceFirst("").strip().replaceFirst("^[, ]+","");
        }
        if(!clock.isEmpty()&&!clock.equals("повтори")){
            LocalTime t=time(clock);
            if(t==null){a.promiseMessage("Уточните время для «"+obj()+"», например «завтра в 10:30» или «в десять утра». Чтобы выйти, скажите «отмена».",true);return true;}
            draft.edit().putString("time",t.toString()).commit();
        }
        ask();return true;
    }
    private String canonical(String name){
        for(String known:a.getSharedPreferences("objects",0).getAll().keySet())if(Showing.clean(name).equals(Showing.clean(known)))return known;
        return name.strip();
    }
    void calendar(){
        if(!pending()||!obj().isEmpty())return;
        String id=draft.getString("id","");
        new Thread(()->{
            List<String> matches;
            try{matches=Showing.recent(a);}catch(RuntimeException unavailable){matches=List.of();}
            List<String> options=matches;
            a.runOnUiThread(()->{
                if(a.isDestroyed()||a.isFinishing()||!id.equals(draft.getString("id",""))||!obj().isEmpty())return;
                if(options.size()==1&&!options.get(0).isBlank()){draft.edit().putString("object",options.get(0)).commit();ask();}
                else{
                    List<String> names=new ArrayList<>(options);names.remove("");
                    draft.edit().putString("options",new JSONArray(names).toString()).commit();
                    a.promiseMessage((names.isEmpty()?"":"Нашла несколько возможных показов: "+String.join(", ",names)+". ")+"По какому объекту записать обещание? Назовите название или адрес.",true);
                }
            });
        },"jarvis-showing").start();
    }
    static LocalTime time(String text){
        String s=text.toLowerCase(Locale.ROOT).replace('ё','е');
        if(s.matches("(?:в )?полдень"))return LocalTime.NOON;
        String[] words={"ноль","час","два","три","четыре","пять","шесть","семь","восемь","девять","десять","одиннадцать","двенадцать"};
        s=s.replaceFirst("(?iu)\\bполовин[ауе] (?:одиннадцатого)\\b","10:30");
        s=s.replace("тридцать","30").replace("пятнадцать","15").replace("сорок пять","45");
        for(int i=0;i<words.length;i++)s=s.replaceFirst("^(в |на |к )?"+words[i]+"(?= |$)","$1"+i);
        Matcher m=CLOCK.matcher(s);if(!m.matches())return null;
        int h=Integer.parseInt(m.group(1)),min=m.group(2)==null?0:Integer.parseInt(m.group(2));String period=m.group(3);
        if(h>=24||min>=60||period!=null&&(h>12||h==0))return null;
        if(period!=null){if(h==12)h=0;if(period.matches("дня|вечера"))h+=12;}
        return LocalTime.of(h,min);
    }
    void ask(){
        if(!pending())return;
        if(obj().isEmpty()){a.promiseMessage("По какому объекту записать обещание «"+note()+"»? Назовите название или адрес.",true);return;}
        String date=draft.getString("date",""),clock=draft.getString("time","");
        String about="Объект «"+obj()+"». "+note()+". ";
        if(date.isEmpty()||clock.isEmpty()){
            a.promiseMessage(about+(date.isEmpty()?"На какой день и время поставить напоминание?":"Во сколько напомнить "+LocalDate.parse(date).format(java.time.format.DateTimeFormatter.ofPattern("dd.MM"))+"?"),true);return;
        }
        long due=LocalDateTime.of(LocalDate.parse(date),LocalTime.parse(clock)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        if(due<=System.currentTimeMillis()){draft.edit().remove("time").commit();a.promiseMessage(about+"Это время уже прошло. Назовите будущий день и время.",true);return;}
        String id=draft.getString("id",""),object=obj(),text=note();
        a.withNotifications(()->{
            if(!id.equals(draft.getString("id","")))return;
            a.book.ensure(object);
            if(!Promises.save(a,object,text,due)){a.promiseReply("Не удалось включить напоминание. Проверьте уведомления Марии и скажите «повтори».");return;}
            ShowingNotes.reminderSaved(a,draft.getString("showing",""));
            clear();a.promiseReply(about+"Напомню "+Promises.when(due)+".");
        });
    }
}
