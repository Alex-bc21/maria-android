package local.jarvis.search;

import java.util.Locale;
import java.util.Random;

/** Short conversational replies. Search counts and error details come from the search engine. */
final class CompanionLines {
    private final Random random=new Random();
    private final java.util.Map<String,Integer> previous=new java.util.HashMap<>();
    String pick(String... lines){
        String key=lines[0];
        int last=previous.getOrDefault(key,-1);
        int next=random.nextInt(last<0?lines.length:lines.length-1);
        if(last>=0 && next>=last)next++;
        previous.put(key,next);
        return lines[next];
    }
    static final java.util.List<String> GREETINGS=java.util.List.of("Привет! Я вся внимание. Что разыскиваем сегодня?","Привет-привет! За чем охотимся сегодня?","Привет! Есть для меня загадка? Рассказывайте!");
    String greeting(){return pick(GREETINGS.toArray(new String[0]));}
    private static final java.util.regex.Pattern ADDRESS=java.util.regex.Pattern.compile(
        "(?iu)^\\s*(?:мария|мари|джарвис|джервис|jarvis)(?:\\s*[,!:—]\\s*|\\s+(?=(?:найди|поищи|покажи|открой|отправь|перешли|проложи|построй|скопируй|запусти|проверь|расскажи|скажи|сколько|как|кто|что|где|почему|почисти|очисти|напомни|запиши|включи|выключи|поделись|помоги|разберись|привет|спасибо|ты|давай|пожалуйста|сделай|подготовь|собери|поставь|переведи|объясни|ответь|назови|составь|посмотри|прочитай|выбери|поищем|верни|закрой|добавь|освободи|убери|выйди|когда|какие|какой|какое|какая|представься|через)(?![\\p{L}\\p{N}_])))");
    static String command(String input){return ADDRESS.matcher(input).replaceFirst("");}
    String social(String input){
        String words=input.toLowerCase(Locale.ROOT).replaceAll("[,.!?—]+"," ").replaceAll("\\s+"," ").strip()
                .replaceFirst("^(?:джарвис|jarvis) ","").replaceFirst(" (?:мария|мари|джарвис|jarvis)$","");
        return switch(words){
            case "привет","приветик","здравствуй","доброе утро","добрый день","добрый вечер" ->
                greeting();
            case "спасибо","большое спасибо","спасибо большое","благодарю" ->
                pick("Пожалуйста!","Всегда рада помочь.","Обращайтесь. Я рядом.");
            case "как тебя зовут","как твое имя","как твоё имя","какое у тебя имя","представься" -> "Меня зовут Мария. Чем помочь?";
            case "ты тут","ты здесь","ты на связи" -> pick("Да, я здесь. Слушаю вас.","На связи! Чем помочь?");
            default -> null;
        };
    }
    String results(int count,boolean visual){
        if(count==0)return pick("Пока ничего похожего. Попробуем другую примету?","Совпадений пока нет. Может, вспомните другую деталь?");
        if(visual)return count==1?pick("Есть один похожий вариант. Посмотрите, это он?","Вот что похоже на ваше описание. Узнаёте?"):
            pick("Есть несколько похожих вариантов. Самые близкие — в начале.","Посмотрите на первые кадры. Что-нибудь узнаёте?");
        if(count==1)return pick("Нашла один вариант. Посмотрите.","Ага, вот и находка!");
        return pick("Нашла варианты. Показываю.","Есть зацепки! Посмотрите, что нашлось.");
    }
}
