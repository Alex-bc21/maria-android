package local.jarvis.search;

/** Phrase-level pitch contour for the local voice. The output also drives the lip animation. */
final class VoiceDelivery {
    static float speed(boolean lively){return lively?1.04f:1.0f;}
    static float[] shape(float[] input,String sentence,boolean lively){
        if(input.length<2)return input;
        int first=0,last=input.length-1;
        while(first<last && Math.abs(input[first])<.012f)first++;
        while(last>first && Math.abs(input[last])<.012f)last--;
        boolean question=sentence.endsWith("?"),exclaim=sentence.endsWith("!");
        float[] output=new float[input.length+1];
        int written=0;
        double cursor=0;
        while(cursor<input.length-1){
            float t=(float)Math.max(0,Math.min(1,(cursor-first)/Math.max(1,last-first)));
            float lift=lively?.12f:.065f;
            double accent=Math.sin(Math.PI*t)*(lively?.06:.018);
            double tail=Math.max(0,(t-.67)/.33);
            double step=1+lift+accent+tail*(lively?(question?.105:exclaim?-.045:-.065):-.032);
            int j=(int)cursor;float mix=(float)(cursor-j);
            output[written++]=(input[j]+mix*(input[j+1]-input[j]))*(lively?1.13f:1.04f);
            cursor+=step;
        }
        return java.util.Arrays.copyOf(output,written);
    }
}
