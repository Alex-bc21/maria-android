package local.jarvis.search;

import android.content.Context;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import java.util.*;
import java.util.regex.*;

/** Extract answers from the selected PDF. Keep alternative clauses and their original page. */
final class Contract {
    record Citation(int page,String text,boolean scan,int score){
        String key(){return page+"\n"+text;}
    }
    static boolean continuation(String question){
        return question.toLowerCase(Locale.ROOT).replace('ё','е').strip()
            .matches("(?:а )?(?:что еще|расскажи еще|продолжай|продолжи)(?:[ ?.!,].*)?");
    }
    static boolean overview(String question){
        String q=question.toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("[?!.]+$","").strip();
        if(continuation(q) && (q.matches("(?:а )?(?:что еще|расскажи еще|продолжай|продолжи)") ||
            q.matches(".*(?:про |об? |по )(?:этот |этом |этому )?(?:договор[а-я]*|документ[а-я]*)") ||
            q.matches("(?:а )?что еще (?:ты )?можешь (?:мне )?(?:сказать|рассказать)")))return true;
        return q.matches("(?:о чем|про что|расскажи (?:кратко )?(?:про|о)|перескажи|опиши) (?:этот |этом |данный )?(?:договор[а-я]*|документ[а-я]*)") ||
            q.matches(".*(?:краткий обзор|основные условия|краткое содержание|главные условия|что важно знать)(?: (?:этого |в этом |про этот )?договора?)?");
    }
    private static final Pattern NUMBER=Pattern.compile("(?iu)(?:пункт(?:е|а|у|ом)?|п\\.)\\s*(\\d+(?:[.,]\\d+)*)");
    private static final String[][] concepts={
        {"растор","розір","прекращ","припинен","разорв","досроч","дострок"},
        {"предупр","уведом","повідом","поперед","извест"},
        {"штраф","неустой","пеня","пени","санкц"},
        {"депози","залог","обеспеч","завдат","гарантійн"},
        {"аренд","оренд"}, {"стоим","цен","вартіс","сумм","сума","оплат","платеж","платіж"},
        {"продл","пролонг","поновл"}, {"ремонт","ремонту"}
    };
    static List<Citation> find(Context c,PhoneSearch.Hit hit,String question) throws Exception {
        boolean general=overview(question);
        Matcher number=NUMBER.matcher(question);
        Pattern clause=null;
        if(number.find())clause=Pattern.compile("(?<![\\d.,])"+Pattern.quote(number.group(1).replace(',','.'))+"(?!\\d|\\.\\d)");
        String q=question.toLowerCase(Locale.ROOT);
        Set<String> keys=new HashSet<>();
        for(String word:q.split("[^\\p{L}]+")){
            if(word.length()<4||word.matches("договор.*|пункт.*|како.*|сколько|скажи|скажите|каки.*|указан.*|написан.*|сказан.*|должен|нужно|процитируй|котор.*|этом|этого|дней|договоре|сторон.*"))continue;
            keys.add(word.substring(0,Math.min(5,word.length())));
        }
        List<Citation> candidates=new ArrayList<>();
        try(ContentIndex ix=new ContentIndex(c,new ContentRequest(false,""),0);
            ParcelFileDescriptor fd=c.getContentResolver().openFileDescriptor(hit.uri(),"r");PdfRenderer pdf=new PdfRenderer(fd)){
            for(int i=0;i<pdf.getPageCount();i++){
                if(Thread.currentThread().isInterrupted())throw new InterruptedException();
                String raw=ix.pageText(hit,pdf,i);
                boolean scan=raw.startsWith("[OCR]\n");
                String page=(scan?raw.substring(6):raw).strip().replaceAll("\\s+"," ");
                String[] numbered=page.split("(?<=\\s)(?=\\d+\\.\\d+(?:\\.\\d+)*[.)]?\\s)");
                List<String> passages=new ArrayList<>();
                for(String part:numbered){
                    if(part.matches("^\\d+(?:\\.\\d+)+[.)]?\\s.*"))passages.add(part.strip());
                    else Collections.addAll(passages,part.split("(?<!\\d\\.)(?<=[.!?;])\\s+(?=[\\p{Lu}\\d])"));
                }
                for(String passage:passages){
                    if(passage.isBlank())continue;
                    String lower=passage.toLowerCase(Locale.ROOT);
                    int score=0;
                    if(general){
                        if(passage.length()<24 || !passage.matches(".*\\p{L}{3}.*"))continue;
                        score=passage.matches("^\\d+(?:\\.\\d+)*[.)]?\\s+.*")?10:1;
                        for(String[] group:concepts)if(Arrays.stream(group).anyMatch(lower::contains))score++;
                    }else if(clause!=null){
                        if(!clause.matcher(passage).lookingAt()&&!Pattern.compile("(?iu)^пункт\\s+"+clause.pattern()).matcher(passage).find())continue;
                        score=100;
                    }else{
                        for(String[] group:concepts)if(Arrays.stream(group).anyMatch(q::contains)&&Arrays.stream(group).anyMatch(lower::contains))score+=4;
                        for(String key:keys)if(lower.contains(key))score+=2;
                        if(score<2)continue;
                    }
                    candidates.add(new Citation(i,passage,scan,score));
                }
            }
        }
        candidates.sort(Comparator.comparingInt(Citation::score).reversed().thenComparingInt(Citation::page));
        if(!general && !candidates.isEmpty()){
            int min=Math.max(2,candidates.get(0).score()-2);
            candidates.removeIf(x->x.score()<min);
        }
        return candidates;
    }
}
