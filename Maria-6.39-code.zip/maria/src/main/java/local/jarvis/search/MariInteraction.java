package local.jarvis.search;

public final class MariInteraction extends android.service.voice.VoiceInteractionService {}
