package local.jarvis.search;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Extract a remembered scene or quotation without treating it as a general question. */
record RecallSearch(String query,String period) {
    private static final Pattern KIND=Pattern.compile("(?<![а-яёa-z])(?:видеоролик|видео|ролик|фотографи[яию]|фото|снимок|договор(?:е|а)?|контракт(?:е|а)?|скан(?:е|а)?|pdf|пдф|документ(?:е|а)?)(?![а-яёa-z])");
    private static final Pattern SCENE=Pattern.compile("^(?:(?:на н[её]м|на ней|на котором|на которой|в котором|в кадре|где|там|как|с изображением|с)\\s+)(?:(?:там|был[аио]?|видн[аоы]|виден|есть|изображ[её]н[аоы]?)\\s+)*");
    private static final Pattern QUOTE=Pattern.compile("^(?:(?:в н[её]м|в котором|на котором|где|там)\\s+)?(?:(?:был[аои]?|есть)\\s+)?(?:было написано|написано|сказано|указано|упоминается|встречается|со словами|с текстом|с фразой|слова|текст|фраза|пункт)[: ,]+");
    private static final Pattern DAY=Pattern.compile("(?<![а-яё])(?:сегодня|вчера)(?![а-яё])");
    static RecallSearch parse(String input){
        String s=input.toLowerCase(Locale.ROOT).strip().replaceAll("\\s+"," ")
                .replaceFirst("^(?:джарвис|джервис|jarvis)[, ]+","");
        Matcher kind=KIND.matcher(s);
        if(!kind.find())return null;
        String prefix=s.substring(0,kind.start()).strip();
        if(!prefix.isEmpty() && !prefix.matches("(?:(?:найди|поищи|покажи|отыщи|ищу|помню|не помню|где|там|уже|сохранял[аи]?|лежит|лежал[аио]?|хранится|найти|мне|нужно|нужен|нужна|нужное|нужна была|у меня|я|снимал[аи]?|снял[аи]?|делал[аи]?|сохранил[аи]?|был[аои]?|когда-то|где-то|вчера|сегодня|тот|то|ту|это|пожалуйста|фразу|из|в|на)[, ]*)+"))return null;
        boolean scene=kind.group().matches("видео.*|ролик|фото.*|снимок");
        String tail=s.substring(kind.end()).strip().replaceFirst("^[,.:; —–-]+","");
        if(tail.startsWith("с названием ") || tail.startsWith("с именем "))return null;
        if(kind.group().startsWith("скан"))
            tail=tail.replaceFirst("^(?:(?:или )?(?:pdf|пдф))[ ,:]+","");
        boolean stillPhoto=scene && !kind.group().matches("видео.*|ролик");
        Matcher written=QUOTE.matcher(tail);
        boolean textOnPhoto=stillPhoto && written.find();
        Matcher marker=(scene && !textOnPhoto?SCENE:QUOTE).matcher(tail);
        boolean quoted=tail.startsWith("«")||tail.startsWith("\"");
        if(marker.find())tail=tail.substring(marker.end());
        else if(!quoted && !(prefix.contains("фразу из") && !scene)){
            // A spoken topic can directly follow the media type. Preserve dates and filename queries.
            if(!scene || !tail.matches("[а-яё -]+[,!.? ]*")
                    || tail.matches("(?:за |от |из |в папке |с названи.*|с именем |за сегодня|за вчера|сегодня|вчера|скачан.*|последн.*|недел.*|съёмк.*).*"))return null;
            tail=tail.replaceFirst("^(?:про|об|о) +","");
        }
        tail=tail.replaceFirst("[, ]+например[.!? ]*$","").replaceFirst("[,.; ]+(?:не помню где.*|не помню название.*|найди (?:его|её|это).*|покажи (?:его|её|это).*)$","")
                .replaceAll("^[«\" :]+|[»\".?! ]+$","").strip();
        if(tail.isEmpty() || tail.matches("(?:(?:то-то|что-то|что-нибудь|не помню)[, ]*)+"))return null;
        String type=kind.group();

        String query;
        if(textOnPhoto)query="скрин со словами "+tail;
        else if(scene)query=(type.matches("видео.*|ролик")?"видео":"фото")+", где "+tail;
        else query=(type.startsWith("скан")?"скан":type.startsWith("документ")?"документ":"pdf")+" со словами "+tail;
        Matcher day=DAY.matcher(prefix);
        return new RecallSearch(query,day.find()?day.group():"");
    }
}
