package local.jarvis.search;

import android.content.Intent;
import android.net.Uri;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.*;

record Directions(String destination,List<String> stops) {
    private static final Pattern REQUEST=Pattern.compile("^(?:(?:мари|джарвис|ну|пожалуйста|давай) +)*(?:проложи(?:ть)?|построй|построить|покажи|открой|составь) +(?:мне +)?маршрут +(?:мне +)?(?:(?:на|в|до|к) +)?(.+)$",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);
    static Directions parse(String input){
        String cleaned=input.strip().replaceAll("[,!?]+"," ").replaceAll("\\s+"," ").strip().replaceFirst("[.]$","");
        Matcher m=REQUEST.matcher(cleaned);
        if(!m.matches())return null;
        String[] parts=m.group(1).strip().split("(?iu) +через +",-1);
        if(parts[0].matches("(?iu)(?:следующий|следующему) показу?"))return null;
        List<String> stops=new ArrayList<>();
        for(int i=1;i<parts.length;i++)stops.add(place(parts[i]));
        return new Directions(place(parts[0]),stops);
    }
    private static String place(String name){
        return switch(name.toLowerCase(Locale.ROOT).strip()){
            case "вышгород","выжгород","вишгород","вышгорода","вышгороде" -> "Вишгород, Київська область, Україна";
            default -> name.strip();
        };
    }
    String target(){
        if(destination.matches("(?iu)пр[оіи]л[еіи]ски") && stops.contains("Вишгород, Київська область, Україна"))
            return "Проліски, Бориспільський район, Київська область, Україна";
        return destination;
    }
    Uri uri(){
        Uri.Builder url=new Uri.Builder().scheme("https").authority("www.google.com").path("/maps/dir/")
                .appendQueryParameter("api","1").appendQueryParameter("destination",target()).appendQueryParameter("travelmode","driving");
        if(!stops.isEmpty())url.appendQueryParameter("waypoints",String.join("|",stops));
        return url.build();
    }
    Intent maps(){return new Intent(Intent.ACTION_VIEW,uri()).setPackage("com.google.android.apps.maps");}
}
