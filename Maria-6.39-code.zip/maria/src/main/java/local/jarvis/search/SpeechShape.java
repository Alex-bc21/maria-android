package local.jarvis.search;

/** Two continuous articulation controls evaluated at the current PCM playback position. */
final class SpeechShape {
    float opening,rounding;
    private final int window;
    private final float[] coefficient=new float[6];
    private static final int[] BANDS={520,800,1040,1550,2050,2550};
    SpeechShape(int rate){
        window=rate/45;
        for(int i=0;i<BANDS.length;i++)coefficient[i]=(float)(2*Math.cos(2*Math.PI*BANDS[i]/rate));
    }
    void read(short[] pcm,int pos){
        int count=Math.min(window,pcm.length-pos);
        if(count<2){opening=rounding=0;return;}
        double energy=0;
        for(int i=0;i<count;i++){float v=pcm[pos+i]/32768f;energy+=v*v;}
        float rms=(float)Math.sqrt(energy/count);
        opening=Math.min(1,(float)Math.sqrt(Math.max(0,rms-.009f)*5.2f));
        float low=0,high=0;
        for(int band=0;band<BANDS.length;band++){
            float a=0,b=0,k=coefficient[band];
            for(int i=0;i<count;i++){
                float next=pcm[pos+i]/32768f+k*a-b;b=a;a=next;
            }
            float power=Math.max(0,a*a+b*b-k*a*b);
            if(band<3)low+=power;else high+=power;
        }
        rounding=opening*Math.min(1,Math.max(0,(low-1.25f*high)/(low+high+.001f)));
    }
}
