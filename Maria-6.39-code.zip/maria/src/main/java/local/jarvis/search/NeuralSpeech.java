package local.jarvis.search;

import android.content.Context;
import android.media.*;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.k2fsa.sherpa.onnx.*;
import java.io.*;
import java.nio.file.*;
import java.text.BreakIterator;
import java.util.Locale;
import java.util.concurrent.*;
import java.util.zip.*;

/** Russian speech. Inference and playback are serialized off the UI thread. */
final class NeuralSpeech {
    interface Listener { void start(); void mouth(float open,float round); void end(); void failed(); }
    private final Context context;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private volatile int turn;
    private OfflineTts engine;
    private final BrightVoice bright=new BrightVoice();
    NeuralSpeech(Context context){this.context=context.getApplicationContext();}
    void stop(){turn++;bright.cancel();}
    void close(){stop();worker.execute(()->{if(engine!=null)engine.release();});worker.shutdown();}
    void say(String text,CoralDelivery delivery,Listener listener){
        int id=++turn;bright.cancel();
        worker.execute(()->{
            if(id!=turn)return;
            try{
                int greeting=CompanionLines.GREETINGS.indexOf(text);
                if(greeting>=0){
                    short[] pcm=BrightVoice.readPcm(context.getAssets().open("bright/hello"+greeting+".pcm"));
                    play(pcm,BrightVoice.RATE,1,id,listener,true,"Coral greeting");
                    post(id,listener::end);
                    if(id==turn)Log.i("JarvisVoice","Coral greeting playback finished");
                    return;
                }
                var prefs=context.getSharedPreferences("contract_ai",0);
                String sealed=prefs.getBoolean(BrightVoice.PREFERENCE,false)?prefs.getString(DeviceCredential.SETTING,""):"";
                if(!sealed.isEmpty()){
                    int from=0;
                    boolean started=false;
                    BreakIterator sentences=BreakIterator.getSentenceInstance(new Locale("ru","RU"));
                    sentences.setText(text);
                    while(from<text.length() && id==turn){
                        int end=CoralDelivery.chunkEnd(text,from,sentences);
                        String chunk=text.substring(from,end).strip();
                        if(!chunk.isEmpty()){
                            short[] pcm;
                            try{pcm=bright.request(chunk,sealed,delivery,()->id==turn);}
                            catch(Exception network){
                                if(id!=turn)return;
                                Log.i("JarvisVoice","Coral unavailable; continuing locally");
                                break;
                            }
                            if(id!=turn)return;
                            play(pcm,BrightVoice.RATE,BrightVoice.pitch(pcm),id,listener,!started,"Coral online");
                            if(!started)Log.i("JarvisVoice","Coral delivery "+delivery.name());
                            started=true;
                        }
                        from=end;
                    }
                    if(id!=turn)return;
                    if(from==text.length()){
                        post(id,listener::end);Log.i("JarvisVoice","Coral online playback finished");return;
                    }
                    local(text.substring(from),listener,id,started);
                }else local(text,listener,id,false);
            }catch(Exception|LinkageError e){
                if(id==turn){Log.w("JarvisVoice","Speech unavailable: "+e.getClass().getSimpleName());post(id,listener::failed);}
            }
        });
    }
    private void local(String text,Listener listener,int id,boolean played) throws Exception {
        if(!DeviceSupport.nativeModels() || !DeviceSupport.memoryAvailable(context,256L*1024*1024))throw new IOException("Use Android speech");
        if(engine==null)engine=load();
        BreakIterator parts=BreakIterator.getSentenceInstance(new Locale("ru","RU"));
        parts.setText(text);

        for(int from=parts.first(),end=parts.next();end!=BreakIterator.DONE;from=end,end=parts.next()){
            String sentence=text.substring(from,end).strip();
            while(!sentence.isEmpty() && id==turn){
                int cut=Math.min(240,sentence.length());
                if(cut<sentence.length()){
                    int word=sentence.lastIndexOf(' ',cut);if(word>0)cut=word;
                }
                String line=sentence.substring(0,cut);
                sentence=sentence.substring(cut).strip();
                if(line.codePoints().noneMatch(Character::isLetterOrDigit))continue;
                boolean lively=text.length()<=110;
                GeneratedAudio audio=engine.generate(line,0,VoiceDelivery.speed(lively));
                if(id!=turn)return;
                float[] samples=VoiceDelivery.shape(audio.getSamples(),line,lively);
                if(samples.length==0)throw new IOException("Empty synthesized audio");
                play(pcm16(samples),audio.getSampleRate(),1,id,listener,!played,"Mari");
                played=true;
            }
            if(id!=turn)return;
        }
        post(id,listener::end);
        if(played && id==turn)Log.i("JarvisVoice","Mari playback finished");
    }
    private void post(int id,Runnable callback){ui.post(()->{if(id==turn)callback.run();});}
    private OfflineTts load()throws IOException{
        File dir=new File(context.getNoBackupFilesDir(),"mari-medium-v2");
        File done=new File(dir,"ready");
        synchronized(NeuralSpeech.class){
            if(!done.isFile()){
                Files.createDirectories(dir.toPath());
                try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(context.getAssets().open("mari-medium.zip")))){
                    ZipEntry e;
                    while((e=zip.getNextEntry())!=null){
                        Path dest=dir.toPath().resolve(e.getName()).normalize();
                        if(!dest.startsWith(dir.toPath()))throw new IOException("Invalid voice archive");
                        if(e.isDirectory()){Files.createDirectories(dest);continue;}
                        Files.createDirectories(dest.getParent());
                        Files.copy(zip,dest,StandardCopyOption.REPLACE_EXISTING);
                    }
                }
                Files.createFile(done.toPath());
            }
        }
        OfflineTtsConfig config=new OfflineTtsConfig();
        OfflineTtsModelConfig models=config.getModel();
        models.setNumThreads(2);
        OfflineTtsVitsModelConfig vits=models.getVits();
        vits.setModel(new File(dir,"voice.onnx").getPath());
        vits.setTokens(new File(dir,"tokens.txt").getPath());
        vits.setDataDir(new File(dir,"espeak-ng-data").getPath());
        return new OfflineTts(null,config);
    }
    private static short[] pcm16(float[] samples){
        short[] pcm=new short[samples.length];
        for(int i=0;i<pcm.length;i++)pcm[i]=(short)(32767*Math.max(-1,Math.min(1,samples[i])));
        return pcm;
    }
    private void play(short[] pcm,int rate,float pitch,int id,Listener listener,boolean first,String name)throws Exception{
        AudioTrack track=new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setTransferMode(AudioTrack.MODE_STATIC).setBufferSizeInBytes(pcm.length*2).build();
        try{
            if(track.write(pcm,0,pcm.length)!=pcm.length)throw new IOException("Audio buffer");
            if(id!=turn)return;
            if(pitch!=1f)track.setPlaybackParams(new PlaybackParams().setSpeed(1f).setPitch(pitch));
            track.play();
            if(first){post(id,listener::start);Log.i("JarvisVoice",name+" playback started, "+rate+" Hz");}
            SpeechShape shape=new SpeechShape(rate);
            int pos;
            while(id==turn && (pos=track.getPlaybackHeadPosition())<pcm.length){
                shape.read(pcm,pos);
                float open=shape.opening,round=shape.rounding;
                post(id,()->listener.mouth(open,round));Thread.sleep(20);
            }
            post(id,()->listener.mouth(0,0));
        }finally{track.release();}
    }
}
