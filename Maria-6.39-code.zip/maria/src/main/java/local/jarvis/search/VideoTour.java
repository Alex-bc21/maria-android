package local.jarvis.search;

import android.graphics.Bitmap;
import java.util.Locale;
import java.util.regex.*;

record VideoTour(String clue) {
    private static final Pattern TOUR=Pattern.compile("^(?:видео[- ]?)?(?:(?:обзор[а-я]*|тур[а-я]*|показ[а-я]*)\\s+(?:по\\s+)?квартир[а-я]*|квартир[а-я]*\\s+(?:изнутри|обзор[а-я]*))(?:\\s*[,;—-]?\\s+(.*))?$");
    static VideoTour parse(String text){
        Matcher m=TOUR.matcher(text.toLowerCase(Locale.ROOT).strip().replaceAll("[.!?]+$",""));
        if(!m.matches())return null;
        String detail=m.group(1)==null?"":m.group(1).replaceFirst("^(?:(?:там|где|есть|был[аои]?|виден|видно|с|и)\\s+)+","");
        return new VideoTour(detail.strip());
    }
    private boolean redSofa(){return clue.matches("(?:красн[а-я]+ диван[а-я]*|диван[а-я]* красн[а-я]+)");}
    String detailText(){return redSofa()?"red sofa in a living room":clue;}
    String googleTerms(){return "videos of "+(clue.isEmpty()?"apartment interiors":detailText());}
    boolean needsRed(){return redSofa();}
    static double redFraction(Bitmap frame){
        int red=0,seen=0;
        int step=Math.max(1,Math.min(frame.getWidth(),frame.getHeight())/36);
        for(int y=step/2;y<frame.getHeight();y+=step)for(int x=step/2;x<frame.getWidth();x+=step){
            int pixel=frame.getPixel(x,y),r=pixel>>16&255,g=pixel>>8&255,b=pixel&255;
            seen++;
            if(r>50 && r-Math.max(g,b)>28 && Math.abs(g-b)<(r-Math.min(g,b))*.47)red++;
        }
        return (double)red/Math.max(1,seen);
    }
}
