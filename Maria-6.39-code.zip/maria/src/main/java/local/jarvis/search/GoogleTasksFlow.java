package local.jarvis.search;

import android.content.*;
import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;

/** A bounded interaction with the visible Google Tasks list and its native date picker. */
final class GoogleTasksFlow {
    static final String PKG="com.google.android.apps.tasks";
    final String title;final long due,turn;final boolean list;
    final ZonedDateTime at;
    private final LinkedHashSet<String> names=new LinkedHashSet<>();
    private String stage="list", listName="",hourValue="";
    private int scrolls;
    private boolean editing;
    private String lastPage="";
    String stage(){return stage;}
    GoogleTasksFlow(String title,long due,boolean list,long turn){
        this.title=title;this.due=due;this.list=list;this.turn=turn;
        at=Instant.ofEpochMilli(due).atZone(ZoneId.systemDefault());
    }
    static List<AccessibilityNodeInfo> nodes(AccessibilityNodeInfo root){
        var out=new ArrayList<AccessibilityNodeInfo>();out.add(root);
        for(int i=0;i<out.size()&&out.size()<1800;i++){
            var n=out.get(i);
            for(int j=0;j<n.getChildCount();j++){var child=n.getChild(j);if(child!=null&&child.isVisibleToUser()&&!child.isPassword())out.add(child);}
        }
        return out;
    }
    static String text(AccessibilityNodeInfo n){return n==null?"":Objects.toString(n.getText(),"");}
    static String desc(AccessibilityNodeInfo n){return Objects.toString(n.getContentDescription(),"");}
    static AccessibilityNodeInfo id(List<AccessibilityNodeInfo> ns,String id){
        for(var n:ns)if((PKG+":id/"+id).equals(n.getViewIdResourceName()))return n;return null;
    }
    static boolean click(AccessibilityNodeInfo n){
        for(int i=0;n!=null&&i<4;i++,n=n.getParent())if(n.isClickable()&&n.isEnabled())return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        return false;
    }
    private static boolean set(AccessibilityNodeInfo n,String value){
        if(n==null||!n.isEditable())return false;
        var b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,value);
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);
    }
    private boolean dateMatches(String s){
        s=s.toLowerCase(Locale.ROOT).replace('ё','е').replace('\u00a0',' ');
        var today=LocalDate.now();var day=at.toLocalDate();
        if(day.equals(today) && (s.contains("сегодня")||s.contains("today")))return true;
        if(day.equals(today.plusDays(1))&&(s.contains("завтра")||s.contains("tomorrow")))return true;
        for(Locale locale:List.of(Locale.getDefault(),Locale.ENGLISH,new Locale("ru"),new Locale("uk"))){
            for(String fmt:new String[]{"d MMMM yyyy","MMMM d, yyyy","d MMMM","MMM d","d MMM"})
                if(Pattern.compile("(?<![\\p{L}0-9])"+Pattern.quote(day.format(DateTimeFormatter.ofPattern(fmt,locale)).toLowerCase(locale))+"(?![\\p{L}0-9])").matcher(s).find())return true;
        }
        return false;
    }
    private boolean sameTime(String s){
        s=s.replace('\u00a0',' ').replace('\u202f',' ').strip();
        var formats=Pattern.compile("(?i)\\b[ap]m\\b").matcher(s).find()?List.of("h:mm a","hh:mm a"):List.of("HH:mm","H:mm");
        for(String fmt:formats)if(Pattern.compile("(?i)(?<![0-9])"+Pattern.quote(at.format(DateTimeFormatter.ofPattern(fmt,Locale.US)))+"(?![0-9])").matcher(s).find())return true;
        return false;
    }
    String step(AccessibilityNodeInfo root){
        var ns=nodes(root);
        var rowList=ns.stream().filter(n->(PKG+":id/task_item_layout").equals(n.getViewIdResourceName())).collect(java.util.stream.Collectors.toList());
        if(stage.equals("list")||stage.equals("verify")){
            if(stage.equals("list") && !list && id(ns,"add_task_title")!=null){
                String draft=text(id(ns,"add_task_title"));
                if(title.equals(draft)){stage="composer";return null;}
                return "В Google Задачах уже открыт другой черновик. Закройте его и повторите команду.";
            }
            if(id(ns,"tasks_fab")==null && id(ns,"task_list_title")==null)return null;
            listName=text(id(ns,"task_list_title"));StringBuilder visible=new StringBuilder();
            var matching=new ArrayList<AccessibilityNodeInfo>();
            for(var row:rowList){
                var children=nodes(row);String name=text(id(children,"task_name"));String date=text(id(children,"task_due_date_text"));
                visible.append(name).append(date).append('\n');
                if(list){if(dateMatches(date+" "+desc(row)))names.add(name+" · "+date);continue;}
                if(!name.equals(title))continue;
                if(sameTime(date) && dateMatches(date))return "Подтверждено в Google Задачах: «"+title+"» · "+ActionReceipt.stamp(due)+".";
                matching.add(row);
            }
            if(!matching.isEmpty()){
                if(matching.size()>1)return "В списке несколько задач «"+title+"». Откройте нужную задачу, чтобы проверить её срок.";
                var children=nodes(matching.get(0));String date=text(id(children,"task_due_date_text"));
                if(stage.equals("verify")){
                    if(!date.isBlank() && click(id(children,"task_name")))stage="verifyEditor";
                    return null;
                }
                if(!date.isBlank())return "В Google Задачах уже есть «"+title+"» со сроком "+date+". Для изменения откройте эту задачу.";
                if(click(id(children,"task_name"))){editing=true;stage="editor";}return null;
            }
            if(stage.equals("verify")){
                if(!lastPage.equals(visible.toString()) && scrolls++<40){
                    lastPage=visible.toString();for(var n:ns)if(n.isScrollable() && n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))break;
                }
                return null;
            }
            {
                if(!rowList.isEmpty() && !lastPage.equals(visible.toString()) && scrolls<40){
                    lastPage=visible.toString();for(var n:ns)if(n.isScrollable() && n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)){scrolls++;return null;}
                }
                if(list)return "Google Задачи, открытый список «"+listName+"», "+at.toLocalDate()+". "+(names.isEmpty()?"Среди просмотренных задач на эту дату ничего нет.":String.join("; ",names))+(scrolls>=40?" Проверена часть списка.":"");
            }
            if(click(id(ns,"tasks_fab")))stage="composer";
        }else if(stage.equals("composer")){
            var input=id(ns,"add_task_title");
            if(!title.equals(text(input))){set(input,title);return null;}
            if(click(id(ns,"add_task_pick_due_date")))stage="date";
        }else if(stage.equals("editor") || stage.equals("verifyEditor")){
            if(!title.equals(text(id(ns,"edit_title"))))return null;
            if(click(id(ns,"edit_due_date_container")))stage=stage.equals("verifyEditor")?"readback":"date";
        }else if(stage.equals("date")||stage.equals("readback")){
            if(id(ns,"dtp_done")==null)return null;
            AccessibilityNodeInfo day=null;
            for(var n:ns)if(text(n).equals(""+at.getDayOfMonth()) && dateMatches(desc(n))) {day=n;break;}
            if(stage.equals("readback")){
                if(day!=null && (day.isSelected()||day.isChecked()) && sameTime(selectedTime(ns)))
                    return "Подтверждено в Google Задачах: «"+title+"» · "+ActionReceipt.stamp(due)+".";
                return "Открыла сохранённую задачу в Google Задачах. Проверить её дату и время автоматически не удалось.";
            }
            if(day==null){if(scrolls++<14)click(id(ns,"next"));else return "Нужная дата не найдена в календаре Google Задач.";return null;}
            if(click(day))stage="openTime";
        }else if(stage.equals("openTime")){
            if(click(id(ns,"dtp_time_layout")) || click(id(ns,"dtp_time_label")))stage="hour";
        }else if(stage.equals("hour")){
            if(id(ns,"material_timepicker_ok_button")==null)return null;
            var edits=ns.stream().filter(AccessibilityNodeInfo::isEditable).collect(java.util.stream.Collectors.toList());
            if(edits.isEmpty()){
                var mode=id(ns,"material_timepicker_mode_button");
                if(mode!=null && !desc(mode).toLowerCase(Locale.ROOT).matches(".*(?:режим часов|clock mode).*"))click(mode);
                return null;
            }
            int h=at.getHour();boolean twelve=id(ns,"material_clock_period_am_button")!=null;
            if(twelve){click(id(ns,h>=12?"material_clock_period_pm_button":"material_clock_period_am_button"));h=h%12==0?12:h%12;}
            hourValue=String.valueOf(h);if(set(edits.get(0),hourValue))stage="minuteFocus";
        }else if(stage.equals("minuteFocus")){
            var m=id(ns,"material_minute_text_input");
            if(m!=null){for(var child:nodes(m))if(child.isCheckable()&&click(child)){stage="minute";return null;}}
            for(var n:ns)if(n.isClickable() && n.isCheckable() && text(n).matches("[0-9]{1,2}") && !n.isChecked()){
                if(click(n)){stage="minute";return null;}
            }
        }else if(stage.equals("minute")){
            var edits=ns.stream().filter(n->n.isEditable()&&n.isVisibleToUser()).collect(java.util.stream.Collectors.toList());
            if(!edits.isEmpty() && set(edits.get(edits.size()-1),String.format(Locale.US,"%02d",at.getMinute())))stage="timeOK";
        }else if(stage.equals("timeOK")){
            if(click(id(ns,"material_timepicker_ok_button")))stage="dateOK";
        }else if(stage.equals("dateOK")){
            if(id(ns,"dtp_done")==null)return null;
            if(!sameTime(selectedTime(ns)))return "Google Задачи не подтвердили выбранное время. Проверьте его в открытом окне.";
            if(click(id(ns,"dtp_done")))stage="save";
        }else if(stage.equals("save")){
            lastPage="";scrolls=0;
            if(editing && title.equals(text(id(ns,"edit_title")))){for(var n:ns)if(desc(n).matches("Назад|Back|Navigate up|Перейти вверх")&&click(n)){stage="verify";break;}}
            else if(title.equals(text(id(ns,"add_task_title"))) && click(id(ns,"add_task_done")))stage="verify";
        }
        return null;
    }
    private static String selectedTime(List<AccessibilityNodeInfo> ns){
        var chip=id(ns,"dtp_selected_time_chip");
        return text(chip!=null?chip:id(ns,"dtp_time_label"));
    }
}

