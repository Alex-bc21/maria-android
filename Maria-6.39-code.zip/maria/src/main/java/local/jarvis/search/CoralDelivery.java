package local.jarvis.search;

import java.text.BreakIterator;

enum CoralDelivery {
    CONVERSATION("Speak as if answering a friend in the room. Let short replies land simply. For a question, put the melodic lift on the word being asked about."),
    GREETING("Greet a friend who just walked in. Start with a bright smile, settle into a more relaxed middle, then leave space for their answer."),
    FOUND("Share a discovery with a small spark of delight on the meaningful word. Ease back after the discovery. If the last sentence is a question, genuinely ask it."),
    CLARIFY("You are interested in what the listener remembers. Leave a brief beat before the question. Give its key word a curious inflection and let the ending breathe."),
    DOCUMENT("Read as a helpful person explaining a document. Use a measured conversational pace. Land clearly on the condition, amount or deadline, pause before the page reference, and enunciate each number accurately.");

    private final String direction;
    CoralDelivery(String direction){this.direction=direction;}
    String instructions(){
        return "You are Maria, an adult woman speaking idiomatic Russian to one person. Use a bright, clear, youthful high soprano, lightly mischievous when appropriate. "
            +"Keep the resonance clear and forward. Use a light speaking voice, never whispered or squeaky. Articulate word endings and consonants. "
            +"Vary pitch and pace around the meaning. Give each thought one main stress, take small pauses at sense boundaries, and finish phrases naturally. "
            +"Speak the supplied words faithfully, with no added words, laughs or sound effects. "+direction;
    }
    String forSpeech(String text){
        if(this!=DOCUMENT)return text;
        return text.replaceAll("\\s*\\(стр\\.\\s*(\\d+)\\)", " Страница $1.")
                   .replaceAll("\\s*\\(стр\\.\\s*(\\d+(?:,\\s*\\d+)+)\\)", " Страницы $1.");
    }
    // Prefer complete sentences. When a single sentence exceeds the limit, keep its clauses together.
    static int chunkEnd(String text,int start,BreakIterator sentences){
        int limit=Math.min(start+600,text.length());
        if(limit==text.length())return limit;
        int end=sentences.preceding(limit+1);
        if(end>start)return end;
        for(int i=limit;i>start+200;i--){
            if(Character.isWhitespace(text.charAt(i)) && ",;:—".indexOf(text.charAt(i-1))>=0)return i;
        }
        for(int i=limit;i>start;i--)if(Character.isWhitespace(text.charAt(i)))return i;
        return Character.isHighSurrogate(text.charAt(limit-1))?limit-1:limit;
    }
}
