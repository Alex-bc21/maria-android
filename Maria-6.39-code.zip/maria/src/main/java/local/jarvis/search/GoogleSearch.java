package local.jarvis.search;

import android.app.SearchManager;
import android.content.Intent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

record GoogleSearch(Source source,String terms) {
    enum Source {
        PHONE("Телефон",null), PHOTOS("Google Фото","com.google.android.apps.photos"), DRIVE("Google Диск","com.google.android.apps.docs");
        final String title,app;
        Source(String title,String app){this.title=title;this.app=app;}
    }
    private static final int CI=Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE;
    private static final Pattern SOURCE=Pattern.compile("(?<![\\p{L}\\p{N}])(?:(?:в|на|из|по)\\s+)?(?:google|гугл|гугл[еа]|гугол)[\\s-]*(?:(?<photos>фото(?:графиях)?|photos)|диск(?:е|а|у)?|драйв(?:е|а)?|drive)(?![\\p{L}\\p{N}])",CI);
    private static final Pattern COMMAND=Pattern.compile("^(?:(?:джарвис|jarvis)[, ]+)?(?:найди|найти|поищи|ищи|покажи|покажите|отыщи|открой|искать)(?:\\s+(?:мне|пожалуйста))?(?=[, :]|$)[, :]*",CI);
    private static final Pattern PHOTO_PREFIX=Pattern.compile("^(?:фото(?:графи[яиюй])?|снимки|снимок|картинки)(?:[, ]+(?:на котор(?:ом|ой|ых)|где|с изображением|с))?(?:\\s+(?:есть|видно|видна|изображ[её]н[аы]?))?(?:[, ]+|$)",CI);
    private static final Pattern DOCUMENT_PREFIX=Pattern.compile("^(?:файлы?|документ(?:ы)?)(?:[, ]+(?:в котором|в которых))?(?:\\s+(?:есть|написано))?(?:[, ]+|$)",CI);
    private static final Pattern PDF=Pattern.compile("^(?:pdf|пдф|пэдээф)(?:[ -]+файл(?:ы)?)?(?=[, :]|$)[, :]*",CI);
    private static final Pattern TERMS=Pattern.compile("^(?:(?:в котором|в которых|где|есть|написано|текст|со словами|с текстом|с названием|по названию|с фразой|слова|слово|фраза)(?:[, :]+|$))+",CI);

    static GoogleSearch parse(String raw,Source selected){
        String q=raw.trim();
        Matcher command=COMMAND.matcher(q);
        boolean requested=command.find();
        if(requested)q=q.substring(command.end()).trim();
        Matcher source=SOURCE.matcher(q);
        if(source.find() && (requested || source.start()==0 || selected!=Source.PHONE)){
            selected=source.group("photos")!=null?Source.PHOTOS:Source.DRIVE;
            q=(q.substring(0,source.start())+" "+q.substring(source.end())).trim();
            q=COMMAND.matcher(q).replaceFirst("");
        }
        if(selected==Source.PHONE)return null;
        q=q.replaceFirst("^[, :—-]+","").replaceFirst("[,.!? ]+$","").trim();
        if(selected==Source.PHOTOS) q=PhotoSubject.google(PHOTO_PREFIX.matcher(q).replaceFirst(""));
        else {
            boolean documents=q.matches("(?iu)^документ(?:ы)?(?:[ ,].*|$)");
            q=DOCUMENT_PREFIX.matcher(q).replaceFirst("");
            Matcher type=PDF.matcher(q);
            if(type.find()){
                String rest=TERMS.matcher(q.substring(type.end()).trim()).replaceFirst("").trim();
                boolean exact=q.substring(type.end()).trim().matches("(?iu)^(?:со словами|с текстом|с фразой|где написано|в котором написано) .+");
                q=rest.isEmpty()?"type:pdf":"type:pdf "+(exact?"со словами ":"")+rest;
            } else q=(documents?"документ ":"")+TERMS.matcher(q).replaceFirst("");
        }
        return new GoogleSearch(selected,q.trim().replaceAll("\\s+"," "));
    }
    Intent intent(){
        return new Intent("com.google.android.gms.actions.SEARCH_ACTION").setPackage(source.app)
                .putExtra(SearchManager.QUERY,terms);
    }

    static GoogleSearch forPhotoQuery(String query,ContentRequest content,String period){
        period=MediaClue.googlePeriod(period);
        if(content==null && new PhoneSearch.Query(query).videos){
            String terms=String.join(" ",new PhoneSearch.Query(query).words);
            if(period.isEmpty())period=MediaClue.googlePeriod(MediaClue.parse(query).period());
            return new GoogleSearch(Source.PHOTOS,("videos "+terms+" "+period).trim().replaceAll("\\s+"," "));
        }
        if(content!=null && content.video()){
            VideoTour tour=VideoTour.parse(content.terms());
            return new GoogleSearch(Source.PHOTOS,((tour==null?"videos "+content.terms():tour.googleTerms())+" "+period).trim());
        }
        String terms;
        if(content!=null && content.photo())terms=content.lettering()?content.terms():PhotoSubject.google(content.terms());
        else if(query.matches("(?iu)^(?:фото(?:графи(?:я|и|ю|й))?|сним(?:ок|ки)|картин(?:ка|ку|ки)|скрин(?:шот)?ы?)(?:[ ,].*)?$"))
            terms=query.replaceFirst("(?iu)^\\S+?[, ]+|^\\S+$","").trim();
        else return null;
        if(!period.isEmpty())terms=(terms+" "+period).trim();
        return new GoogleSearch(Source.PHOTOS,terms);
    }
}
