package local.jarvis.search;

import android.util.Base64;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;

final class OpenAIResponses {
    static String text(JSONObject body,String sealedKey) throws Exception {
        String key=DeviceCredential.open(Base64.decode(sealedKey,Base64.NO_WRAP));
        if(Thread.currentThread().isInterrupted())throw new InterruptedException();
        HttpsURLConnection conn=(HttpsURLConnection)new URL("https://api.openai.com/v1/responses").openConnection();
        try{
            conn.setInstanceFollowRedirects(false);conn.setRequestMethod("POST");
            conn.setConnectTimeout(12000);conn.setReadTimeout(45000);conn.setDoOutput(true);
            conn.setRequestProperty("Authorization","Bearer "+key);
            conn.setRequestProperty("Content-Type","application/json");
            byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);
            try(OutputStream out=conn.getOutputStream()){out.write(bytes);}
            if(conn.getResponseCode()!=200)throw new IOException("OpenAI не вернул ответ. Код "+conn.getResponseCode()+".");
            JSONObject response=new JSONObject(CloudContract.read(conn.getInputStream(),65536));
            return CloudContract.outputText(response);
        }finally{conn.disconnect();}
    }
}
