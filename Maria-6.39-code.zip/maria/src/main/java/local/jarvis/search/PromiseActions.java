package local.jarvis.search;

import android.app.*;
import android.content.SharedPreferences;
import java.time.*;
import java.util.*;
import java.util.regex.*;

final class PromiseActions {
    private final SearchActivity a;
    private final SharedPreferences state;
    PromiseActions(SearchActivity a){this.a=a;state=a.getSharedPreferences("promise_action",0);}
    void clear(){state.edit().clear().commit();}
    void choose(){choose("");}
    private void choose(String action){
        List<Promises.Item> items=Promises.all(a).stream().filter(Promises::active).sorted(Comparator.comparingLong(Promises.Item::due)).toList();
        if(items.isEmpty()){a.promiseReply("Открытых обещаний нет.");return;}
        new AlertDialog.Builder(a).setTitle("Выберите обещание")
            .setItems(items.stream().map(i->i.object()+" · "+i.note()+" · "+Promises.when(i.due())).toArray(String[]::new),(d,index)->{
                if(action.isEmpty())select(items.get(index));
                else{state.edit().clear().putInt("id",items.get(index).id()).commit();handle(action);}
            }).setNegativeButton("Закрыть",null).show();
    }
    void select(Promises.Item item){
        state.edit().clear().putInt("id",item.id()).commit();
        a.promiseReply(item.object()+" · "+item.label()+". Скажите «уже отправил» или «перенеси на завтра в десять утра».");
        AlertDialog.Builder dialog=new AlertDialog.Builder(a).setTitle(item.object()).setMessage(item.label());
        if(Promises.active(item)){
            dialog.setPositiveButton("Выполнено",(d,w)->complete(item));
            dialog.setNeutralButton("Перенести",(d,w)->pickTime(item));
            dialog.setNegativeButton("Говорить",(d,w)->a.listenForPromise());
        }else dialog.setNegativeButton("Закрыть",null);
        dialog.show();
    }
    private void complete(Promises.Item item){
        if(Promises.mark(a,item.id(),Promises.DONE)){
            state.edit().clear().commit();a.promiseReply("Выполнено · "+item.note()+" · "+item.object()+".");
        }else a.promiseReply("Не удалось сохранить отметку. Повторите.");
    }
    private void move(Promises.Item item,long due){
        a.withNotifications(()->{
            if(Promises.move(a,item,due)){state.edit().remove("day").apply();a.promiseReply("Перенёс · "+item.note()+" · "+item.object()+". Напомню "+Promises.when(due)+".");}
            else a.promiseReply("Не удалось перенести. Укажите будущее время и проверьте уведомления.");
        });
    }
    private void pickTime(Promises.Item item){
        Calendar at=Calendar.getInstance();at.setTimeInMillis(item.due());
        new DatePickerDialog(a,(v,y,m,d)->new TimePickerDialog(a,(clock,h,min)->{
            at.set(y,m,d,h,min,0);at.set(Calendar.MILLISECOND,0);move(item,at.getTimeInMillis());
        },at.get(Calendar.HOUR_OF_DAY),at.get(Calendar.MINUTE),true).show(),at.get(Calendar.YEAR),at.get(Calendar.MONTH),at.get(Calendar.DAY_OF_MONTH)).show();
    }
    boolean handle(String raw){
        String command=raw.strip().toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("[.!?]+$","");
        if(command.matches("(?:покажи |открой )?управление обещаниями")){choose();return true;}
        boolean done=command.matches("(?:уже )?(?:отправил[а]?|сделал[а]?|выполнено)");
        if(command.equals("отмена")&&state.contains("day")){clear();a.promiseReply("Перенос отменён.");return true;}
        boolean move=command.startsWith("перенеси ")||command.equals("напомни через час");
        boolean time=state.contains("day")&&PromiseDialog.time(command)!=null;
        if(!done&&!move&&!time)return false;
        Promises.Item selected=Promises.get(a,state.getInt("id",-1));
        if(selected==null||!Promises.active(selected)){state.edit().clear().commit();choose(raw);return true;}
        if(done){complete(selected);return true;}
        if(command.equals("напомни через час")){move(selected,System.currentTimeMillis()+3600000);return true;}
        String phrase=command.replaceFirst("^перенеси (?:на )?","");
        Matcher day=Pattern.compile("^(сегодня|завтра|послезавтра)(?:\\s+|$)").matcher(phrase);
        if(day.find()){
            LocalDate date=LocalDate.now().plusDays(day.group(1).equals("сегодня")?0:day.group(1).equals("завтра")?1:2);
            state.edit().putString("day",date.toString()).commit();phrase=phrase.substring(day.end()).strip();
        }
        LocalTime clock=PromiseDialog.time(phrase);
        if(clock==null){
            if(!state.contains("day"))state.edit().putString("day",Instant.ofEpochMilli(selected.due()).atZone(ZoneId.systemDefault()).toLocalDate().toString()).apply();
            a.promiseReply("Во сколько перенести «"+selected.note()+"»? Скажите, например, «перенеси на завтра в 10:30».");return true;
        }
        LocalDate date=LocalDate.parse(state.getString("day",Instant.ofEpochMilli(selected.due()).atZone(ZoneId.systemDefault()).toLocalDate().toString()));
        move(selected,date.atTime(clock).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());return true;
    }
}
