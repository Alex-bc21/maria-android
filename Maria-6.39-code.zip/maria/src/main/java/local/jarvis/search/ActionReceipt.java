package local.jarvis.search;

import android.app.*;
import android.content.*;
import android.provider.AlarmClock;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.*;

final class ActionReceipt {
    private static final Pattern TIME=Pattern.compile("(?<![0-9])(?:([01]?[0-9]|2[0-3])[:.]([0-5][0-9])|в ([01]?[0-9]|2[0-3])(?: час(?:а|ов)?)?)(?![0-9:.])");
    static String norm(String s){return s.toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("[,!?]+"," ").replaceAll("\\s+"," ").strip();}
    static SharedPreferences prefs(Context c){return c.getSharedPreferences("completed_actions",0);}
    static String stamp(long when){return Instant.ofEpochMilli(when).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"));}
    static void remember(Context c,String type,String note,long due,String status){
        prefs(c).edit().putString("last",type).putString(type+"_note",note).putLong(type+"_due",due)
            .putLong(type+"_at",System.currentTimeMillis()).putString(type+"_status",status).apply();
    }
    static long due(String text){
        Matcher m=TIME.matcher(text);if(!m.find())return 0;
        int h=Integer.parseInt(m.group(1)==null?m.group(3):m.group(1)),min=m.group(2)==null?0:Integer.parseInt(m.group(2));
        String period=text.substring(m.end()).stripLeading();
        if((period.startsWith("вечера") || period.startsWith("дня")) && h>0 && h<12)h+=12;
        else if(period.startsWith("ночи") && h==12)h=0;
        var now=ZonedDateTime.now();var at=now.withHour(h).withMinute(min).withSecond(0).withNano(0);
        if(text.contains("послезавтра"))at=at.plusDays(2);
        else if(text.contains("завтра")||!text.contains("сегодня")&&!at.isAfter(now))at=at.plusDays(1);
        return at.toInstant().toEpochMilli();
    }
    static String report(Context c,String type){
        var p=prefs(c);long due=p.getLong(type+"_due",0);
        if(due==0)return "У меня нет записи о выполнении этого действия.";
        if(type.equals("alarm")){
            var alarm=c.getSystemService(AlarmManager.class).getNextAlarmClock();
            if(alarm!=null && alarm.getTriggerTime()==due && alarm.getShowIntent()!=null &&
                    alarm.getShowIntent().getCreatorPackage().equals(p.getString("clockPackage","")))
                return "Android подтверждает ближайший будильник приложения «Часы» на "+stamp(due)+".";
        }
        return p.getString(type+"_status","")+" "+stamp(due)+".";
    }
    static void alarm(SearchActivity a,String input,String time){
        long when=due(norm(time));if(when<=System.currentTimeMillis()){a.reply("На какое будущее время поставить будильник?");return;}
        var at=Instant.ofEpochMilli(when).atZone(ZoneId.systemDefault());
        var now=ZonedDateTime.now();var nearest=now.withHour(at.getHour()).withMinute(at.getMinute()).withSecond(0).withNano(0);
        if(!nearest.isAfter(now))nearest=nearest.plusDays(1);
        if(!nearest.toLocalDate().equals(at.toLocalDate())){a.reply("Для этой даты откройте «Часы» и выберите дату будильника. Стандартная команда Android ставит его на ближайшее указанное время.");return;}
        var p=prefs(a);
        if(p.getLong("alarm_due",0)==when && System.currentTimeMillis()-p.getLong("alarm_at",0)<300000){a.reply(report(a,"alarm"));return;}
        String label="Мария";
        Matcher named=Pattern.compile("[«\"]([^»\"]{1,70})[»\"]").matcher(input);
        if(named.find())label=named.group(1);
        Intent i=new Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR,at.getHour())
            .putExtra(AlarmClock.EXTRA_MINUTES,at.getMinute()).putExtra(AlarmClock.EXTRA_MESSAGE,label).putExtra(AlarmClock.EXTRA_SKIP_UI,true);
        var component=i.resolveActivity(a.getPackageManager());
        if(component==null){a.reply("Android не нашёл приложение для установки будильника.");return;}
        try{a.startActivity(i.setComponent(component));}
        catch(RuntimeException e){a.reply("Приложение часов не приняло команду.");return;}
        p.edit().putString("clockPackage",component.getPackageName()).apply();
        remember(a,"alarm",label,when,"Передала запрос в приложение часов. Время запроса на будильник:");
        a.record("Действие","SET_ALARM · "+component.getPackageName()+" · "+stamp(when));
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(()->{
            String result=report(a,"alarm");a.record("Результат",result);
            if(!a.isDestroyed()&&!a.isFinishing())a.reply(result);
        },800);
    }
}
