package local.jarvis.search;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.widget.RemoteViews;
public final class JarvisWidget extends AppWidgetProvider {
    public void onUpdate(Context c,AppWidgetManager manager,int[] ids){
        Intent intent=new Intent(c,SearchActivity.class).setAction("local.jarvis.MIC")
                .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent talk=PendingIntent.getActivity(c,0,intent,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        for(int id:ids){
            RemoteViews view=new RemoteViews(c.getPackageName(),c.getResources().getIdentifier("talk_widget","layout",c.getPackageName()));
            view.setOnClickPendingIntent(android.R.id.button1,talk);manager.updateAppWidget(id,view);
        }
    }
}
