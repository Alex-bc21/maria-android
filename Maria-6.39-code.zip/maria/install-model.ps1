param(
    [Parameter(Mandatory)][string]$Adb,
    [Parameter(Mandatory)][string]$Serial,
    [Parameter(Mandatory)][string]$ModelFile
)
$ErrorActionPreference='Stop'
$revision='91cad51170dc346986eccefdc2dd33a9da36ead9'
$name='qwen2.5-1.5b-instruct-q4_k_m.gguf'
$expected='6A1A2EB6D15622BF3C96857206351BA97E1AF16C30D7A74EE38970E434E9407E'
if (!(Test-Path -LiteralPath $ModelFile)) {
    & curl.exe --fail --location --retry 2 "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/$revision/$name" -o "$ModelFile.part"
    if ($LASTEXITCODE -ne 0) { throw 'Model download failed' }
    if ((Get-FileHash -LiteralPath "$ModelFile.part").Hash -ne $expected) { throw 'Downloaded file failed verification' }
    Move-Item -LiteralPath "$ModelFile.part" -Destination $ModelFile
}
if ((Get-FileHash -LiteralPath $ModelFile).Hash -ne $expected) { throw 'Model checksum mismatch' }
$dir='/sdcard/Android/data/local.jarvis.search/files'
& $Adb -s $Serial shell mkdir -p $dir
if ($LASTEXITCODE -ne 0) { throw 'Cannot access application folder. Install APK first.' }
& $Adb -s $Serial push $ModelFile "$dir/qwen.gguf.part"
if ($LASTEXITCODE -ne 0) { throw 'Model transfer failed' }
$remote=& $Adb -s $Serial shell sha256sum "$dir/qwen.gguf.part"
if ($LASTEXITCODE -ne 0 -or ($remote -split '\s+')[0] -ne $expected) { throw 'Phone copy failed verification' }
& $Adb -s $Serial shell mv "$dir/qwen.gguf.part" "$dir/qwen.gguf"
if ($LASTEXITCODE -ne 0) { throw 'Cannot activate model' }
