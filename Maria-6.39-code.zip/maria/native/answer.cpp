#include <jni.h>
#include "llama.h"
#include <algorithm>
#include <atomic>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace {
std::mutex run_mutex;
std::atomic<jlong> current{0};
std::string bytes(JNIEnv *env, jbyteArray input) {
    std::string value(env->GetArrayLength(input), '\0');
    env->GetByteArrayRegion(input, 0, value.size(), reinterpret_cast<jbyte *>(value.data()));
    return value;
}
bool aborted(void *id) { return current.load() != *static_cast<jlong *>(id); }
}

extern "C" JNIEXPORT void JNICALL Java_local_jarvis_search_LocalAnswer_select(JNIEnv *, jclass, jlong id) {
    current.store(id);
}
extern "C" JNIEXPORT jbyteArray JNICALL Java_local_jarvis_search_LocalAnswer_generate(
        JNIEnv *env, jclass, jbyteArray path, jbyteArray prompt, jlong id) {
    std::lock_guard<std::mutex> lock(run_mutex);
    if (aborted(&id)) return nullptr;
    static std::once_flag initialized;
    std::call_once(initialized, llama_backend_init);
    // Unload after each answer so other phone apps regain the memory immediately.
    auto mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    std::unique_ptr<llama_model, decltype(&llama_model_free)> model(
        llama_model_load_from_file(bytes(env,path).c_str(),mp), llama_model_free);
    if (!model || aborted(&id)) return nullptr;
    auto cp = llama_context_default_params();
    cp.n_ctx=1024; cp.n_batch=256; cp.n_threads=4; cp.n_threads_batch=4;
    cp.abort_callback=aborted; cp.abort_callback_data=&id;
    std::unique_ptr<llama_context, decltype(&llama_free)> ctx(llama_init_from_model(model.get(),cp),llama_free);
    if (!ctx) return nullptr;
    auto vocab=llama_model_get_vocab(model.get());
    std::string question=bytes(env,prompt);
    std::vector<llama_token> tokens(860);
    int n=llama_tokenize(vocab,question.data(),question.size(),tokens.data(),tokens.size(),false,true);
    if (n<=0) return nullptr;
    for (int i=0;i<n;i+=256) {
        if (aborted(&id) || llama_decode(ctx.get(),llama_batch_get_one(tokens.data()+i,std::min(n-i,256)))!=0) return nullptr;
    }
    std::unique_ptr<llama_sampler,decltype(&llama_sampler_free)> sampler(llama_sampler_init_greedy(),llama_sampler_free);
    std::string answer;
    for (int i=0;i<160;i++) {
        if (aborted(&id)) return nullptr;
        llama_token token=llama_sampler_sample(sampler.get(),ctx.get(),-1);
        if (llama_vocab_is_eog(vocab,token)) break;
        char part[512];
        int length=llama_token_to_piece(vocab,token,part,sizeof(part),0,false);
        if (length<0) return nullptr;
        answer.append(part,length);
        if (llama_decode(ctx.get(),llama_batch_get_one(&token,1))!=0) return nullptr;
    }
    auto result=env->NewByteArray(answer.size());
    if (result) env->SetByteArrayRegion(result,0,answer.size(),reinterpret_cast<const jbyte *>(answer.data()));
    return result;
}
