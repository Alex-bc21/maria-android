"""Transfer a Jarvis key to one Android Keystore recipient over an authorized ADB connection."""
import argparse
import hashlib
import hmac
from pathlib import Path
import subprocess
import tempfile

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--adb", default="adb")
    parser.add_argument("--device", required=True)
    parser.add_argument("--fingerprint", required=True, help="Code displayed inside Jarvis")
    parser.add_argument("--env-file", type=Path, required=True)
    args = parser.parse_args()
    adb = [args.adb, "-s", args.device]
    remote = "/sdcard/Android/data/local.jarvis.search/files/"
    with tempfile.TemporaryDirectory() as tmp:
        der = Path(tmp) / "public.der"
        subprocess.run(adb + ["pull", remote + "jarvis-public.der", str(der)], check=True, stdout=subprocess.DEVNULL)
        data = der.read_bytes()
        fingerprint = hashlib.sha256(data).hexdigest()[:24].upper()
        if not hmac.compare_digest(fingerprint, args.fingerprint.strip().upper()):
            parser.exit(1, "Device fingerprint does not match. Transfer canceled.\n")
        public = serialization.load_der_public_key(data)
        if not isinstance(public, rsa.RSAPublicKey) or public.key_size != 3072:
            parser.exit(1, "Unexpected device public key.\n")
        for line in args.env_file.read_text(encoding="utf-8-sig").splitlines():
            name, _, value = line.partition("=")
            if name.strip() == "OPENAI_API_KEY":
                key = value.strip().strip("\042\047").encode("ascii")
                break
        else:
            parser.exit(1, "Missing OPENAI_API_KEY.\n")
        if not key.startswith(b"sk-") or not 19 <= len(key) <= 303:
            parser.exit(1, "Invalid API key format.\n")
        packet = Path(tmp) / "jarvis-key.bin"
        packet.write_bytes(public.encrypt(key, padding.OAEP(mgf=padding.MGF1(hashes.SHA1()), algorithm=hashes.SHA256(), label=None)))
        subprocess.run(adb + ["push", str(packet), remote + "jarvis-key.bin"], check=True, stdout=subprocess.DEVNULL)
    print("Encrypted key delivered. Select Accept on the phone.")


if __name__ == "__main__":
    main()
